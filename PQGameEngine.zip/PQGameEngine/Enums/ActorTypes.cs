namespace PQGameEngine.Enums;

public enum ActorTypes
{
    Attacker = 1,
    Defender = 2,
}