namespace PQGameEngine.Enums;

public enum AssetCategories
{
    MOBILE = 1,
    CLOUD = 2,
    DMZ = 3,
    LAN = 4,
    WEB_SERVER = 5,
    MAIL_SERVER = 6,
    APP_SERVER = 7,
    FILE_SERVER = 8,
    DATABASE = 9,
    CLIENT = 10,
    NETWORK_APPLIANCE = 11,
    IOT = 12,
    CONTAINER = 13,
    INDUSTRIAL_SYSTEM = 14,
    SCADA = 15,
    DEVICE = 16
}