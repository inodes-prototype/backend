namespace PQGameEngine.Enums;

public enum GameOptionMultiTargetSuccessMode
{
    OneRollPerTarget = 0,
    Attacker_OneRollOnAverageSuccessChanceOfAllTargets = 1,
    Defender_OneRollOnAverageSuccessChanceOfAllTargets = 2,
    All_OneRollOnAverageSuccessChanceOfAllTargets = 3,
}