﻿namespace PQGameEngine.Enums;

public enum ReplayedActionEffectBehaviour
{
    REFRESH = 0,

    STACK = 1,
}