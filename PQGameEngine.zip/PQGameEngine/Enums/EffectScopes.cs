namespace PQGameEngine.Enums;

public enum EffectScopes
{
    Undefined = 0,
    Attackers = 1,
    Defenders = 2,
    Own = 3,
    NotOwn = 4,
}