namespace PQGameEngine.Enums;

public enum ChangedPlayerAttributeType
{
    Insight = 1,
    Credits = 2,
    Initiative = 3,
    Skill = 4,
    InsightShield = 5,
}