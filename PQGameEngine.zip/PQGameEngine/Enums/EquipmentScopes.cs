namespace PQGameEngine.Enums;

public enum EquipmentScopes
{
    All = 1,
    NotOwn = 2,
    Own = 3,
    Attackers = 4,
    Defenders = 5,
}