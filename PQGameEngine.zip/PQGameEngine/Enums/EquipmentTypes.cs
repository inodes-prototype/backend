namespace PQGameEngine.Enums;

public enum EquipmentTypes
{
    ATTACK_EQUIPMENT = 1,
    DEFENSE_EQUIPMENT = 2,
}