namespace PQGameEngine.Enums;

public enum ConnectionStates
{
    Online = 1,
    Offline = 2,
}