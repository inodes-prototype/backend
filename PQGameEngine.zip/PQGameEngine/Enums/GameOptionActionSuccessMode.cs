﻿namespace PQGameEngine.Enums;

public enum GameOptionActionSuccessMode
{
    DEFAULT = 0,
    ALWAYS_SUCCESS = 1
}