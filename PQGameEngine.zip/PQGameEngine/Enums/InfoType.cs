namespace PQGameEngine.Enums;

public enum InfoType
{
    InvalidCommand = 1,
}