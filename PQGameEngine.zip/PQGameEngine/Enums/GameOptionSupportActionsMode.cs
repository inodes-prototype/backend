﻿namespace PQGameEngine.Enums;

public enum GameOptionSupportActionsMode
{
    DISABLED = 0,
    ENABLED = 1,
    ALL_AT_START = 2
}