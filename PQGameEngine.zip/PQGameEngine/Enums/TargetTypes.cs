namespace PQGameEngine.Enums;

public enum TargetTypes
{
    Untargeted = 0,
    Single = 1,
    Multi = 2
}