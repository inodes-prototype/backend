namespace PQGameEngine.Enums;

public enum GamePlayerEndState
{
    Won = 1,
    Lost = 2,
    AutoDefeatAssetOffline = 3,
    Surrendered = 4,
}