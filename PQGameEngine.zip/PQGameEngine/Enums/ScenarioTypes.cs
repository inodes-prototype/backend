namespace PQGameEngine.Enums;

public enum ScenarioTypes
{
    Other = 0,
    Tutorial = 1,
    Training = 2,
    Challenge = 3,
    SoloPlay = 4,
    Testing = 5,
}