namespace PQGameEngine.Enums;

public enum GameOptionInitialAssetStage
{
    DEFAULT = 0,
    RECONNAISSANCE = 1,
    INITIAL_ACCESS = 2,
    EXECUTION = 3
}