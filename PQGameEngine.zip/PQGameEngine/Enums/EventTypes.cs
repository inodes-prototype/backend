﻿namespace PQGameEngine.Enums;

public enum EventTypes
{
    AttackActionEvent = 1,
    DefenseActionEvent = 2,
}