namespace PQGameEngine.Enums;

public enum GameOptionDefenderPreSetupMode
{
    ScenarioDefined = 0,
    Disabled = 1,
    AttributeBased = 2,
}