namespace PQGameEngine.Enums;

public enum ModifiableAttributes
{
    Credits,
    Insight,
    Skill
}