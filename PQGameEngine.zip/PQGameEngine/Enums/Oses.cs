namespace PQGameEngine.Enums;

public enum Oses
{
    Windows = 1,
    Linux = 2,
    iOS = 3,
    Android = 4
}