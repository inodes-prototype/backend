namespace PQGameEngine.Enums;

public enum DeflectedType
{
    Not = 0,
    PartiallyDeflected = 1,
    FullyDeflected = 2,
}