namespace PQGameEngine.Enums;

public enum DefenseActionType
{
    None = 0,
    Prevention = 2,
    Detection = 1,
    Response = 3
}