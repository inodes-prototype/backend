namespace PQGameEngine.Enums;

public enum GoalTypes
{
    AssetGoal = 1,
    ActorGoal = 2,
    DefenderNotExceedActorGoal = 3,
}