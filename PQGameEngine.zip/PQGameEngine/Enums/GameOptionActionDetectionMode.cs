﻿namespace PQGameEngine.Enums;

public enum GameOptionActionDetectionMode
{
    DEFAULT = 0,
    ALWAYS_DETECT = 1
}