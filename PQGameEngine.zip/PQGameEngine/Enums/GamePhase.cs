﻿namespace PQGameEngine.Enums;

public enum GamePhase
{
    Starting = 0,
    InitDraw = 1,
    Attack = 3,
    Defense = 4,
    Ended = 5,
    DefenderPreSetup = 6,
}