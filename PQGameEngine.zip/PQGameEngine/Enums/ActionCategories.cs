namespace PQGameEngine.Enums;

public enum ActionCategories
{
    MainAction = 1,
    SupportAction = 2,
}