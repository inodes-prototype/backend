namespace PQGameEngine.Enums;

public enum GameOptionManualDefType
{
    DISABLED = 0,
    PREVENTION = 1,
    DETECTION = 2,
    RESPONSE = 3,
    PREVENTION_ONLY = 4,
    DETECTION_ONLY = 5,
    RESPONSE_ONLY = 6
}