namespace PQGameEngine.Enums;

public enum ActionSuccessState
{
    Failed = 1,
    PartialSuccess = 2,
    Success = 3,
}