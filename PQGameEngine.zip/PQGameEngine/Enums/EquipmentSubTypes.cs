namespace PQGameEngine.Enums;

public enum EquipmentSubTypes
{
    ATTACK_TOOL = 1,
    MALWARE = 2,
    EXPLOIT = 3,
    CREDENTIALS = 4,
    SECURITY_SYSTEMS = 5,
    FAILOVER = 6,
    FIX = 7,
    POLICY = 8
}