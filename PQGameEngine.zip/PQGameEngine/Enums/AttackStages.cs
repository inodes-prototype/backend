namespace PQGameEngine.Enums;

public enum AttackStages
{
    None = 0,
    Reconnaissance = 1,
    InitialAccess = 2,
    Execution = 3
}