﻿namespace PQGameEngine.Enums;

public enum GameOptionDefenderActionsDetectableMode
{
    ResponseOnly = 0,
    PreventionAndResponse = 1,
    DetectionAndResponse = 2,
    AllDefenseAction = 3
}