﻿namespace PQGameEngine.Enums;

public enum GameOptionEquipmentShopMode
{
    DISABLED = 0,
    RANDOM = 1,
    ALL_EQUIPMENT = 2
}