namespace PQGameEngine.Enums;

public enum EffectTimings
{
    PreSuccess = 1,
    PostSuccess = 2
}