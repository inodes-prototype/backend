namespace PQGameEngine.Enums;

public enum ActionTypes
{
    Attack = 1,
    Defense = 2,
}