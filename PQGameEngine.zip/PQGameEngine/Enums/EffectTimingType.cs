﻿namespace PQGameEngine.Enums;

public enum EffectTimingType
{
    PreSuccess = 1,
    PostSuccess = 2
}