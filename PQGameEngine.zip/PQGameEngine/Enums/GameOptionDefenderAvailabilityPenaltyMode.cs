﻿namespace PQGameEngine.Enums;

public enum GameOptionDefenderAvailabilityPenaltyMode
{
    Enabled = 0,
    Disabled = 1
}