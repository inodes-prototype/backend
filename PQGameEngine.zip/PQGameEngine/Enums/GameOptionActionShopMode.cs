﻿namespace PQGameEngine.Enums;

public enum GameOptionActionShopMode
{
    RANDOM = 0,
    ALL_ACTIONS = 1
}