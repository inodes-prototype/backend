﻿namespace PQGameEngine.Enums;

public enum GameOptionInitActionsMode
{
    RANDOM = 0,
    PLAYABLE = 1,
    PICK = 2
}