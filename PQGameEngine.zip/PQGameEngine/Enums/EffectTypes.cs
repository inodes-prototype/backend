namespace PQGameEngine.Enums;

public enum EffectTypes
{
    MODIFY_ACTION = 3,
    MODIFY_ACTOR = 5,
    DAMAGE_SHIELD = 7,
    REVEAL_ASSET = 8,
    INFO = 9,
    GRANT_EQUIPMENT = 10,
    GRANT_ADMIN_RIGHTS = 11,
    REVOKE_ADMIN_RIGHTS = 12,
    APPLY_DOT = 13,
    CURE_DOT = 14,
    INSIGHT_PREVENTION = 15,
    STEAL_CREDITS = 16,
}