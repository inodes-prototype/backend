namespace PQGameEngine.Utils;

public class SeedableRandom : IRandom
{
    private readonly Random _random;

    public SeedableRandom(int seed)
    {
        _random = new Random(seed);
    }

    public int Next(int maxValue)
    {
        return _random.Next(maxValue);
    }

    public int Next(int minValue, int maxValue)
    {
        return _random.Next(minValue, maxValue + 1);
    }

    public void Shuffle<T>(T[] array)
    {
        for (int i = 0; i < array.Length - 1; ++i)
        {
            int r = _random.Next(i, array.Length);
            (array[r], array[i]) = (array[i], array[r]);
        }
    }
}