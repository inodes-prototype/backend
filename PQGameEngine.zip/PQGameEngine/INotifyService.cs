﻿using PQGameEngine.GameEventMessages;
using PQGameEngine.GameEventMessages.Outbound;

namespace PQGameEngine;

public interface INotifyService
{
    void Notify(string connectionId, Guid userId, IGameEventMessage content);
    void NotifyBot(string connectionId, Guid userId, IBotEventMessage content);
}