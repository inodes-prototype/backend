﻿using System.Collections.Concurrent;
using PQGameEngine.GameEventMessages.Inbound;

namespace PQGameEngine.Commands;

public abstract class AbstractCommand(string connectionId, Guid userId, Guid? sourceServiceId, long requestId)
    : IBaseCommand
{
    public string ConnectionId { get; } = connectionId;
    public Guid UserId { get; } = userId;
    public Guid? SourceServiceId { get; } = sourceServiceId;
    public long RequestId { get; } = requestId;
    public string GetConnectionId() => ConnectionId;

    private static ConcurrentDictionary<Type, string> CommandNameCache = [];
    private const string CommandNameSuffix = "Command";

    public string GetCommandName()
    {
        var type = GetType();

        if (CommandNameCache.TryGetValue(type, out var name)) return name;

        name = type.Name;
        if (name.EndsWith(CommandNameSuffix) && name.Length > CommandNameSuffix.Length)
        {
            name = name[..^CommandNameSuffix.Length];
        }

        CommandNameCache.TryAdd(type, name);

        return name;
    }
}

public abstract class AbstractCommand<T>(
    string connectionId,
    Guid userId,
    Guid? sourceServiceId,
    long requestId,
    T data)
    : AbstractCommand(connectionId, userId, sourceServiceId, requestId)
    where T : ICommandEventArgs
{
    public T Data { get; } = data;
}