﻿using PQGameEngine.GameEventMessages.Inbound;

namespace PQGameEngine.Commands;

[GameCommand(Constants.COMMAND_SELECT_ACTIONS)]
public class SelectActionsCommand(
    string connectionId,
    Guid userId,
    Guid? sourceServiceId,
    long requestId,
    SelectActionEvent data)
    : AbstractCommand<SelectActionEvent>(connectionId, userId, sourceServiceId, requestId, data), IInGameCommand;