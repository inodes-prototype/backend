﻿namespace PQGameEngine.Commands;

[AttributeUsage(AttributeTargets.Class)]
public class GameCommandAttribute : Attribute
{
    public GameCommandAttribute(string command)
    {
        Command = command;
    }

    public string Command { get; }
}