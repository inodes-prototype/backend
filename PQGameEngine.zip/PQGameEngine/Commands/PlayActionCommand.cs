﻿using PQGameEngine.GameEventMessages.Inbound;

namespace PQGameEngine.Commands;

[GameCommand(Constants.COMMAND_PLAY_ACTION)]
public class PlayActionCommand(
    string connectionId,
    Guid userId,
    Guid? sourceServiceId,
    long requestId,
    PlayActionEvent data)
    : AbstractCommand<PlayActionEvent>(connectionId, userId, sourceServiceId, requestId, data), IInGameCommand;