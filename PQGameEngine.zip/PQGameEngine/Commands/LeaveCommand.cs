﻿using PQGameEngine.GameEventMessages.Inbound;

namespace PQGameEngine.Commands;

[GameCommand(Constants.COMMAND_LEAVE_GAME)]
public class LeaveCommand(string connectionId, Guid userId, Guid? sourceServiceId, long requestId, LeaveGameEvent data)
    : AbstractCommand<LeaveGameEvent>(connectionId, userId, sourceServiceId, requestId, data), IInGameCommand;