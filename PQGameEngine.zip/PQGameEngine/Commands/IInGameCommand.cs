namespace PQGameEngine.Commands;

public interface IInGameCommand : IBaseCommand
{
}