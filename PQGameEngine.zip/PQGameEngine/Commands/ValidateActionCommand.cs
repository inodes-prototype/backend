﻿using PQGameEngine.GameEventMessages.Inbound;

namespace PQGameEngine.Commands;

[GameCommand(Constants.COMMAND_VALIDATE_ACTION)]
public class ValidateActionCommand(
    string connectionId,
    Guid userId,
    Guid? sourceServiceId,
    long requestId,
    PlayActionEvent data)
    : AbstractCommand<PlayActionEvent>(connectionId, userId, sourceServiceId, requestId, data), IInGameCommand;