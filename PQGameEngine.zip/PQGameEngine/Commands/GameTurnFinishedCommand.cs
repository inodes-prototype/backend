namespace PQGameEngine.Commands;

[GameCommand(Constants.COMMAND_TURN_FINISHED)]
public class GameTurnFinishedCommand(string connectionId, Guid userId, Guid? sourceServiceId, long requestId)
    : AbstractCommand(connectionId, userId, sourceServiceId, requestId), IInGameCommand;