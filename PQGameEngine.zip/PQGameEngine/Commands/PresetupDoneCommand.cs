namespace PQGameEngine.Commands;

[GameCommand(Constants.COMMAND_PRESETUP_DONE)]
public class PresetupDoneCommand(string connectionId, Guid userId, Guid? sourceServiceId, long requestId)
    : AbstractCommand(connectionId, userId, sourceServiceId, requestId), IInGameCommand;