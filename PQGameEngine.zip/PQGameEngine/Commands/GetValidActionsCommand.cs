﻿using PQGameEngine.GameEventMessages.Inbound;

namespace PQGameEngine.Commands;

[GameCommand(Constants.COMMAND_GET_VALID_ACTIONS)]
public class GetValidActionsCommand(
    string connectionId,
    Guid userId,
    Guid? sourceServiceId,
    long requestId,
    GetValidActionsEvent data)
    : AbstractCommand<GetValidActionsEvent>(connectionId, userId, sourceServiceId, requestId, data), IInGameCommand;