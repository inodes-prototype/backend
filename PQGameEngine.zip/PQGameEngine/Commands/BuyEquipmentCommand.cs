﻿using PQGameEngine.GameEventMessages.Inbound;

namespace PQGameEngine.Commands;

[GameCommand(Constants.COMMAND_BUY_EQUIPMENT)]
public class BuyEquipmentCommand(
    string connectionId,
    Guid userId,
    Guid? sourceServiceId,
    long requestId,
    BuyEquipmentEvent data)
    : AbstractCommand<BuyEquipmentEvent>(connectionId, userId, sourceServiceId, requestId, data), IInGameCommand;