﻿namespace PQGameEngine.Commands;

[GameCommand(Constants.COMMAND_PLAYER_DISCONNECTED)]
public class PlayerDisconnectedCommand(string connectionId, Guid userId, Guid? sourceServiceId, long requestId)
    : AbstractCommand(connectionId, userId, sourceServiceId, requestId), IInGameCommand;