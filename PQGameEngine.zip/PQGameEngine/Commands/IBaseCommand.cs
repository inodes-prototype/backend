﻿namespace PQGameEngine.Commands;

public interface IBaseCommand
{
    string GetConnectionId();
}