﻿using PQGameEngine.GameEventMessages.Inbound;

namespace PQGameEngine.Commands;

[GameCommand(Constants.COMMAND_RESUME_GAME)]
public class ResumeGameCommand(
    string connectionId,
    Guid userId,
    Guid? sourceServiceId,
    long requestId,
    ResumeGameEvent data)
    : AbstractCommand<ResumeGameEvent>(connectionId, userId, sourceServiceId, requestId, data), IInGameCommand;