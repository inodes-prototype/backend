namespace PQGameEngine.Commands;

[GameCommand(Constants.COMMAND_SURRENDER)]
public class SurrenderCommand(string connectionId, Guid userId, Guid? sourceServiceId, long requestId)
    : AbstractCommand(connectionId, userId, sourceServiceId, requestId), IInGameCommand;