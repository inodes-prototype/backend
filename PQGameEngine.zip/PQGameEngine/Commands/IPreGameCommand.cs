namespace PQGameEngine.Commands;

public interface IPreGameCommand : IBaseCommand
{
}