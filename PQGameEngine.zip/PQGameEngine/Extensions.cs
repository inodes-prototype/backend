﻿using PQGameEngine.Enums;

namespace PQGameEngine;

public static class Extensions
{
    public static string? ToViewText(this AttackStages attackStages)
    {
        return attackStages switch
        {
            AttackStages.Reconnaissance => "Reconnaissance",
            AttackStages.InitialAccess => "InitialAccess",
            AttackStages.Execution => "Execution",
            _ => null
        };
    }

    public static string? ToViewText(this EffectScopes scope)
    {
        return scope switch
        {
            EffectScopes.NotOwn => "Scope.NotOwn",
            EffectScopes.Own => "Scope.Own",
            EffectScopes.Attackers => "Scope.Attackers",
            EffectScopes.Defenders => "Scope.Defenders",
            _ => null
        };
    }

    public static string? ToViewText(this EquipmentScopes scope)
    {
        return scope switch
        {
            EquipmentScopes.All => "Scope.All",
            EquipmentScopes.NotOwn => "Scope.NotOwn",
            EquipmentScopes.Own => "Scope.Own",
            EquipmentScopes.Attackers => "Scope.Attackers",
            EquipmentScopes.Defenders => "Scope.Defenders",
            _ => null
        };
    }

    public static string? ToViewText(this TargetTypes targetType)
    {
        return targetType switch
        {
            TargetTypes.Untargeted => "untargeted",
            TargetTypes.Multi => "multi",
            TargetTypes.Single => "single",
            _ => null
        };
    }

    public static string ToViewText(this EffectTypes type, short? duration)
    {
        return type switch
        {
            EffectTypes.MODIFY_ACTION when duration == 0 => "inc_dec_effect",
            EffectTypes.MODIFY_ACTION when duration != 0 => "permanent_inc_dec_effect",
            EffectTypes.MODIFY_ACTOR => "inc_dec_effect",
            EffectTypes.DAMAGE_SHIELD => "damage_shield_effect",
            EffectTypes.REVEAL_ASSET => "reveal_assets_effect",
            EffectTypes.INFO => "placeholder_effect",
            EffectTypes.GRANT_EQUIPMENT => "grant_equipment_effect",
            EffectTypes.GRANT_ADMIN_RIGHTS => "grant_admin",
            EffectTypes.REVOKE_ADMIN_RIGHTS => "revoke_admin",
            _ => "base_effect"
        };
    }

    public static string? ToViewText(this EquipmentSubTypes type)
    {
        return type switch
        {
            EquipmentSubTypes.ATTACK_TOOL => "AttackTool",
            EquipmentSubTypes.MALWARE => "Malware",
            EquipmentSubTypes.EXPLOIT => "Exploit",
            EquipmentSubTypes.CREDENTIALS => "Credentials",
            EquipmentSubTypes.SECURITY_SYSTEMS => "SecuritySystem",
            EquipmentSubTypes.FAILOVER => "Failover",
            EquipmentSubTypes.FIX => "Fix",
            EquipmentSubTypes.POLICY => "Policy",
            _ => null
        };
    }
}