﻿namespace PQGameEngine.Models.GameEvents;

public class DrawActionEvent(int turn, int actorId, int actionIdDrawn, List<(Guid ActionId, int Amount)>? selection)
    : GameEvent(turn)
{
    public int ActorId { get; } = actorId;
    public int ActionIdDrawn { get; } = actionIdDrawn;

    public List<(Guid ActionId, int Amount)>? Selection { get; } = selection;
}