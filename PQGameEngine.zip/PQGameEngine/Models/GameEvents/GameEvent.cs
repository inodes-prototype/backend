﻿namespace PQGameEngine.Models.GameEvents;

public abstract class GameEvent
{
    public GameEvent(int turn)
    {
        Id = Guid.NewGuid();
        Turn = turn;
    }

    public Guid Id { get; private set; }
    public int Turn { get; }

    public void ForceOverrideId(Guid id)
    {
        Id = id;
    }
}