﻿using System.Collections.ObjectModel;
using PQGameEngine.Enums;
using PQGameEngine.Functionality;
using PQGameEngine.Functionality.Effects;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.Internal;

namespace PQGameEngine.Models.GameEvents;

public class ActionEvent(int turn, MainActionModel mainAction, List<int>? effectIds)
    : GameEvent(turn), IEffectApplicable, IEquipmentApplicable, IEffectTarget
{
    public record struct ChanceModifier(decimal Value, Guid EventId, int EffectId);

    public MainActionModel MainAction { get; } = mainAction;
    public bool? Succeeded { get; set; }
    public decimal RollResult { get; set; }
    public DeflectedType Deflected { get; set; } = DeflectedType.Not;
    public List<(Guid eventId, DeflectedType deflected, DamageModel deflectedDmg)> DeflectedBy { get; set; } = [];
    public List<ChanceModifier> HistorySuccessChance { get; } = [];
    public List<ChanceModifier> HistoryDetectionChance { get; } = [];
    public List<ChanceModifier> HistoryDetectionChanceFailed { get; } = [];
    private readonly List<int> _effects = [..effectIds ?? []];
    public ReadOnlyCollection<int> Effects => _effects.AsReadOnly();

    public List<ActorModifier> ActorModifiers { get; } = [];

    public Guid? Counters { get; set; }

    public Dictionary<int, int> Detected { get; } = [];

    public HashSet<AppliedEffectSource> AppliedEffects { get; } = [];

    public List<int> InfluencedByEquipment { get; } = [];

    public bool IsAttackAction => MainAction.IsAttackAction;
    public bool IsDefenseAction => MainAction.IsDefenseAction;

    public void AddEffect(int effectId)
    {
        _effects.Add(effectId);
    }

    public override string ToString()
    {
        return $"'{MainAction.Name}'";
    }

    public int SophReq => MainAction.CurrentSophReq;

    public decimal GetSuccessChance(decimal skillModifier, decimal insightModifier) =>
        CalcTotalChance(MainAction.Template.SuccessChance + skillModifier + insightModifier, HistorySuccessChance);

    public decimal GetDetectionChance() => CalcTotalChance(MainAction.Template.DetectionChance, HistoryDetectionChance);

    public decimal GetDetectionChanceFailed() =>
        CalcTotalChance(MainAction.Template.DetectionChanceFailed, HistoryDetectionChanceFailed);

    public bool Detectable => MainAction.Template.Detectable;
    public int DetectableDuring => MainAction.Template.DetectableDuring;

    public TargetTypes TargetType => MainAction.Template.TargetType;

    public int Actor => MainAction.Actor;

    public string AttackMaskUsed => MainAction.AttackMaskUsed!;

    public List<int> SupportedBy => MainAction.SupportedBy;

    public List<int> EquipmentPlayedWith => MainAction.EquipmentPlayedWith;

    public decimal? RealSuccessChance { get; private set; }
    public List<int> GeneratedEquipment { get; } = [];

    public void ChangeSuccessChance(decimal incomingSuccessChance, Guid eventId, int effectId)
    {
        HistorySuccessChance.Add(new ChanceModifier(incomingSuccessChance, eventId, effectId));
    }

    public void ChangeDetectionChance(decimal incomingDetectionChance, Guid eventId, int effectId)
    {
        HistoryDetectionChance.Add(new ChanceModifier(incomingDetectionChance, eventId, effectId));
    }

    public void ChangeDetectionChanceFailed(decimal incomingDetectionChanceFailed, Guid eventId, int effectId)
    {
        HistoryDetectionChanceFailed.Add(new ChanceModifier(incomingDetectionChanceFailed, eventId, effectId));
    }

    public void SetRealSuccessChance(decimal actualSuccessChance)
    {
        RealSuccessChance = actualSuccessChance;
    }

    public int GetOwnerId()
    {
        return MainAction.OwnerId;
    }

    public bool WasEffectiveAction() => Succeeded == true && Deflected != DeflectedType.FullyDeflected;

    private static decimal CalcTotalChance(decimal baseValue, List<ChanceModifier> modifier)
    {
        decimal totalSuccessChance = baseValue + modifier.Sum(obj => obj.Value);

        return Math.Max(Math.Min(totalSuccessChance, 1.0M), 0.0M);
    }
}