﻿using PQGameEngine.Enums;
using PQGameEngine.Functionality.Shields;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Models.GameEvents;

public class AssetActionEvent : ActionEvent, IShieldApplicable<DamageShield>
{
    public int AssetId { get; }
    public Dictionary<int, DamageModel> AppliedDependencyDamage { get; } = [];

    public DamageModel DamageDealt { get; private set; } = DamageModel.Zero;

    public DamageModel CurrentImpact { get; private set; }

    public List<Guid> CounteredByEvents { get; } = [];

    public bool FullyCountered { get; set; }
    public int? LastTurnToCounter { get; }
    public bool IsCounterable { get; set; }
    public (AttackStages oldStage, AttackStages newStage)? AttackStageChangedInfo { get; private set; }
    public List<int> ExposedAssetInfo { get; } = [];

    public List<int> UnexposedAssets { get; } = [];

    public List<int> ExposedAssets { get; } = [];

    public List<char> InitiallyCompromisedTypes { get; } = [];

    public List<char> CompromisedTypes { get; } = [];

    public List<char> UncompromisedTypes { get; } = [];

    public AssetActionEvent(int assetId, int turn, MainActionModel mainAction, List<int>? effectIds,
        ExposedModel? assetCurrentExposedState) : base(turn,
        mainAction, effectIds)
    {
        AssetId = assetId;
        CurrentImpact = mainAction.CurrentImpact;
        if (mainAction.IsAttackAction && assetCurrentExposedState != null)
        {
            CurrentImpact = CurrentImpact.ApplyMask(assetCurrentExposedState.Value.ToCiaString());
        }

        IsCounterable = true;
        if (mainAction.Template.CounterableDuring.HasValue)
        {
            if (mainAction.Template.CounterableDuring == 0)
            {
                IsCounterable = false;
            }
            else
            {
                LastTurnToCounter = turn + (mainAction.Template.CounterableDuring.Value - 1);
            }
        }
        else
        {
            LastTurnToCounter = null;
        }
    }

    public bool IsCurrentlyCounterable(GameInstance game)
    {
        if (!IsCounterable) return false;
        if (game.Turn > LastTurnToCounter) return false;
        return true;
    }

    public bool WasCounterable(GameInstance game)
    {
        if (!IsCounterable) return false;
        if (game.Turn > LastTurnToCounter) return true;
        return false;
    }

    public void AddImpact(DamageModel impact)
    {
        CurrentImpact += impact;
    }

    public void SetImpact(DamageModel impact)
    {
        CurrentImpact = impact;
    }

    public void SetDamageDealt(DamageModel damage)
    {
        DamageDealt = damage;
    }

    public void SetAttackStageChangedInfo(AttackStages previousAttackStage, AttackStages newAttackStage)
    {
        AttackStageChangedInfo = (previousAttackStage, newAttackStage);
    }

    public void AddExposedAssetInfo(int neighboringAssetId)
    {
        ExposedAssetInfo.Add(neighboringAssetId);
    }

    public Guid GetSourceActionEventId()
    {
        return Id;
    }
}