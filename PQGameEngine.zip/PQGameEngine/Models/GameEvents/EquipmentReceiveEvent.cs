﻿namespace PQGameEngine.Models.GameEvents;

public class EquipmentReceiveEvent(int turn, int actorId, int equipmentIdBought, List<Guid>? selection)
    : GameEvent(turn)
{
    public int ActorId { get; } = actorId;
    public int EquipmentIdBought { get; } = equipmentIdBought;

    public List<Guid>? Selection { get; } = [..selection ?? []];
}