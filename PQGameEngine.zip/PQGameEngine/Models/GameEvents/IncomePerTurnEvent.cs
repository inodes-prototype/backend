﻿namespace PQGameEngine.Models.GameEvents;

public class IncomePerTurnEvent(int turn, int actorId, decimal income) : GameEvent(turn)
{
    public int ActorId { get; } = actorId;
    public decimal Income { get; } = income;
}