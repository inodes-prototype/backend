﻿using PQGameEngine.Models.Internal;

namespace PQGameEngine.Models.GameEvents;

public class PlayedActionEvent(
    int turn,
    int actorId,
    List<PlayedActionEventResult> correspondingActionEvents)
    : GameEvent(turn)
{
    public int ActorId { get; } = actorId;
    public List<PlayedActionEventResult> CorrespondingActionEvents { get; } = correspondingActionEvents;
}