namespace PQGameEngine.Models.GameEvents;

public class PlayerSurrenderedEvent(int turn, int actorId) : GameEvent(turn)
{
    public int ActorId { get; } = actorId;
}