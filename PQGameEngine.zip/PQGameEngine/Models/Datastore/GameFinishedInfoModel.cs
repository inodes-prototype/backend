﻿using PQGameEngine.Enums;

namespace PQGameEngine.Models.Datastore;

public class GameFinishedInfoModel
{
    public Guid GameId { get; set; }
    public int Turns { get; set; }
    public List<ActorInfoModel> ActorInfos { get; set; } = [];

    public class ActorInfoModel
    {
        public Guid UserId { get; set; }
        public int ActorId { get; set; }
        public GamePlayerEndState EndState { get; set; }
        public string ConnectionId { get; set; } = default!;
        public string? StatsInfoJson { get; set; }
        public int Xp { get; set; }
        public ActorTypes ActorType { get; set; }
    }
}