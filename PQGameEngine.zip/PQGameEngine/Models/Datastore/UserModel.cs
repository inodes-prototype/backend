﻿using PQGameEngine.Utils;

namespace PQGameEngine.Models.Datastore;

public class UserModel
{
    public Guid Id { get; set; }
    public string Name { get; set; } = default!;
    public Guid? AvatarId { get; set; }
    public bool IsBot() => Id == Constants.BOT_USER_ID;
}