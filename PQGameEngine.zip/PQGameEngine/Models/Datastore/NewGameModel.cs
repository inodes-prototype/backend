﻿namespace PQGameEngine.Models.Datastore;

public class NewGameModel
{
    public List<PlayerInfo> Players { get; set; }
    public Guid Id { get; set; }
    public string Code { get; set; }
    public Guid ScenarioId { get; set; }

    public class PlayerInfo
    {
        public Guid UserId { get; set; }
        public string ConnectionId { get; set; }
        public int RoleId { get; set; }
    }
}