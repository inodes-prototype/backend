﻿using PQGameEngine.Enums;

namespace PQGameEngine.Models.Datastore;

public class RunningGamePlayerModel
{
    public Guid GameId { get; set; }
    public Guid UserId { get; set; }
    public string ConnectionId { get; set; }
    public ConnectionStates OnlineStatus { get; set; }
}