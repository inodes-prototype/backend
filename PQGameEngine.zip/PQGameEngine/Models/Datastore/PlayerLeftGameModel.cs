﻿namespace PQGameEngine.Models.Datastore;

public class PlayerLeftGameModel
{
    public Guid GameId { get; set; }
    public Guid UserId { get; set; }
    public string ConnectionId { get; set; }
    public int ActorId { get; set; }
    public bool HasWon { get; set; }
    public bool UserLeft { get; set; }
}