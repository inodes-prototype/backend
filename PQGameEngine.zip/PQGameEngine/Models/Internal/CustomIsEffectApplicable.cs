using PQGameEngine.Enums;
using PQGameEngine.Functionality;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Models.Internal;

public delegate bool CustomIsEffectApplicable(GameInstance game, EffectModel effect, IEffectApplicable target,
    EffectTimingType timingFilter);