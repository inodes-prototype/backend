﻿using PQGameEngine.Commands;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Models.Internal;

public class InternalStartGameCommand : IPreGameCommand
{
    public InternalStartGameCommand(Guid gameId, string code, Guid scenarioId, GameOptionsModel gameOptions,
        int? seed, ScenarioConfig scenarioConfig)
    {
        GameId = gameId;
        Code = code;
        ScenarioId = scenarioId;
        GameOptions = gameOptions;
        Seed = seed;
        ScenarioConfig = scenarioConfig;
        Players = [];
    }

    public Guid GameId { get; }
    public string Code { get; }
    public Guid ScenarioId { get; }
    public GameOptionsModel GameOptions { get; }
    public int? Seed { get; }
    public Guid? XpEventId { get; }
    public ScenarioConfig ScenarioConfig { get; }
    public List<(int slotId, LobbyUserModel user)> Players { get; }

    public string GetConnectionId() =>
        throw new InvalidOperationException("Connection id does not exist in this context");
}