namespace PQGameEngine.Models.Internal;

public record struct PlayedActionEventResult(Guid ActionEventId, bool Success);