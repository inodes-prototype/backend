using PQGameEngine.Enums;
using PQGameEngine.Functionality;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Models.Internal;

public class TurnTracker
{
    private readonly ActorModel _actor;
    private readonly GameEngineDependencies _geDeps;

    public TurnTracker(ActorModel actor, GameEngineDependencies geDeps)
    {
        _actor = actor;
        _geDeps = geDeps;
        InitForNewTurn();
    }

    private readonly List<Guid> _actionsOffered = [];

    public IReadOnlyCollection<Guid> ActionsOffered => _actionsOffered;

    public int RemainingActionPoints { get; private set; }

    public int TotalActionPointsThisTurn { get; private set; }

    public bool ActionsDrawn { get; private set; }

    public int ActionsPlayedThisTurn { get; private set; }

    public bool TurnEnded { get; private set; }

    private static int AddLowerBounded(int value, int boundToAdd)
    {
        var t = value + boundToAdd;
        return Math.Min(t, boundToAdd);
    }

    public void InitForNewTurn()
    {
        switch (_actor.Type)
        {
            case ActorTypes.Attacker:
                TotalActionPointsThisTurn = Constants.GAME_ENGINE_ACTION_POINTS_PER_TURN_ATTACKER;
                RemainingActionPoints = AddLowerBounded(RemainingActionPoints,
                    Constants.GAME_ENGINE_ACTION_POINTS_PER_TURN_ATTACKER);
                break;
            case ActorTypes.Defender:
                TotalActionPointsThisTurn = Constants.GAME_ENGINE_ACTION_POINTS_PER_TURN_DEFENDER;
                RemainingActionPoints = AddLowerBounded(RemainingActionPoints,
                    Constants.GAME_ENGINE_ACTION_POINTS_PER_TURN_DEFENDER);
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(_actor.Type), "Actor type is not supported");
        }

        ActionsDrawn = false;
        _actionsOffered.Clear();
        ActionsPlayedThisTurn = 0;
        TurnEnded = false;

        _geDeps.Notifier.ActionPointsChanged(_actor, RemainingActionPoints);
    }

    public void SetOfferedActions(List<Guid> offeredActions)
    {
        _actionsOffered.Clear();
        _actionsOffered.AddRange(offeredActions);
        if (offeredActions.Count == 0)
        {
            ActionsDrawn = true;
        }
    }

    public void SetActionPoints(int actionPoints)
    {
        if (actionPoints < 0) throw new ArgumentOutOfRangeException(nameof(actionPoints));

        RemainingActionPoints = actionPoints;

        _geDeps.Notifier.ActionPointsChanged(_actor, RemainingActionPoints);
    }

    public void MarkTurnFinished()
    {
        TurnEnded = true;
    }

    public void PlayedAction(int actionPointCost = 1)
    {
        if (actionPointCost < 0) throw new ArgumentOutOfRangeException(nameof(actionPointCost));

        ActionsPlayedThisTurn++;
        RemainingActionPoints -= actionPointCost;

        _geDeps.Notifier.ActionPointsChanged(_actor, RemainingActionPoints);
    }

    public void SetHasDrawn()
    {
        ActionsDrawn = true;
    }

    public bool HasFinishedItsTurn()
    {
        return TurnEnded || RemainingActionPoints <= ActorHelper.GetMinApValue(_actor);
    }
}