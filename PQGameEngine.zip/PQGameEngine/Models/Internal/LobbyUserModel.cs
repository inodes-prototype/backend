using PQGameEngine.Models.Datastore;

namespace PQGameEngine.Models.Internal;

public class LobbyUserModel(string connectionId, UserModel user)
{
    public string ConnectionId { get; } = connectionId;
    public UserModel User { get; } = user;
}