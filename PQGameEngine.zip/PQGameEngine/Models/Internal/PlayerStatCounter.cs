namespace PQGameEngine.Models.Internal;

public class PlayerStatCounter
{
    public ActionPlayedCounter ReconActions { get; } = new();
    public ActionPlayedCounter InitialAccessActions { get; } = new();
    public ActionPlayedCounter ExecutionActions { get; } = new();
    public ActionPlayedCounter DetectionActions { get; } = new();
    public ActionPlayedCounter PreventionActions { get; } = new();
    public ActionPlayedCounter ResponseActions { get; } = new();

    public int ExploitsFound { get; set; }
    public int ExploitsUsed { get; set; }
    public int ExploitsFixed { get; set; }
    public int CredentialsGathered { get; set; }
    public int AdminGained { get; set; }
    public int AdminRevoked { get; set; }
    public int DamageCaused { get; set; }
    public int DamageHealed { get; set; }
    public int DamagePrevented { get; set; }
    public int InsightGained { get; set; }
    public int InsightPrevented { get; set; }
    public int ActionsDetected { get; set; }
    public int EquipmentBought { get; set; }
    public decimal CreditsSpent { get; set; }

    public int ActionsPlayed => ReconActions.Total + InitialAccessActions.Total + ExecutionActions.Total +
                                DetectionActions.Total + PreventionActions.Total + ResponseActions.Total;

    public int ActionsPlayedSuccessfully => ReconActions.TotalSucceeded + InitialAccessActions.TotalSucceeded +
                                            ExecutionActions.TotalSucceeded + DetectionActions.TotalSucceeded +
                                            PreventionActions.TotalSucceeded + ResponseActions.TotalSucceeded;

    public MostValuableAction? Mva { get; set; }

    public HashSet<int> SystemsCompromised { get; } = [];

    public HashSet<int> CompromisedSystemsMitigated { get; } = [];

    public class ActionPlayedCounter
    {
        public int Success { get; set; }
        public int PartialSuccess { get; set; }
        public int Failed { get; set; }

        public int Total => Success + PartialSuccess + Failed;

        public int TotalSucceeded => Success + PartialSuccess;
    }

    public class MostValuableAction
    {
        public int ActionId { get; set; }
        public int MaxImpact { get; set; }
    }
}