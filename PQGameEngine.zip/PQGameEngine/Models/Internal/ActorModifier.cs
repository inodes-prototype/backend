using PQGameEngine.Enums;
using PQGameEngine.Functionality.Shields;

namespace PQGameEngine.Models.Internal;

public class ActorModifier(
    int actorId,
    ModifiableAttributes type,
    decimal value,
    Guid eventId,
    int effectId) : IShieldApplicable<InsightShield>
{
    public int ActorId { get; } = actorId;
    public ModifiableAttributes Type { get; } = type;
    public decimal Value { get; private set; } = value;
    public decimal InitialValue { get; } = value;
    public Guid EventId { get; } = eventId;
    public int EffectId { get; } = effectId;
    public IReadOnlyCollection<PreventedBy> PreventedValue => _preventedValue;

    private readonly List<PreventedBy> _preventedValue = [];

    public bool TryReduceValueBy(int effectId, int amount, out int actualReduction)
    {
        actualReduction = (int)Math.Max(0, Math.Min(amount, Value));
        if (actualReduction > 0)
        {
            Value -= actualReduction;
            _preventedValue.Add(new PreventedBy(effectId, actualReduction));
            return true;
        }

        return false;
    }

    public Guid GetSourceActionEventId()
    {
        return EventId;
    }
}

public record struct PreventedBy(int EffectId, int Amount);