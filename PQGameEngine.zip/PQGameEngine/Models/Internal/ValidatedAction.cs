using PQGameEngine.Exceptions;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Models.Internal;

public class ValidatedAction(MainActionModel mainAction)
{
    public MainActionModel MainAction { get; } = mainAction;
    public List<AssetModel> Targets { get; } = [];
    public List<SupportActionModel> SupportActions { get; } = [];
    public List<EquipmentModel> Equipment { get; } = [];
    public string AttackMask { get; set; } = default!;
    public int ResponseTargetId { get; set; }
    public List<PenQuestErrorInfo> Errors { get; } = [];
    public bool IsPlayable => Errors.Count == 0;
    public List<PenQuestErrorInfo> Warnings { get; set; } = [];

    public int GetTotalActionPointCost()
    {
        return mainAction.Template.ActionPointCost + SupportActions.Sum(x => x.Template.ActionPointCost);
    }
}