﻿using PQGameEngine.Enums;
using PQGameEngine.Functionality;
using PQGameEngine.Templates;

namespace PQGameEngine.Models.Game;

public class EquipmentModel
{
    public int Id { get; set; }
    public EquipmentTemplate Template { get; }
    public EquipmentScopes Scope { get; set; }
    public List<int> Effects { get; }
    public List<int> TransferEffects { get; }

    public int OwnerId { get; }

    public int? PlayedWithAction { get; private set; }
    public IEquipmentApplicable? EquiptOn { get; set; }

    public EquipmentModel(int id, EquipmentTemplate template, int ownerId, List<int> effectIds,
        List<int> transferEffectIds)
    {
        Id = id;
        Template = template;
        OwnerId = ownerId;
        Scope = template.InitialScope;
        Effects = effectIds;
        TransferEffects = transferEffectIds;
    }

    public Guid TemplateId => Template.Id;
    public string Name => Template.Name;
    public decimal Price => Template.Price;
    public string ShortDescription => Template.ShortDescription;
    public string LongDescription => Template.LongDescription;
    public HashSet<Guid> PossibleActions => Template.PossibleActions;
    public HashSet<AssetCategories> PossibleAssetCategories => Template.PossibleAssetCategories;
    public HashSet<AttackStages> PossibleAttackStages => Template.PossibleAttackStages;
    public HashSet<Oses> PossibleOses => Template.PossibleOses;
    public EquipmentSubTypes EquipmentType => Template.EquipmentType;
    public bool IsAttackEquipment => Template.IsAttackEquipment;
    public bool IsDefenseEquipment => Template.IsDefenseEquipment;

    public Guid? UsedOn { get; set; }

    public bool Active { get; private set; }

    public int RemainingTurns { get; private set; }

    public void SetPlayedWith(int actionId)
    {
        PlayedWithAction = actionId;
    }

    public void Activate()
    {
        Active = true;
    }

    public void Deactivate()
    {
        Active = false;
    }

    public void DecreaseOneTurn()
    {
        if (RemainingTurns > 0)
        {
            RemainingTurns--;
            if (RemainingTurns == 0)
            {
                Deactivate();
            }
        }
    }

    public override string ToString()
    {
        return $"Equipment[id:{Id};templateId:{TemplateId}]";
    }

    public static bool IsTemplatePermanentEquipment(EquipmentTemplate template) => template.EquipmentType.In(
        EquipmentSubTypes.POLICY, EquipmentSubTypes.EXPLOIT, EquipmentSubTypes.FIX, EquipmentSubTypes.ATTACK_TOOL,
        EquipmentSubTypes.SECURITY_SYSTEMS);

    public static bool IsTemplateSingleUseEquipment(EquipmentTemplate template) => template.EquipmentType.In(
        EquipmentSubTypes.CREDENTIALS, EquipmentSubTypes.FAILOVER, EquipmentSubTypes.EXPLOIT, EquipmentSubTypes.FIX,
        EquipmentSubTypes.MALWARE);

    public static bool IsTemplateGlobalEquipment(EquipmentTemplate template) =>
        template.EquipmentType.In(EquipmentSubTypes.SECURITY_SYSTEMS, EquipmentSubTypes.POLICY,
            EquipmentSubTypes.ATTACK_TOOL);

    public static bool IsTemplateLocalEquipment(EquipmentTemplate template) => template.EquipmentType.In(
        EquipmentSubTypes.MALWARE, EquipmentSubTypes.CREDENTIALS, EquipmentSubTypes.EXPLOIT, EquipmentSubTypes.FIX,
        EquipmentSubTypes.FAILOVER);

    public static bool IsTemplatePassiveEquipment(EquipmentTemplate template) =>
        IsTemplateGlobalEquipment(template) && IsTemplatePermanentEquipment(template);
}