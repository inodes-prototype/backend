﻿using System.Text.RegularExpressions;
using PQGameEngine.Exceptions;

namespace PQGameEngine.Models.Game;

public record struct ExposedModel
{
    public static readonly Regex RegexC = new Regex("[cC]", RegexOptions.Compiled);
    public static readonly Regex RegexI = new Regex("[iI]", RegexOptions.Compiled);
    public static readonly Regex RegexA = new Regex("[aA]", RegexOptions.Compiled);

    public static ExposedModel NotExposed => new ExposedModel(false, false, false);

    public static ExposedModel From(string exposedMask)
    {
        if (!Constants.ValidAttackMasks.Contains(exposedMask))
        {
            throw new PenQuestException(Errors.InvalidAttackMaskErrorFatal,
                $"Exposed type '{exposedMask}' is invalid.");
        }

        var c = RegexC.IsMatch(exposedMask);
        var i = RegexI.IsMatch(exposedMask);
        var a = RegexA.IsMatch(exposedMask);

        return new ExposedModel(c, i, a);
    }

    public ExposedModel()
    {
        C = false;
        I = false;
        A = false;
    }

    public ExposedModel(bool c, bool i, bool a)
    {
        C = c;
        I = i;
        A = a;
    }

    public bool C { get; set; }
    public bool I { get; set; }
    public bool A { get; set; }

    public bool IsExposed(char c)
    {
        if (c == 'C' || c == 'c') return C;
        if (c == 'I' || c == 'i') return I;
        if (c == 'A' || c == 'a') return A;
        throw new PenQuestException(Errors.InvalidAttackMaskErrorFatal, $"Invalid attack mask part '{c}'");
    }

    public string ToCiaString()
    {
        return (C ? "C" : "") + (I ? "I" : "") + (A ? "A" : "");
    }

    public bool Any()
    {
        return C || I || A;
    }
}