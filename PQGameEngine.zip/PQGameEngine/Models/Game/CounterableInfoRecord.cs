namespace PQGameEngine.Models.Game;

public record struct CounterableInfoRecord(int CounterableActionId, bool Expired);