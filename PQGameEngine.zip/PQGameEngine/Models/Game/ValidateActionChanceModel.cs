﻿namespace PQGameEngine.Models.Game;

public class ValidateActionChanceModel
{
    public ValidateActionChanceModel(decimal baseChance)
    {
        BaseChance = baseChance;
        Chance = baseChance;
        ChanceModifier = [];
    }

    public decimal BaseChance { get; }
    public decimal Chance { get; private set; }
    public List<(decimal chanceModifier, string reason, string code)> ChanceModifier { get; }


    private void AddBonus(decimal value, string reason, string code)
    {
        if (value != 0)
        {
            ChanceModifier.Add((value, reason, code));
            Chance += value;
        }
    }

    public void AddBonusFromInsight(decimal value, string reason)
    {
        AddBonus(value, reason, GenerateCode(Constants.VA_BONI_CODE_PREFIX_FROM_INSIGHT));
    }

    public void AddBonusFromLocalEq(decimal value, string reason, int effectId, int effectTemplateId, int equipmentId,
        Guid equipmentTemplateId)
    {
        AddBonus(value, reason,
            GenerateCode(Constants.VA_BONI_CODE_PREFIX_FROM_LOCAL_EQ, effectId, effectTemplateId, equipmentId,
                equipmentTemplateId));
    }

    public void AddBonusFromSkill(decimal value, string reason)
    {
        AddBonus(value, reason, GenerateCode(Constants.VA_BONI_CODE_PREFIX_FROM_SKILL));
    }

    public void AddBonusFromSupportAction(decimal value, string reason, int effectId, int effectTemplateId,
        int actionId, Guid actionTemplateId)
    {
        AddBonus(value, reason,
            GenerateCode(Constants.VA_BONI_CODE_PREFIX_FROM_SUPPORT_ACTION, effectId, effectTemplateId, actionId,
                actionTemplateId));
    }

    public void AddBonusFromGlobalPermEq(decimal value, string reason, int effectId, int effectTemplateId,
        int equipmentId, Guid equipmentTemplateId)
    {
        AddBonus(value, reason,
            GenerateCode(Constants.VA_BONI_CODE_PREFIX_FROM_GLOBAL_PERM_EQ, effectId, effectTemplateId, equipmentId,
                equipmentTemplateId));
    }

    public void AddBonusFromLocalPermEqOnAsset(decimal value, string reason, int effectId, int effectTemplateId,
        int equipmentId, Guid equipmentTemplateId)
    {
        AddBonus(value, reason,
            GenerateCode(Constants.VA_BONI_CODE_PREFIX_FROM_LOCAL_PERM_EQ, effectId, effectTemplateId, equipmentId,
                equipmentTemplateId));
    }

    public void AddBonusFromPlayedActions(decimal value, string reason, int effectId, int effectTemplateId,
        int actionId, Guid actionTemplateId)
    {
        AddBonus(value, reason,
            GenerateCode(Constants.VA_BONI_CODE_PREFIX_FROM_PLAYED_ACTIONS, effectId, effectTemplateId, actionId,
                actionTemplateId));
    }

    public void AddBonusFromAsset(decimal value, string reason, int effectId, int effectTemplateId, int assetId)
    {
        AddBonus(value, reason,
            GenerateCode(Constants.VA_BONI_CODE_PREFIX_FROM_ASSET, effectId, effectTemplateId, assetId));
    }

    public void AddBonusFromAlwaySuccess(decimal value, string reason)
    {
        AddBonus(value, reason, GenerateCode(Constants.VA_BONI_CODE_PREFIX_FROM_ALWAYS_SUCCESS));
    }

    public void AddBonusFromAlwaysDetect(decimal value, string reason)
    {
        AddBonus(value, reason, GenerateCode(Constants.VA_BONI_CODE_PREFIX_FROM_ALWAYS_DETECT));
    }

    public static string GenerateCode(params object[] parts)
    {
        return string.Join("+", parts);
    }
}