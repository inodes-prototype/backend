﻿using System.Collections.ObjectModel;
using PQGameEngine.Enums;
using PQGameEngine.Functionality;
using PQGameEngine.Functionality.Effects;
using PQGameEngine.Functionality.Shields;
using PQGameEngine.Templates;

namespace PQGameEngine.Models.Game;

public class AssetModel : IEffectApplicable, IEquipmentApplicable, IEffectTarget, IHasInsightShield, IHasDamageShield
{
    public AssetTemplate Template { get; }

    public int Id => Template.Id;

    public AttackStages InitialAttackStage { get; private set; }

    public ExposedModel CurrentExposedState { get; private set; }

    public List<(ExposedModel, Guid)> ExposedHistory { get; private set; }

    public AttackStages CurrentAttackStage { get; private set; }
    public List<AttackStages> AttackStageHistory { get; private set; }
    public DamageModel CurrentDamage { get; private set; }

    public bool IsOffline => CurrentDamage.A >= Constants.DMG_MAX;

    public List<(DamageModel dmg, Guid eventId)> DamageHistory { get; private set; }

    public List<Guid> PlayedActionEvents { get; private set; }

    public HashSet<AppliedEffectSource> AppliedEffects { get; } = [];

    public List<int> InfluencedByEquipment { get; } = [];

    public bool AdminAccessEnabled { get; private set; }
    public HashSet<Guid> EventsGrantingAdminAccess { get; } = [];
    public HashSet<Guid> EventsRevokingAdminAccess { get; } = [];

    public int ExposedPointerCount { get; set; }

    public HashSet<int> RevealedTo { get; private set; }
    public HashSet<int> PreviouslyExposedTo { get; private set; }

    public Guid? First3CDamageEventId { get; set; }

    public Guid? First3IDamageEventId { get; set; }

    public Guid? First3ADamageEventId { get; set; }

    public int? Owner { get; private set; }
    public Guid LastEventIdCausing3ADamage { get; private set; }

    private List<int> _effectsWhenAdminIsActive = [];

    private Dictionary<ActorTypes, bool> _assetHasChanged = [];

    public bool HasAssetChanged(ActorTypes actorType) =>
        _assetHasChanged.TryGetValue(actorType, out var hasChanged) && hasChanged;

    public AssetModel(AssetTemplate template)
    {
        Template = template;

        ExposedPointerCount = template.InitiallyExposed ? 1 : 0;
        RevealedTo = [];
        PreviouslyExposedTo = [];
        CurrentExposedState = template.InitialExposedState;
        ExposedHistory = [];
        InitialAttackStage = template.StartingAttackStage;
        CurrentAttackStage = template.StartingAttackStage;
        AttackStageHistory = [];
        CurrentDamage = DamageModel.Zero;
        DamageHistory = [];
        PlayedActionEvents = [];
    }

    public void MarkAssetAsChanged()
    {
        _assetHasChanged[ActorTypes.Attacker] = true;
        _assetHasChanged[ActorTypes.Defender] = true;
    }

    public void ResetAssetChangedState(ActorTypes actorType)
    {
        _assetHasChanged[actorType] = false;
    }

    public void AddAdminIsActiveEffect(int effectId)
    {
        _effectsWhenAdminIsActive.Add(effectId);
    }

    public ReadOnlyCollection<int> GetActiveAssetSpecificEffects()
    {
        var l = new List<int>();

        if (AdminAccessEnabled)
        {
            l.AddRange(_effectsWhenAdminIsActive);
        }

        return new ReadOnlyCollection<int>(l);
    }

    public void GrantAdminAccess(Guid eventId)
    {
        AdminAccessEnabled = true;
        EventsGrantingAdminAccess.Add(eventId);
    }

    public void RevokeAdminAccess(Guid eventId)
    {
        AdminAccessEnabled = false;
        EventsRevokingAdminAccess.Add(eventId);
    }

    public void SetOwner(int actorId)
    {
        Owner = actorId;
    }

    public void SetAttackStage(AttackStages initialAssetStage)
    {
        AttackStageHistory.Add(CurrentAttackStage);
        CurrentAttackStage = initialAssetStage;
    }

    public void AddDamage(DamageModel newDamage, Guid eventId)
    {
        var oldADmg = CurrentDamage.A;
        DamageHistory.Add((newDamage, eventId));
        CurrentDamage += newDamage;
        if (oldADmg < CurrentDamage.A && CurrentDamage.A >= Constants.DMG_MAX)
        {
            LastEventIdCausing3ADamage = eventId;
        }
    }

    public void SetExposed(ExposedModel newExposedState, Guid eventId)
    {
        ExposedHistory.Add((CurrentExposedState, eventId));
        CurrentExposedState = newExposedState;
    }

    public void SetInitialAttackStage(AttackStages initialAssetStage)
    {
        CurrentAttackStage = initialAssetStage;
        InitialAttackStage = initialAssetStage;
    }

    public int GetOwnerId()
    {
        return Owner!.Value;
    }

    public override string ToString()
    {
        return $"Asset[id:{Id}]";
    }

    public List<InsightShield> InsightShields { get; } = [];
    public List<DamageShield> DamageShields { get; } = [];
}