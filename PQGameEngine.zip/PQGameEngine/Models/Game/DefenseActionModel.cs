﻿using PQGameEngine.Enums;
using PQGameEngine.Templates;

namespace PQGameEngine.Models.Game;

public class DefenseActionModel : MainActionModel
{
    public DefenseActionType DefType => Template.DefenseType;

    public DefenseActionModel(int id, ActionTemplate template, int ownerId, List<int> effectIds) : base(id, template,
        ownerId, effectIds)
    {
    }
}