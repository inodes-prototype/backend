﻿using PQGameEngine.Exceptions;

namespace PQGameEngine.Models.Game;

public record struct DamageModel
{
    public const int MAX_DAMAGE = Constants.DMG_MAX;
    public const int MIN_DAMAGE = Constants.DMG_MIN;

    public static DamageModel Zero => new DamageModel(0, 0, 0);

    public static DamageModel Create(int dmg, string atkMask)
    {
        return new DamageModel(
            ExposedModel.RegexC.IsMatch(atkMask) ? dmg : 0,
            ExposedModel.RegexI.IsMatch(atkMask) ? dmg : 0,
            ExposedModel.RegexA.IsMatch(atkMask) ? dmg : 0
        );
    }

    public int C { get; set; }
    public int I { get; set; }
    public int A { get; set; }

    public DamageModel(int c, int i, int a)
    {
        C = Math.Max(Math.Min(c, MAX_DAMAGE), MIN_DAMAGE);
        I = Math.Max(Math.Min(i, MAX_DAMAGE), MIN_DAMAGE);
        A = Math.Max(Math.Min(a, MAX_DAMAGE), MIN_DAMAGE);
    }

    public int this[char c]
    {
        get
        {
            switch (c)
            {
                case 'C':
                case 'c':
                    return C;
                case 'I':
                case 'i':
                    return I;
                case 'A':
                case 'a':
                    return A;
                default: throw new NotSupportedException($"Invalid attack mask char '{c}'");
            }
        }
        set
        {
            switch (c)
            {
                case 'C':
                case 'c':
                    C = Math.Max(Math.Min(value, MAX_DAMAGE), MIN_DAMAGE);
                    break;
                case 'I':
                case 'i':
                    I = Math.Max(Math.Min(value, MAX_DAMAGE), MIN_DAMAGE);
                    break;
                case 'A':
                case 'a':
                    A = Math.Max(Math.Min(value, MAX_DAMAGE), MIN_DAMAGE);
                    break;
                default: throw new NotSupportedException($"Invalid attack mask char '{c}'");
            }
        }
    }

    public bool Any(Func<int, bool> predicate)
    {
        if (predicate(C)) return true;
        if (predicate(I)) return true;
        if (predicate(A)) return true;
        return false;
    }

    public DamageModel Invert()
    {
        return new DamageModel(-C, -I, -A);
    }

    public readonly int Sum()
    {
        return C + I + A;
    }

    public readonly int SumDamage()
    {
        var t = 0;
        if (C > 0) t += C;
        if (I > 0) t += I;
        if (A > 0) t += A;
        return t;
    }

    public readonly int SumHeal()
    {
        var t = 0;
        if (C < 0) t -= C;
        if (I < 0) t -= I;
        if (A < 0) t -= A;
        return t;
    }

    public bool All(Func<int, bool> predicate)
    {
        return predicate(C) && predicate(I) && predicate(A);
    }

    public DamageModel ApplyMask(string attackMask)
    {
        if (!Constants.ValidAttackMasks.Contains(attackMask))
        {
            throw new ArgumentException($"Attack mask '{attackMask}' not supported");
        }

        var c = 0;
        var i = 0;
        var a = 0;

        foreach (var ch in attackMask)
        {
            switch (ch)
            {
                case 'c':
                case 'C':
                    c = C;
                    break;
                case 'i':
                case 'I':
                    i = I;
                    break;
                case 'a':
                case 'A':
                    a = A;
                    break;
                default: throw new PenQuestException(Errors.InvalidAttackMaskError, $"Invalid mode '{ch}'");
            }
        }

        return new DamageModel(c, i, a);
    }

    public static bool operator <(DamageModel a, DamageModel b) => a.C < b.C && a.I < b.I && a.A < b.A;
    public static bool operator >(DamageModel a, DamageModel b) => a.C > b.C && a.I > b.I && a.A > b.A;
    public static bool operator <=(DamageModel a, DamageModel b) => a.C <= b.C && a.I <= b.I && a.A <= b.A;
    public static bool operator >=(DamageModel a, DamageModel b) => a.C >= b.C && a.I >= b.I && a.A >= b.A;

    public static DamageModel operator +(DamageModel a, DamageModel b) =>
        new DamageModel(a.C + b.C, a.I + b.I, a.A + b.A);

    public static DamageModel operator -(DamageModel a, DamageModel b) =>
        new DamageModel(a.C - b.C, a.I - b.I, a.A - b.A);

    public readonly char MaxIdx()
    {
        if (C >= I && C >= A) return 'C';
        if (I >= C && I >= A) return 'I';
        if (A >= C && A >= I) return 'A';
        return '\x00';
    }
}