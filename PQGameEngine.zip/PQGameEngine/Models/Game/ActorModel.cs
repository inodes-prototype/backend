﻿using System.Collections.Concurrent;
using PQGameEngine.Enums;
using PQGameEngine.Exceptions;
using PQGameEngine.Functionality;
using PQGameEngine.Functionality.Shields;
using PQGameEngine.Models.Datastore;
using PQGameEngine.Templates;
using PQGameEngine.Utils;

namespace PQGameEngine.Models.Game;

public class ActorModel : IEffectApplicable, IHasInsightShield
{
    public const int MAX_SOPH = 5;
    public const int MAX_DET = 5;
    public const int MAX_WEALTH = 5;
    public const int MAX_INS = 10;
    public const int MAX_INI = 15;
    public const int MIN_SOPH = 1;
    public const int MIN_DET = 1;
    public const int MIN_WEALTH = 1;
    public const int MIN_INS = 0;
    public const int MIN_INI = 0;

    public int Id { get; }

    public string Name => template.Name;
    public string Description => template.Description;
    public string WonText => template.WonText;
    public string LostText => template.LostText;
    public ActorTypes Type => template.Type;

    public int InitialSoph => template.Soph;
    public int CurrentSoph { get; private set; }

    public List<(int changeVal, Guid eventId)> HistorySoph { get; private set; }

    public int InitialDet => template.Det;
    public int CurrentDet { get; }

    public List<(int changeVal, Guid eventId)> HistoryDet { get; private set; }

    public int InitialWealth => template.Wealth;
    public int CurrentWealth { get; }

    public List<(int changeVal, Guid eventId)> HistoryWealth { get; private set; }

    public int InitialIns { get; private set; }
    public int CurrentIns { get; private set; }

    public List<(int changeVal, Guid eventId)> HistoryIns { get; private set; }

    public int InitialIni { get; private set; }
    public int CurrentIni { get; private set; }

    public List<(int changeVal, int Turn)> HistoryIni { get; private set; }

    public decimal InitialCredits { get; private set; }
    public decimal CurrentCredits { get; private set; }

    public List<(decimal changeVal, Guid eventId)> HistoryCredits { get; private set; }


    public bool FirstActionDetected => FirstActionDetectedInTurn.HasValue;

    public int? FirstActionDetectedInTurn { get; private set; }

    public HashSet<int> OwnAssets { get; private set; }

    public HashSet<int> VisibleAssets { get; private set; }

    public HashSet<int> KnownAssets { get; private set; } = [];

    public ConcurrentDictionary<int, int> Known3IDmgOnAssets { get; private set; } = [];

    public List<int> Actions { get; private set; }
    public List<int> Equipment { get; private set; }

    public bool IsAttacker => Type == ActorTypes.Attacker;
    public bool IsDefender => Type == ActorTypes.Defender;

    public bool HasLeft { get; set; }
    public bool IsOnline { get; set; }

    public bool HasSurrendered { get; private set; }

    public Guid UserId { get; private set; }
    
    public string ConnectionId { get; private set; }

    public Guid? AvatarId { get; private set; }

    public string Username { get; private set; }

    private ActorTemplate template;

    public ActorModel(ActorTemplate template)
    {
        this.template = template;

        if (template.Soph > MAX_SOPH || template.Soph < MIN_SOPH)
        {
            throw new PenQuestException(
                Errors.AttributeOutOfRangeErrorFatal,
                $"Error: sophistication is not between {MIN_SOPH} and {MAX_SOPH} for actor {template.Id} {template.Name}"
            );
        }

        if (template.Det > MAX_DET || template.Det < MIN_DET)
        {
            throw new PenQuestException(
                Errors.AttributeOutOfRangeErrorFatal,
                $"Error: determination is not between {MIN_DET} and {MAX_DET} for actor {template.Id} {template.Name}"
            );
        }

        if (template.Wealth > MAX_WEALTH || template.Wealth < MIN_WEALTH)
        {
            throw new PenQuestException(
                Errors.AttributeOutOfRangeErrorFatal,
                $"Error: wealth is not between {MIN_WEALTH} and {MAX_WEALTH} for actor {template.Id} {template.Name}"
            );
        }

        Id = template.Id;

        CurrentSoph = template.Soph;
        HistorySoph = [];
        CurrentDet = template.Det;
        HistoryDet = [];
        CurrentWealth = template.Wealth;
        HistoryWealth = [];
        CurrentIns = 0;
        HistoryIns = [];
        CurrentIni = 0;
        HistoryIni = [];
        CurrentCredits = 0.0M;
        HistoryCredits = [];

        OwnAssets = [];
        VisibleAssets = [];
        Actions = [];
        Equipment = [];

        HasLeft = false;

        IsOnline = true;
    }

    public void ChangeCredits(decimal addValue, Guid eventId)
    {
        if (CurrentCredits + addValue < 0)
        {
            addValue = -CurrentCredits;
        }

        HistoryCredits.Add((addValue, eventId));
        CurrentCredits += addValue;
    }

    public void ChangeIni(int addValue, int turn)
    {
        HistoryIni.Add((addValue, turn));
        CurrentIni += addValue;
    }

    public void ChangeIns(int addValue, Guid eventId)
    {
        HistoryIns.Add((addValue, eventId));
        CurrentIns += addValue;
    }

    public void ChangeSkill(int addValue, Guid eventId)
    {
        HistorySoph.Add((addValue, eventId));
        CurrentSoph += addValue;
    }

    public void ConnectPlayer(string connectionId, UserModel user)
    {
        UserId = user.Id;
        ConnectionId = connectionId;
        AvatarId = user.AvatarId;
        Username = user.Name;
    }

    public void DisconnectPlayer()
    {
        UserId = Guid.Empty;
        ConnectionId = null!;
        AvatarId = null;
        Username = "<unknown-user>";
    }

    public void SetInitialValues(int initiative, int insight, decimal credits)
    {
        InitialIni = initiative;
        CurrentIni = initiative;

        InitialIns = insight;
        CurrentIns = insight;

        InitialCredits = credits;
        CurrentCredits = credits;
    }

    public override string ToString()
    {
        if (IsAttacker) return $"Attacker[slot:{Id};connectionId:{ConnectionId}]";
        if (IsDefender) return $"Defender[slot:{Id};connectionId:{ConnectionId}]";
        return $"Actor[slot:{Id};connectionId:{ConnectionId}]";
    }

    public void RegisterActionDetection(int turn)
    {
        FirstActionDetectedInTurn ??= turn;
    }

    public void MarkSurrendered()
    {
        HasSurrendered = true;
    }

    public HashSet<AppliedEffectSource> AppliedEffects { get; } = [];

    public int GetOwnerId()
    {
        return Id;
    }

    public List<InsightShield> InsightShields { get; } = [];

    public int GetRemainingInsightShieldStrength()
    {
        return InsightShields.Sum(x => x.GrantingEffect.RemainigShieldStrength);
    }

    public decimal GetIncomePerTurn()
    {
        return Type switch
        {
            ActorTypes.Attacker => 0,
            ActorTypes.Defender => Constants.GAME_ENGINE_INCOME_RATE * CurrentWealth,
            _ => throw new ArgumentException($"Income not defined for actor type {Type}"),
        };
    }

    public bool IsBot() => UserId == Constants.BOT_USER_ID;
}