﻿using PQGameEngine.Enums;
using PQGameEngine.Models.Internal;
using PQGameEngine.Templates;

namespace PQGameEngine.Models.Game;

public class EffectModel
{
    public const int MAX_EFFECT_TURNS = 1000000;

    public int Id { get; }

    public EffectTemplate Template { get; }

    public bool IsActive { get; private set; }

    public int RemainingTurns { get; private set; }

    public int RemainigShieldStrength { get; private set; }

    public List<(int absorbedAmount, Guid eventIdCausingDmg)> ShieldStrenghHistory { get; } = [];

    public List<int> GeneratedEquipment { get; } = [];

    public int OwnerId { get; set; }

    public Guid? ActionTemplateSourceId { get; }
    public Guid? EquipmentTemplateSourceId { get; }

    public CustomIsEffectApplicable? CustomCheckApply { get; }
    public Guid? InitializingActionEventId { get; private set; }

    public EffectModel(int id, EffectTemplate template, int ownerId, Guid? actionTemplateSourceId,
        Guid? equipmentTemplateSourceId, CustomIsEffectApplicable? customCheckApply)
        : this(id, template, ownerId, actionTemplateSourceId, equipmentTemplateSourceId)
    {
        CustomCheckApply = customCheckApply;
    }

    public EffectModel(int id, EffectTemplate template, int owningActorId, Guid? actionTemplateSourceId,
        Guid? equipmentTemplateSourceId)
    {
        Id = id;

        Template = template;
        OwnerId = owningActorId;
        ActionTemplateSourceId = actionTemplateSourceId;
        EquipmentTemplateSourceId = equipmentTemplateSourceId;
        RemainingTurns = GetInitialRemainingTurns(template);
        RemainigShieldStrength = template.ShieldStrength ?? 0;
    }

    private static int GetInitialRemainingTurns(EffectTemplate template)
    {
        return template.Duration >= 0 ? template.Duration.Value : MAX_EFFECT_TURNS;
    }

    public void Activate()
    {
        IsActive = true;
    }

    public void Deactivate()
    {
        IsActive = false;
    }

    public void DecreaseOneTurn(out bool isExpired)
    {
        isExpired = false;
        if (this.IsPermanentEffect() && RemainingTurns > 0)
        {
            RemainingTurns--;
            if (RemainingTurns <= 0)
            {
                Deactivate();
                isExpired = true;
            }
        }
    }

    public void ReduceShieldAmount(int shieldedAmount, Guid eventIdCausingTheDamage)
    {
        ShieldStrenghHistory.Add((shieldedAmount, eventIdCausingTheDamage));

        RemainigShieldStrength -= shieldedAmount;
        if (RemainigShieldStrength < 0)
        {
            RemainigShieldStrength = 0;
        }

        if (RemainingTurns < 0)
        {
            RemainigShieldStrength = 0;
        }
    }

    public static bool IsTemplatePermanentEffect(EffectTemplate effectTemplate) =>
        effectTemplate.Type == EffectTypes.DAMAGE_SHIELD || effectTemplate.Type == EffectTypes.INSIGHT_PREVENTION ||
        (effectTemplate.Duration != 0 && effectTemplate.Type == EffectTypes.MODIFY_ACTION ||
         effectTemplate.Type == EffectTypes.APPLY_DOT);

    public static bool IsTemplateIncDecEffect(EffectTemplate effectTemplate) =>
        effectTemplate.Type.In(EffectTypes.MODIFY_ACTION, EffectTypes.MODIFY_ACTOR);

    public static bool IsTemplateUnscopedEffect(EffectTemplate effectTemplate) =>
        effectTemplate.Type.In(EffectTypes.INFO, EffectTypes.REVEAL_ASSET, EffectTypes.GRANT_EQUIPMENT,
            EffectTypes.GRANT_ADMIN_RIGHTS, EffectTypes.REVOKE_ADMIN_RIGHTS, EffectTypes.CURE_DOT);

    public void ResetDuration()
    {
        RemainingTurns = GetInitialRemainingTurns(Template);
    }

    public void ResetShieldStrength()
    {
        RemainigShieldStrength = Template.ShieldStrength ?? 0;
    }

    public void SetInitializingActionEventId(Guid initializingActionEventId)
    {
        if (InitializingActionEventId != null)
        {
            throw new ArgumentException("Field is already set");
        }

        InitializingActionEventId = initializingActionEventId;
    }
}