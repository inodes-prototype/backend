﻿using PQGameEngine.Templates;

namespace PQGameEngine.Models.Game;

public abstract class BaseGoalModel
{
    private readonly GoalTemplate _template;

    public int Id { get; }

    public BaseGoalModel(GoalTemplate template)
    {
        Id = template.GoalId;
        _template = template;
    }

    public string Description => _template.Description;

    public abstract void SetOwningActorId(int actorId);
}