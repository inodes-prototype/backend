﻿using PQGameEngine.Enums;
using PQGameEngine.Templates;

namespace PQGameEngine.Models.Game;

public class AssetGoalModel : BaseGoalModel
{
    public int AssetId { get; }
    public DamageModel Damage { get; }
    public ExposedModel Exposed { get; }
    public AttackStages AttackStage { get; }

    public AssetGoalModel(GoalTemplate template) : base(template)
    {
        AssetId = template.AssetId ??
                  throw new ArgumentNullException(nameof(template.AssetId), "Asset id must not be null");
        Damage = new DamageModel(template.AssetDmgC ?? 0, template.AssetDmgI ?? 0, template.AssetDmgA ?? 0);
        Exposed = new ExposedModel(template.AssetExposedC > 0, template.AssetExposedI > 0, template.AssetExposedA > 0);
        AttackStage = template.AttackStage ?? AttackStages.Reconnaissance;
    }

    public override void SetOwningActorId(int actorId)
    {
    }
}