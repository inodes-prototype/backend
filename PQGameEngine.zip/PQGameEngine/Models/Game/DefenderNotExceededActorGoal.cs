﻿using PQGameEngine.Exceptions;
using PQGameEngine.Templates;

namespace PQGameEngine.Models.Game;

public class DefenderNotExceededActorGoal : BaseGoalModel
{
    public int DefenderId { get; }
    public int ActorId { get; private set; }
    public int? Insight { get; }
    public decimal? Credits { get; }

    public DefenderNotExceededActorGoal(GoalTemplate template) : base(template)
    {
        DefenderId = template.RoleDefenderId ?? throw new PenQuestFatalException("Defender id required");
        Insight = template.TargetInsight;
        Credits = template.TargetCredits;
    }

    public override void SetOwningActorId(int actorId)
    {
        ActorId = actorId;
    }
}