﻿using PQGameEngine.Enums;

namespace PQGameEngine.Models.Game;

public class GameOptionsModel
{
    public GameOptionDefenderPreSetupMode DefenderPreSetupMode { get; set; } =
        GameOptionDefenderPreSetupMode.ScenarioDefined;

    public GameOptionActionSuccessMode ActionSuccessMode { get; set; } = GameOptionActionSuccessMode.DEFAULT;
    public GameOptionActionDetectionMode ActionDetectionMode { get; set; } = GameOptionActionDetectionMode.DEFAULT;
    public GameOptionEquipmentShopMode EquipmentShopMode { get; set; } = GameOptionEquipmentShopMode.RANDOM;
    public GameOptionActionShopMode ActionShopMode { get; set; } = GameOptionActionShopMode.RANDOM;
    public GameOptionSupportActionsMode SupportActionsMode { get; set; } = GameOptionSupportActionsMode.ENABLED;
    public GameOptionInitialAssetStage InitialAssetStage { get; set; } = GameOptionInitialAssetStage.DEFAULT;
    public GameOptionInitActionsMode InitActionsMode { get; set; } = GameOptionInitActionsMode.PLAYABLE;
    public GameOptionManualDefType ManualDefTypeMode { get; set; } = GameOptionManualDefType.DISABLED;
    public bool InfiniteShields { get; set; } = false;

    public GameOptionMultiTargetSuccessMode MultiTargetSuccess { get; set; } =
        GameOptionMultiTargetSuccessMode.OneRollPerTarget;

    public GameOptionDefenderActionsDetectableMode DefenderActionsDetectable { get; set; } =
        GameOptionDefenderActionsDetectableMode.ResponseOnly;

    public GameOptionDefenderAvailabilityPenaltyMode AvailabilityPenalty { get; set; } =
        GameOptionDefenderAvailabilityPenaltyMode.Enabled;
}