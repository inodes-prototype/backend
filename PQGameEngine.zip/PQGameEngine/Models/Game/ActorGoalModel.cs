﻿using PQGameEngine.Templates;

namespace PQGameEngine.Models.Game;

public class ActorGoalModel : BaseGoalModel
{
    public int SelfActorId { get; private set; }
    public int? Insight { get; }
    public decimal? Credits { get; }

    public ActorGoalModel(GoalTemplate template) : base(template)
    {
        Insight = template.TargetInsight;
        Credits = template.TargetCredits;
    }

    public override void SetOwningActorId(int actorId)
    {
        SelfActorId = actorId;
    }
}