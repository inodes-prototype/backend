﻿using PQGameEngine.Enums;
using PQGameEngine.Templates;

namespace PQGameEngine.Models.Game;

public class MainActionModel : BaseActionModel
{
    public int Actor { get; private set; }

    public string? AttackMaskUsed { get; private set; }

    public List<int> SupportedBy { get; private set; }

    public List<int> EquipmentPlayedWith { get; private set; }

    public Dictionary<int, Guid> ActionEvents { get; private set; }

    public MainActionModel(int id, ActionTemplate template, int ownerId, List<int> effectIds) : base(id, template,
        ownerId, effectIds)
    {
        Actor = 0;
        AttackMaskUsed = null;
        SupportedBy = [];
        EquipmentPlayedWith = [];
        ActionEvents = [];
    }

    public decimal SuccessChance => Template.SuccessChance;
    public decimal DetectionChance => Template.DetectionChance;
    public decimal DetectionChanceFailed => Template.DetectionChanceFailed;
    public bool Detectable => Template.Detectable;
    public string PredefinedAttackMask => Template.PredefinedAttackMask;
    public TargetTypes TargetType => Template.TargetType;

    public void SetPlayedInfo(int actorId, string usedAttackMask, IEnumerable<int> supportActionIds,
        IEnumerable<int> equipmentIds)
    {
        Actor = actorId;
        AttackMaskUsed = usedAttackMask;
        SupportedBy.AddRange(supportActionIds);
        EquipmentPlayedWith.AddRange(equipmentIds);
    }
}