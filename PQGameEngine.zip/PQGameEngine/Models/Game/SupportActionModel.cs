﻿using PQGameEngine.Templates;

namespace PQGameEngine.Models.Game;

public class SupportActionModel : BaseActionModel
{
    public bool Used { get; set; }
    public List<int> TransferEffects { get; set; }

    public SupportActionModel(int id, ActionTemplate template, int ownerId, List<int> effectIds,
        List<int> transferEffectIds) : base(id, template, ownerId, effectIds)
    {
        Used = false;
        TransferEffects = transferEffectIds;
    }

    public HashSet<Guid> ValidMainActions => Template.ValidMainActions;
}