﻿using PQGameEngine.Enums;
using PQGameEngine.Functionality;
using PQGameEngine.Functionality.Effects;
using PQGameEngine.Templates;

namespace PQGameEngine.Models.Game;

public abstract class BaseActionModel : IEffectApplicable, IEffectTarget
{
    public int Id { get; }
    public ActionTemplate Template { get; }
    public int CurrentSophReq { get; private set; }

    public List<(int changeVal, Guid eventId)> HistorySophReq { get; }

    public List<int> Effects { get; }
    public DamageModel CurrentImpact { get; }

    public HashSet<AppliedEffectSource> AppliedEffects { get; } = [];

    public int OwnerId { get; }

    public BaseActionModel(int id, ActionTemplate template, int ownerId, List<int>? effectIds)
    {
        Id = id;
        Template = template;
        HistorySophReq = [];
        Effects = effectIds ?? [];
        OwnerId = ownerId;
        CurrentImpact = template.Impact;
        CurrentSophReq = template.SophReq;
    }

    public Guid TemplateId => Template.Id;
    public string Name => Template.Name;

    public void ChangeSophReq(int incomingSophReq, Guid eventId)
    {
        HistorySophReq.Add((incomingSophReq, eventId));
        CurrentSophReq = Math.Max(-1 * (CurrentSophReq - ActorModel.MIN_SOPH),
            Math.Min(ActorModel.MAX_SOPH - CurrentSophReq, incomingSophReq));
    }

    public int GetOwnerId()
    {
        return OwnerId;
    }

    public string ShortDescription => Template.ShortDescription;
    public string LongDescription => Template.LongDescription;
    public HashSet<AssetCategories> AssetCategories => Template.AssetCategories;
    public AttackStages AttackStage => Template.AttackStage;
    public HashSet<Oses> Oses => Template.Oses;

    public bool IsMainAction => Template.IsMainAction;
    public bool IsSupportAction => Template.IsSupportAction;
    public bool IsAttackAction => Template.IsAttackAction;
    public bool IsDefenseAction => Template.IsDefenseAction;

    public override string ToString()
    {
        return $"Action[id:{Id},templateId:{Template.Id}";
    }
}