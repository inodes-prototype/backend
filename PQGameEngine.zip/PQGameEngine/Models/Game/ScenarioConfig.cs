namespace PQGameEngine.Models.Game;

public class ScenarioConfig
{
    public Guid? SelectedGoalSet { get; private set; }

    public ScenarioGoalMode GoalMode { get; private set; } = ScenarioGoalMode.Default;

    public enum ScenarioGoalMode
    {
        Default,
        Random,
        ManuallySelected
    }

    public void Reset()
    {
        SelectedGoalSet = null;
        GoalMode = ScenarioGoalMode.Default;
    }

    public void RandomGoal()
    {
        SelectedGoalSet = null;
        GoalMode = ScenarioGoalMode.Random;
    }

    public void DefaultGoal()
    {
        SelectedGoalSet = null;
        GoalMode = ScenarioGoalMode.Default;
    }

    public void ChooseGoal(Guid goalSetId)
    {
        SelectedGoalSet = goalSetId;
        GoalMode = ScenarioGoalMode.ManuallySelected;
    }
}