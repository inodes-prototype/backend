using PQGameEngine.Models.Game;
using PQGameEngine.Templates;

namespace PQGameEngine;

public static class ActionExcentions
{
    public static bool HasPredefinedAttackMask(this MainActionModel mainActionModel)
    {
        return mainActionModel.Template.HasPredefinedAttackMask();
    }

    public static bool HasPredefinedAttackMask(this ActionTemplate actionTemplate)
    {
        return !string.IsNullOrWhiteSpace(actionTemplate.PredefinedAttackMask);
    }
}