﻿namespace PQGameEngine;

public static class IRandomExtensions
{
    public static bool DidMyRollSucceed(this IRandom random, decimal chance, out decimal result)
    {
        result = random.Next(0, 100_00) / 100_00M;

        return chance > 0 && (result <= chance);
    }
}