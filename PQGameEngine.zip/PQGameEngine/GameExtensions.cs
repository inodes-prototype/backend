using PQGameEngine.Enums;
using PQGameEngine.Functionality;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;
using PQGameEngine.Models.Internal;
using PQGameEngine.Templates;

namespace PQGameEngine;

public static class GameExtensions
{
    public static ActorStatsHelper ActorStats(this GameInstance game) => new ActorStatsHelper(game);

    public static AttackStages Next(this AttackStages stage) => stage switch
    {
        AttackStages.None => AttackStages.Reconnaissance,
        AttackStages.Reconnaissance => AttackStages.InitialAccess,
        AttackStages.InitialAccess => AttackStages.Execution,
        AttackStages.Execution => AttackStages.Execution,
        _ => throw new ArgumentException($"Unknown attack stage {stage}"),
    };

    public static AttackStages Previous(this AttackStages stage) => stage switch
    {
        AttackStages.None => AttackStages.None,
        AttackStages.Reconnaissance => AttackStages.None,
        AttackStages.InitialAccess => AttackStages.Reconnaissance,
        AttackStages.Execution => AttackStages.InitialAccess,
        _ => throw new ArgumentException($"Unknown attack stage {stage}"),
    };

    public static bool Affects(this IAffectsActions affects, ActionTemplate actionTemplate) =>
        affects.Affects(actionTemplate);

    public static bool HaveAllDefendersCompletedTheirActions(this GameInstance game)
    {
        return game.TurnTrackers.Where(x => game.Defenders.ContainsKey(x.Key)).All(x => x.Value.HasFinishedItsTurn());
    }

    public static bool HaveAllAttackersCompletedTheirActions(this GameInstance game)
    {
        return game.TurnTrackers.Where(x => game.Attackers.ContainsKey(x.Key)).All(x => x.Value.HasFinishedItsTurn());
    }

    public static bool HaveAllAttackersDrawnNewActions(this GameInstance game)
    {
        return game.Attackers.All(x => GamePhaseHelper.HasActorDrawnActions(game, x.Value));
    }

    public static bool HaveAllDefendersDrawnNewActions(this GameInstance game)
    {
        return game.Defenders.All(x => GamePhaseHelper.HasActorDrawnActions(game, x.Value));
    }

    public static bool HaveAllPlayersDrawnNewActions(this GameInstance game)
    {
        return game.TurnTrackers.Values.All(x => x.ActionsDrawn);
    }

    public static void AddActorModifier(this ActionEvent activeEvent, ActorModel targetActor,
        ModifiableAttributes attribute, decimal value, EffectModel sourceEffect)
    {
        activeEvent.ActorModifiers.Add(new ActorModifier(targetActor.Id, attribute,
            value, activeEvent.Id, sourceEffect.Id));
    }
}