﻿namespace PQGameEngine.Exceptions;

public class PenQuestException : PenQuestBaseException
{
    public PenQuestException(Errors code, string message) : base($"[{code}] {message}")
    {
        Code = code;
    }

    public PenQuestException(PenQuestErrorInfo data) : this(data.Code, data.Message)
    {
    }

    public Errors Code { get; }
}