﻿using System.Runtime.Serialization;

namespace PQGameEngine.Exceptions;

public abstract class PenQuestBaseException : Exception
{
    protected PenQuestBaseException()
    {
    }

    protected PenQuestBaseException(string? message) : base(message)
    {
    }

    protected PenQuestBaseException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }

    protected PenQuestBaseException(string? message, Exception? innerException) : base(message, innerException)
    {
    }
}