﻿using PQGameEngine.Commands;

namespace PQGameEngine.Exceptions;

public class PenQuestInvalidCommandException : PenQuestBaseException
{
    public PenQuestInvalidCommandException(IBaseCommand command, string msg) : base(
        $"Invalid Command [{command.GetType()}] {msg}")
    {
    }
}