﻿namespace PQGameEngine.Exceptions;

public class PenQuestFatalException : PenQuestBaseException
{
    public PenQuestFatalException(string? message) : base("Fatal Error: " + message)
    {
    }
}