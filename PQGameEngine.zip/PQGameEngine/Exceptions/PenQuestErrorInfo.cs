﻿namespace PQGameEngine.Exceptions;

public class PenQuestErrorInfo
{
    public PenQuestErrorInfo(Errors code, string message)
    {
        Code = code;
        Message = message;
    }

    public Errors Code { get; }
    public string Message { get; }

    public override string ToString()
    {
        return $"[{Code}] {Message}";
    }
}