﻿namespace PQGameEngine.Exceptions;

public class PenQuestAggregateException : PenQuestBaseException
{
    public PenQuestAggregateException(List<PenQuestErrorInfo> errorInfos) : base(
        $"Multiple errors [{errorInfos.Count}]\n{string.Join("\n", errorInfos.Select(x => $"{x.Code} - {x.Message}"))}")
    {
        ErrorInfos = errorInfos;
    }

    public List<PenQuestErrorInfo> ErrorInfos { get; }
}