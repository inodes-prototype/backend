using PQGameEngine.Models.Game;
using PQGameEngine.Templates;

namespace PQGameEngine;

public static class EffectExtensions
{
    public static bool IsPermanentEffect(this EffectTemplate effect) => EffectModel.IsTemplatePermanentEffect(effect);

    public static bool IsPermanentEffect(this EffectModel effect) => IsPermanentEffect(effect.Template);

    public static bool IsIncDecEffect(this EffectTemplate effect) => EffectModel.IsTemplateIncDecEffect(effect);

    public static bool IsIncDecEffect(this EffectModel effect) => IsIncDecEffect(effect.Template);

    public static bool IsUnscopedEffect(this EffectTemplate effect) => EffectModel.IsTemplateUnscopedEffect(effect);

    public static bool IsUnscopedEffect(this EffectModel effect) => IsUnscopedEffect(effect.Template);
}