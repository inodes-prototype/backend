﻿using PQGameEngine.Enums;

namespace PQGameEngine.Templates;

public class ActorTemplate
{
    public ActorTemplate(
        int id,
        int soph,
        int det,
        int wealth,
        string name,
        string description,
        string wonText,
        string lostText,
        ActorTypes type
    )
    {
        if (id < 0 || id == Constants.DUNGEON_MASTER_ID)
            throw new ArgumentException($"Disallowed actor id {id}", nameof(id));

        Id = id;
        Soph = soph;
        Det = det;
        Wealth = wealth;
        Name = name;
        Description = description;
        WonText = wonText;
        LostText = lostText;
        Type = type;
    }

    public int Id { get; }
    public int Soph { get; }
    public int Det { get; }
    public int Wealth { get; }
    public string Name { get; }
    public string Description { get; }
    public string WonText { get; }
    public string LostText { get; }
    public ActorTypes Type { get; }
}