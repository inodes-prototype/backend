namespace PQGameEngine.Templates;

public class GoalSetTemplate(
    Guid id,
    string? description,
    GoalSummaryTemplate attackerSummary,
    GoalSummaryTemplate defenderSummary,
    List<GoalTemplate> goals,
    int? availableInitiative,
    int? initialInsightAttacker,
    int? initialInsightDefender,
    int? defenderPreSetupActionLimit)
{
    public Guid Id { get; } = id;
    public string? Description { get; } = description;
    public GoalSummaryTemplate AttackerSummary { get; } = attackerSummary;
    public GoalSummaryTemplate DefenderSummary { get; } = defenderSummary;
    public int? AvailableInitiative { get; } = availableInitiative;
    public int? InitialInsightAttacker { get; } = initialInsightAttacker;
    public int? InitialInsightDefender { get; } = initialInsightDefender;
    public int? DefenderPreSetupActionLimit { get; } = defenderPreSetupActionLimit;
    public List<GoalTemplate> Goals { get; } = [..goals];
}