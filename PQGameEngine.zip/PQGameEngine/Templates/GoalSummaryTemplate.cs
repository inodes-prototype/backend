namespace PQGameEngine.Templates;

public class GoalSummaryTemplate(string missionDescription, string goalDescription)
{
    public string MissionDescription { get; } = missionDescription;
    public string GoalDescription { get; } = goalDescription;
}