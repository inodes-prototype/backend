﻿using PQGameEngine.Enums;

namespace PQGameEngine.Templates;

public class ScenarioInfoTemplate(
    Guid id,
    string name,
    string description,
    ScenarioTypes type,
    List<ScenarioInfoTemplate.ScenarioActor> slots,
    ScenarioInfoTemplate.DefaultScenarioOptions? defaultScenarioOptions,
    Guid defaultGoalSetId,
    List<GoalSetTemplate> goalSets)
{
    public Guid Id { get; } = id;
    public string Name { get; } = name;
    public string Description { get; } = description;
    public List<ScenarioActor> Slots { get; } = slots;
    public DefaultScenarioOptions? DefaultOptions { get; } = defaultScenarioOptions;
    public Guid DefaultGoalSetId { get; } = defaultGoalSetId;
    public List<GoalSetTemplate> GoalSets { get; } = goalSets;
    public ScenarioTypes Type { get; } = type;

    public class ScenarioActor(int slotId, string name, ActorTypes type)
    {
        public int SlotId { get; } = slotId;
        public string Name { get; } = name;
        public ActorTypes Type { get; } = type;
        public string ConnectionId { get; set; } = null!;
    }

    public class DefaultScenarioOptions(
        GameOptionActionSuccessMode defaultActionSuccessMode,
        bool fixedActionSuccessMode,
        GameOptionActionDetectionMode defaultActionDetectionMode,
        bool fixedActionDetectionMode,
        GameOptionEquipmentShopMode defaultEquipmentShopMode,
        bool fixedEquipmentShopMode,
        GameOptionActionShopMode defaultActionShopMode,
        bool fixedActionShopMode,
        GameOptionSupportActionsMode defaultSupportActionsMode,
        bool fixedSupportActionsMode,
        GameOptionInitialAssetStage defaultInitialAssetStage,
        bool fixedInitialAssetStage,
        GameOptionInitActionsMode defaultInitialActionMode,
        bool fixedInitialActionMode,
        GameOptionManualDefType defaultManualDefTypeMode,
        bool fixedManualDefTypeMode,
        bool defaultInfiniteShields,
        bool fixedInfiniteShields,
        GameOptionMultiTargetSuccessMode defaultMultiTargetSuccess,
        bool fixedMultiTargetSuccess,
        GameOptionDefenderActionsDetectableMode defenderActionsDetectable,
        bool fixedDefenderActionsDetectable,
        GameOptionDefenderAvailabilityPenaltyMode availabilityPenalty,
        bool fixedAvailabilityPenalty,
        GameOptionDefenderPreSetupMode defenderPreSetupMode,
        bool fixedDefenderPreSetupMode)
    {
        public GameOptionActionSuccessMode DefaultActionSuccessMode { get; } = defaultActionSuccessMode;
        public bool FixedActionSuccessMode { get; } = fixedActionSuccessMode;
        public GameOptionActionDetectionMode DefaultActionDetectionMode { get; } = defaultActionDetectionMode;
        public bool FixedActionDetectionMode { get; } = fixedActionDetectionMode;
        public GameOptionEquipmentShopMode DefaultEquipmentShopMode { get; } = defaultEquipmentShopMode;
        public bool FixedEquipmentShopMode { get; } = fixedEquipmentShopMode;
        public GameOptionActionShopMode DefaultActionShopMode { get; } = defaultActionShopMode;
        public bool FixedActionShopMode { get; } = fixedActionShopMode;
        public GameOptionSupportActionsMode DefaultSupportActionsMode { get; } = defaultSupportActionsMode;
        public bool FixedSupportActionsMode { get; } = fixedSupportActionsMode;
        public GameOptionInitialAssetStage DefaultInitialAssetStage { get; } = defaultInitialAssetStage;
        public bool FixedInitialAssetStage { get; } = fixedInitialAssetStage;
        public GameOptionInitActionsMode DefaultInitialActionMode { get; } = defaultInitialActionMode;
        public bool FixedInitialActionMode { get; } = fixedInitialActionMode;
        public GameOptionManualDefType DefaultManualDefTypeMode { get; } = defaultManualDefTypeMode;
        public bool FixedManualDefTypeMode { get; } = fixedManualDefTypeMode;
        public bool DefaultInfiniteShields { get; } = defaultInfiniteShields;
        public bool FixedInfiniteShields { get; } = fixedInfiniteShields;
        public GameOptionMultiTargetSuccessMode DefaultMultiTargetSuccess { get; } = defaultMultiTargetSuccess;
        public bool FixedMultiTargetSuccess { get; } = fixedMultiTargetSuccess;

        public GameOptionDefenderActionsDetectableMode DefaultDefenderActionsDetectable { get; } =
            defenderActionsDetectable;

        public bool FixedDefenderActionsDetectable { get; } = fixedDefenderActionsDetectable;
        public GameOptionDefenderAvailabilityPenaltyMode DefaultAvailabilityPenalty { get; } = availabilityPenalty;
        public bool FixedAvailabilityPenalty { get; } = fixedAvailabilityPenalty;
        public GameOptionDefenderPreSetupMode DefaultDefenderPreSetupMode { get; } = defenderPreSetupMode;
        public bool FixedDefenderPreSetupMode { get; } = fixedDefenderPreSetupMode;
    }
}