﻿using PQGameEngine.Enums;

namespace PQGameEngine.Templates;

public class EffectTemplate(
    int id,
    EffectTypes type,
    string name,
    string description,
    EffectScopes scope,
    short? duration,
    short? numEffects,
    decimal? successChance,
    decimal? detectionChance,
    decimal? detectedChanceFailed,
    short? insight,
    decimal? credits,
    short? shieldStrength,
    List<EffectTemplate.GrantedEquipmentInfo>? grantEquipment,
    List<EffectTemplate.ShieldProbability>? shieldProbabilities,
    List<Guid>? compatibleActions)
{
    public int Id { get; } = id;
    public EffectTypes Type { get; } = type;
    public string Name { get; } = name;
    public string Description { get; } = description;

    public EffectTimingType Timing { get; } = type == EffectTypes.MODIFY_ACTION
        ? EffectTimingType.PreSuccess
        : EffectTimingType.PostSuccess;

    public EffectScopes Scope { get; } = scope;
    public short? Duration { get; } = duration < 0 ? null : duration;
    public short? NumEffects { get; set; } = numEffects;
    public decimal? SuccessChance { get; } = successChance;
    public decimal? DetectionChance { get; } = detectionChance;
    public decimal? DetectedChanceFailed { get; } = detectedChanceFailed;
    public short? Insight { get; } = insight;
    public decimal? Credits { get; } = credits;
    public short? ShieldStrength { get; set; } = shieldStrength;

    public short? Skill { get; } = null;

    public short? SkillReq { get; } = null;

    public List<GrantedEquipmentInfo> GrantEquipment { get; } = grantEquipment ?? [];
    public List<ShieldProbability> ShieldProbabilities { get; } = shieldProbabilities ?? [];

    public List<Guid> CompatibleActions { get; } = compatibleActions ?? [];

    public class ShieldProbability
    {
        public ShieldProbability(int turn, decimal proability)
        {
            Turn = turn;
            Proability = proability;
        }

        public int Turn { get; }
        public decimal Proability { get; }
    }

    public class GrantedEquipmentInfo
    {
        public GrantedEquipmentInfo(Guid equipmentId, decimal? dropChance)
        {
            EquipmentId = equipmentId;
            if (dropChance.HasValue)
            {
                if (dropChance.Value < 0)
                {
                    DropChance = 0;
                }
                else if (dropChance > 1)
                {
                    DropChance = 1;
                }
                else
                {
                    DropChance = dropChance;
                }
            }
        }

        public Guid EquipmentId { get; }
        public decimal? DropChance { get; }
    }
}