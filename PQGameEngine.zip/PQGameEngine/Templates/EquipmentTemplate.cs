﻿using PQGameEngine.Enums;
using PQGameEngine.Functionality;

namespace PQGameEngine.Templates;

public class EquipmentTemplate : IAffectsActions
{
    public Guid Id { get; }
    public EquipmentTypes Type { get; }
    public EquipmentSubTypes EquipmentType { get; }
    public string Name { get; }
    public string ShortDescription { get; }
    public string LongDescription { get; }
    public List<int> Effects { get; }
    public List<int> TransferEffects { get; }
    public decimal Price { get; }
    public EquipmentScopes InitialScope { get; }
    public HashSet<Guid> PossibleActions { get; }
    public HashSet<AssetCategories> PossibleAssetCategories { get; }
    public HashSet<AttackStages> PossibleAttackStages { get; }
    public HashSet<Oses> PossibleOses { get; }

    public HashSet<Guid> AffectedAttackActions { get; }
    public HashSet<Guid> AffectedDefenseActions { get; }

    public bool IsAttackEquipment => Type == EquipmentTypes.ATTACK_EQUIPMENT;
    public bool IsDefenseEquipment => Type == EquipmentTypes.DEFENSE_EQUIPMENT;

    public EquipmentTemplate(
        Guid id,
        EquipmentTypes type,
        EquipmentSubTypes equipmentType,
        string name,
        List<int> effects,
        decimal price,
        List<int> transferEffects,
        string shortDescription,
        string longDescription,
        HashSet<Guid> possibleActions,
        HashSet<AssetCategories> possibleAssetCategories,
        HashSet<AttackStages> possibleAttackStages,
        HashSet<Oses> possibleOses,
        EquipmentScopes initialScope,
        List<Guid> affectedAttackActions,
        List<Guid> affectedDefenseActions)
    {
        Id = id;
        Type = type;
        EquipmentType = equipmentType;
        Name = name;
        ShortDescription = shortDescription;
        LongDescription = longDescription;
        Effects = effects;
        TransferEffects = transferEffects;
        Price = price;
        InitialScope = initialScope;
        PossibleActions = [..possibleActions];
        PossibleAssetCategories = [..possibleAssetCategories];
        PossibleAttackStages = [..possibleAttackStages];
        PossibleOses = [..possibleOses];
        AffectedAttackActions = [..affectedAttackActions];
        AffectedDefenseActions = [..affectedDefenseActions];

        if (PossibleAssetCategories.Count == 0)
        {
            PossibleAssetCategories = Enum.GetValues<AssetCategories>().ToHashSet();
        }

        if (PossibleAttackStages.Count == 0)
        {
            PossibleAttackStages = Enum.GetValues<AttackStages>().ToHashSet();
        }

        if (PossibleOses.Count == 0)
        {
            PossibleOses = Enum.GetValues<Oses>().ToHashSet();
        }
    }
}