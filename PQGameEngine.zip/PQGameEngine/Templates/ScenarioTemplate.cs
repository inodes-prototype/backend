﻿using PQGameEngine.Enums;
using PQGameEngine.Exceptions;
using PQGameEngine.Factories;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Templates;

public class ScenarioTemplate
{
    private readonly Guid _defaultGoalSet;
    public GoalSetTemplate ActiveGoalSet { get; private set; } = default!;
    private readonly List<GoalSetTemplate> _goalSets;

    public Guid Id { get; }
    public string Name { get; }
    public string Description { get; }
    public Dictionary<int, ActorModel> Actors { get; }
    public Dictionary<int, ActorModel> Attackers { get; }
    public IReadOnlyCollection<BaseGoalModel> Goals { get; private set; }
    public Dictionary<int, ActorModel> Defenders { get; }
    public Dictionary<int, AssetModel> Assets { get; }
    public Dictionary<int, HashSet<int>> ActorToAssets { get; }
    public HashSet<int> InitialExposedAssets { get; }
    public HashSet<int> InitialVisibleAssets { get; }
    public HashSet<Guid> AttackerActionTemplates { get; }
    public HashSet<Guid> DefenderActionTemplates { get; }
    public Dictionary<Guid, ActionTemplate> ActionTemplates { get; }
    public HashSet<Guid> AttackerEquipmentTemplates { get; }
    public HashSet<Guid> DefenderEquipmentTemplates { get; }
    public Dictionary<Guid, EquipmentTemplate> EquipmentTemplates { get; }
    public Dictionary<int, EffectTemplate> EffectTemplates { get; }

    public int AddCustomEffect(Func<int, EffectTemplate> effectGenerator)
    {
        
        var nextFreeMinId = -1;

        if (EffectTemplates.Keys.Count > 0)
        {
            nextFreeMinId = Math.Min(0, EffectTemplates.Keys.Min(x => x)) - 1;
        }

        EffectTemplates.Add(nextFreeMinId, effectGenerator(nextFreeMinId));

        return nextFreeMinId;
    }

    public ScenarioTemplate(
        Guid id,
        string name,
        string description,
        List<ActorTemplate> actors,
        Guid defaultGoalSet,
        List<GoalSetTemplate> goalSets,
        List<AssetTemplate> assets,
        Dictionary<int, HashSet<int>> actorToAssets,
        List<ActionTemplate> actionTemplates,
        List<EquipmentTemplate> equipmentTemplates,
        List<EffectTemplate> effectTemplates)
    {
        _defaultGoalSet = defaultGoalSet;
        _goalSets = goalSets;

        Id = id;
        Name = name;
        Description = description;
        Attackers = new Dictionary<int, ActorModel>();
        Defenders = new Dictionary<int, ActorModel>();
        Actors = new Dictionary<int, ActorModel>();
        foreach (var t in actors)
        {
            var a = new ActorModel(t);
            Actors.Add(t.Id, a);
            if (a.IsAttacker)
            {
                Attackers.Add(t.Id, a);
            }
            else
            {
                Defenders.Add(t.Id, a);
            }
        }

        Assets = new Dictionary<int, AssetModel>();
        InitialExposedAssets = new HashSet<int>();
        InitialVisibleAssets = new HashSet<int>();
        foreach (var t in assets)
        {
            Assets.Add(t.Id, ModelFactories.CreateAsset(t));
            if (t.InitiallyExposed)
            {
                InitialExposedAssets.Add(t.Id);
            }

            if (t.InitiallyVisible)
            {
                InitialVisibleAssets.Add(t.Id);
            }
        }

        ActorToAssets = actorToAssets;
        ActionTemplates = [];
        AttackerActionTemplates = [];
        DefenderActionTemplates = [];

        foreach (var t in actionTemplates)
        {
            ActionTemplates.Add(t.Id, t);
            if (t.IsAttackAction)
            {
                AttackerActionTemplates.Add(t.Id);
            }

            if (t.IsDefenseAction)
            {
                DefenderActionTemplates.Add(t.Id);
            }
        }

        EquipmentTemplates = [];
        AttackerEquipmentTemplates = [];
        DefenderEquipmentTemplates = [];
        foreach (var t in equipmentTemplates)
        {
            EquipmentTemplates.Add(t.Id, t);
            if (t.IsAttackEquipment)
            {
                AttackerEquipmentTemplates.Add(t.Id);
            }

            if (t.IsDefenseEquipment)
            {
                DefenderEquipmentTemplates.Add(t.Id);
            }
        }

        EffectTemplates = new Dictionary<int, EffectTemplate>();
        foreach (var t in effectTemplates)
        {
            EffectTemplates.Add(t.Id, t);
        }

        foreach (var actorId in actorToAssets.Keys)
        {
            var actor = Actors[actorId];
            foreach (var assetId in actorToAssets[actorId])
            {
                var asset = Assets[assetId];
                asset.SetOwner(actor.Id);
                actor.OwnAssets.Add(assetId);
            }
        }

        
        if (Defenders.Count() != actorToAssets.Count)
        {
            throw new PenQuestFatalException("Amount of defenders does not match amount of asset groups");
        }
    }

    public void SetDefaultGoalSet() => SetActiveGoalSet(_defaultGoalSet);

    public void SetRandomGoalSet(IRandom random)
    {
        var r = random.Next(0, _goalSets.Count - 1);

        SetActiveGoalSet(_goalSets[r].Id);
    }

    public void SetActiveGoalSet(Guid id)
    {
        var goalSet = _goalSets.FirstOrDefault(x => x.Id == id);

        if (goalSet == null)
            throw new PenQuestFatalException($"Choosen goal {id} does not exist in scenario template {Id}");

        var attacker = Actors.Values.Single(x => x.IsAttacker);

        Goals = [];
        ActiveGoalSet = goalSet;

        var tList = new List<BaseGoalModel>();
        foreach (var t in goalSet.Goals)
        {
            BaseGoalModel gm = null;
            switch (t.GoalType)
            {
                case GoalTypes.AssetGoal:
                    gm = new AssetGoalModel(t);
                    break;
                case GoalTypes.ActorGoal:
                    gm = new ActorGoalModel(t);
                    break;
                case GoalTypes.DefenderNotExceedActorGoal:
                    gm = new DefenderNotExceededActorGoal(t);
                    break;
                default:
                    throw new PenQuestFatalException(
                        $"Invalid goal type {t.GoalType} in goal {t.GoalId} from goal set {goalSet.Id} of scenario {Id}");
            }

            gm.SetOwningActorId(attacker.Id);
            tList.Add(gm);
        }

        Goals = tList;
    }
}