﻿using PQGameEngine.Enums;
using PQGameEngine.Exceptions;
using PQGameEngine.Functionality;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Templates;

public class ActionTemplate : IAffectsActions
{
    public ActionTypes ActionType { get; }
    public ActionCategories ActionCategory { get; }
    public short ActionPointCost { get; }
    public Guid Id { get; }
    public string Name { get; }
    public int SophReq { get; }
    public DamageModel Impact { get; }
    public string ShortDescription { get; set; }
    public string LongDescription { get; set; }
    public bool RequireAdmin { get; }

    public short? CounterableDuring { get; }

    public List<Guid> RequiredEquipment { get; }

    public HashSet<Guid> AffectedAttackActions { get; }
    public HashSet<Guid> AffectedDefenseActions { get; }

    public List<int> Effects { get; }
    public HashSet<AssetCategories> AssetCategories { get; set; }
    public AttackStages AttackStage { get; set; }
    public HashSet<Oses> Oses { get; set; }
    public decimal SuccessChance { get; set; }
    public decimal DetectionChance { get; set; }
    public decimal DetectionChanceFailed { get; set; }
    public bool Detectable { get; set; }
    public TargetTypes TargetType { get; set; }
    public string PredefinedAttackMask { get; set; }
    public int DetectableDuring { get; set; }
    public List<int> TransferEffects { get; }
    public HashSet<Guid> ValidMainActions { get; }
    public DefenseActionType DefenseType { get; private set; }

    public bool IsAttackAction => ActionType == ActionTypes.Attack;
    public bool IsDefenseAction => ActionType == ActionTypes.Defense;
    public bool IsMainAction => ActionCategory == ActionCategories.MainAction;
    public bool IsSupportAction => ActionCategory == ActionCategories.SupportAction;

    public ActionTemplate(
        Guid id,
        ActionTypes actionType,
        string name,
        int sophReq,
        short impactC,
        short impactI,
        short impactA,
        string shortDescription,
        string longDescription,
        List<int> effects,
        List<AssetCategories> assetCategories,
        AttackStages attackStage,
        List<Oses> oses,
        decimal successChance,
        decimal detectionChance,
        decimal detectionChanceFailed,
        bool detectable,
        TargetTypes targetType,
        string predefinedAttackMask,
        int detectableDuring,
        List<int> transferEffects,
        HashSet<Guid> validMainActions,
        DefenseActionType defenseType,
        ActionCategories actionCategory,
        bool requireAdmin,
        short? counterableDuring,
        List<Guid> requiredEquipment,
        List<Guid> affectedAttackActions,
        List<Guid> affectedDefenseActions,
        short actionPointCost)
    {
        Id = id;
        ActionCategory = actionCategory;
        ActionType = actionType;
        Name = name;
        SophReq = sophReq;
        Impact = new DamageModel(impactC, impactI, impactA);
        ShortDescription = shortDescription;
        LongDescription = longDescription;
        Effects = effects ?? [];
        AssetCategories = [..assetCategories];
        AttackStage = attackStage;
        Oses = [..oses];
        SuccessChance = successChance;
        DetectionChance = detectionChance;
        DetectionChanceFailed = detectionChanceFailed;
        Detectable = detectable;
        TargetType = targetType;
        PredefinedAttackMask = predefinedAttackMask;
        DetectableDuring = detectableDuring;
        TransferEffects = transferEffects ?? [];
        ValidMainActions = validMainActions ?? [];
        DefenseType = defenseType;
        RequireAdmin = requireAdmin;
        CounterableDuring = counterableDuring;
        ActionPointCost = actionPointCost;
        RequiredEquipment = requiredEquipment ?? [];
        AffectedAttackActions = [..affectedAttackActions];
        AffectedDefenseActions = [..affectedDefenseActions];

        if (this.HasPredefinedAttackMask() &&
            !Constants.ValidAttackMasks.Contains(PredefinedAttackMask))
        {
            throw new PenQuestException(Errors.InvalidAttackMaskErrorFatal,
                $"Invalid attack mask '{PredefinedAttackMask}'");
        }
    }

    public void OverrideDefType(DefenseActionType defType)
    {
        DefenseType = defType;
    }

    public override string ToString()
    {
        return
            $"{Name} ({Id}), target_type: {TargetType} detectable: {Detectable}, SC: {SuccessChance} SDC: {DetectionChance} FDC: {DetectionChanceFailed}";
    }
}