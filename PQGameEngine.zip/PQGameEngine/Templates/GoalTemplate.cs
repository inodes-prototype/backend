﻿using PQGameEngine.Enums;

namespace PQGameEngine.Templates;

public class GoalTemplate(
    int goalId,
    GoalTypes goalType,
    string description,
    int? assetId,
    short? assetDmgC,
    short? assetDmgI,
    short? assetDmgA,
    short? assetExposedC,
    short? assetExposedI,
    short? assetExposedA,
    AttackStages? attackStage,
    short? targetInsight,
    decimal? targetCredits,
    int? roleDefenderId)
{
    public int GoalId { get; } = goalId;
    public GoalTypes GoalType { get; } = goalType;
    public string Description { get; } = description;
    public int? AssetId { get; } = assetId;
    public short? AssetDmgC { get; } = assetDmgC;
    public short? AssetDmgI { get; } = assetDmgI;
    public short? AssetDmgA { get; } = assetDmgA;
    public short? AssetExposedC { get; } = assetExposedC;
    public short? AssetExposedI { get; } = assetExposedI;
    public short? AssetExposedA { get; } = assetExposedA;
    public AttackStages? AttackStage { get; } = attackStage;
    public short? TargetInsight { get; } = targetInsight;
    public decimal? TargetCredits { get; } = targetCredits;
    public int? RoleDefenderId { get; } = roleDefenderId;
}