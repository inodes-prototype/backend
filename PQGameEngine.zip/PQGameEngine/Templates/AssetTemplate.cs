﻿using PQGameEngine.Enums;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Templates;

public class AssetTemplate
{
    public int Id { get; }
    public AttackStages StartingAttackStage { get; }
    public bool InitiallyExposed { get; }
    public bool InitiallyVisible { get; }
    public ExposedModel InitialExposedState { get; }

    public string Name { get; }
    public string Description { get; }
    public AssetCategories Category { get; }
    public Oses Os { get; }
    public int? ParentAssetId { get; }
    public HashSet<int> ChildAssetIds { get; }
    public decimal? Def3APenaltyCreditsPerRound { get; }
    public short? Def3APenaltyRoundsToLoose { get; }
    public bool Def3APenaltyNoIncome { get; }

    public HashSet<(int targetAssetId, DamageModel damage)> Dependencies { get; }

    public Dictionary<int, string> AttackVectors { get; }

    public AssetTemplate(
        int id,
        string name,
        string description,
        Oses os,
        List<(int targetAssetId, short dmgC, short dmgI, short dmgA)> dependencies,
        Dictionary<int, string> attackVectors,
        AssetCategories category,
        bool initiallyExposed,
        bool initiallyVisible,
        AttackStages initialAttackStage,
        int? parentAssetId,
        HashSet<int> childAssetIds,
        decimal? def3APenaltyCreditsPerRound,
        short? def3APenaltyRoundsToLoose,
        bool def3APenaltyNoIncome
    )
    {
        Id = id;
        StartingAttackStage = initialAttackStage;
        InitiallyExposed = initiallyExposed;
        InitiallyVisible = initiallyVisible;
        InitialExposedState = new ExposedModel(initiallyExposed, initiallyExposed, initiallyExposed);

        Name = name;
        Description = description;
        Category = category;
        Os = os;
        ParentAssetId = parentAssetId;
        ChildAssetIds = childAssetIds;
        Def3APenaltyCreditsPerRound = def3APenaltyCreditsPerRound;
        Def3APenaltyRoundsToLoose = def3APenaltyRoundsToLoose;
        Def3APenaltyNoIncome = def3APenaltyNoIncome;
        Dependencies = new HashSet<(int targetAssetId, DamageModel damage)>();
        if (dependencies != null!)
        {
            foreach (var d in dependencies)
            {
                Dependencies.Add((d.targetAssetId, new DamageModel(d.dmgC, d.dmgI, d.dmgA)));
            }
        }

        AttackVectors = attackVectors;
    }
}