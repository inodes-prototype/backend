﻿using PQGameEngine.Enums;

namespace PQGameEngine;

public static class Constants
{
    public const int DMG_MAX = 3;
    public const int DMG_MIN = -3;

    public const decimal GAME_ENGINE_SOPH_SUCCESS_IMPROVEMENT = 0.05M;
    public const decimal GAME_ENGINE_INS_SUCCESS_IMPROVEMENT = 0.02M;
    public const decimal GAME_ENGINE_INCOME_RATE = 0.1M;
    public const decimal GAME_ENGINE_START_CREDITS_PER_WEALTH = 5.0M;

    public const int GAME_ENGINE_EQUIPMENT_PER_SELECTION = 5;

    public const int GAME_ENGINE_ACTION_POINTS_PER_TURN_ATTACKER = 3;
    public const int GAME_ENGINE_ACTION_POINTS_PER_TURN_DEFENDER = 3;

    public const int GAME_ENGINE_ACTION_POINTS_MIN_VALUE = -2;

    public const ReplayedActionEffectBehaviour REPLAYED_ACTION_EFFECT_BEHAVIOUR =
        ReplayedActionEffectBehaviour.REFRESH;

    public const int DUNGEON_MASTER_ID = 0;

    public const string DEFAULT_SURRENDER_MESSAGE = "Your opponent(s) surrendered!";

    public const string DEFAULT_DRAW_MESSAGE_ATTACKER =
        "Your opponent went bust. You could not reach your goal since the defender was unable to restore their infrastructure in time.";

    public const string DEFAULT_DRAW_MESSAGE_DEFENDER =
        "This game has ended in defeat since you did not manage to keep your vital infrastructure up and running.";

    public static readonly HashSet<string> ValidAttackMasks = ["C", "I", "A", "CI", "IA", "CA", "CIA"];

    public const int NO_ASSET_ID = -1;

    public static Guid BOT_USER_ID = Guid.Parse("00000000-0000-0000-0000-000000000002");

    public const string GAME_EVENT_NAME_ERROR = "error";
    public const string GAME_EVENT_NAME_INFO = "info";

    public const string GAME_EVENT_NAME_GAME_CRASHED = "game_crashed";

    public const string GAME_EVENT_NAME_ACTIONS_DETECTED = "actions_detected";
    public const string GAME_EVENT_NAME_ACTIONS_RECEIVED = "actions_received";
    public const string GAME_EVENT_NAME_ACTION_PLAYABLE = "action_playable";
    public const string GAME_EVENT_NAME_GAME_STATE = "game_state";
    public const string GAME_EVENT_NAME_GAME_PLAYER_CHANGE = "game_player_changed";
    public const string GAME_EVENT_NAME_ACTION_SUCCESS = "action_success";
    public const string GAME_EVENT_NAME_ASSET_CHANGED = "asset_changed";
    public const string GAME_EVENT_NAME_ASSET_CHANGES = "asset_changes";
    public const string GAME_EVENT_NAME_ASSORTMENT_RECEIVED = "assortment_received";
    public const string GAME_EVENT_NAME_REMOVE_CARDS = "remove_cards";
    public const string GAME_EVENT_NAME_REMOVE_EQUIPMENT_FROM_SHOP = "remove_equipment_from_shop";
    public const string GAME_EVENT_NAME_ATTRIBUTE_CHANGED = "attribute_changed";
    public const string GAME_EVENT_NAME_EQUIPMENT_RECEIVED = "equipment_received";
    public const string GAME_EVENT_NAME_GAME_ENDED = "game_ended";
    public const string GAME_EVENT_NAME_GAMEPHASE_CHANGED = "game_phase_changed";
    public const string GAME_EVENT_NAME_GAMETURN_CHANGED = "game_turn_changed";
    public const string GAME_EVENT_NAME_GAME_STARTED = "game_started";
    public const string GAME_EVENT_NAME_OFFER_SELECTION = "offer_selection";
    public const string GAME_EVENT_NAME_PLAYER_LEFT = "player_left";
    public const string GAME_EVENT_NAME_UPDATE_PLAYER = "update_player";
    public const string GAME_EVENT_NAME_ACTIONS_PLAYABLE = "all_actions_playable";
    public const string GAME_EVENT_NAME_GAME_LEFT = "game_left";
    public const string GAME_EVENT_NAME_LOG_UPDATE = "eventlog_updated";
    public const string GAME_EVENT_NAME_ACTOR_DETECTED = "actor_detected";

    public const string GAME_EVENT_NAME_ACTION_POINTS_CHANGED = "action_points_changed";

    public const string VA_BONI_CODE_PREFIX_FROM_INSIGHT = "in";
    public const string VA_BONI_CODE_PREFIX_FROM_LOCAL_EQ = "le";
    public const string VA_BONI_CODE_PREFIX_FROM_SKILL = "sk";
    public const string VA_BONI_CODE_PREFIX_FROM_SUPPORT_ACTION = "sa";
    public const string VA_BONI_CODE_PREFIX_FROM_GLOBAL_PERM_EQ = "gp";
    public const string VA_BONI_CODE_PREFIX_FROM_LOCAL_PERM_EQ = "lp";
    public const string VA_BONI_CODE_PREFIX_FROM_PLAYED_ACTIONS = "pa";
    public const string VA_BONI_CODE_PREFIX_FROM_ASSET = "fa";
    public const string VA_BONI_CODE_PREFIX_FROM_ALWAYS_SUCCESS = "as";
    public const string VA_BONI_CODE_PREFIX_FROM_ALWAYS_DETECT = "ad";

    public const decimal XP_BOT_FACTOR = 0.5M;
    public const int XP_RECON_ACTIONS_SUCCESS = 10;
    public const int XP_RECON_ACTIONS_PARTIAL_SUCCESS = 5;
    public const int XP_RECON_ACTIONS_FAILED = 1;
    public const int XP_INITIAL_ACCESS_ACTIONS_SUCCESS = 20;
    public const int XP_INITIAL_ACCESS_ACTIONS_PARTIAL_SUCCESS = 10;
    public const int XP_INITIAL_ACCESS_ACTIONS_FAILED = 2;
    public const int XP_EXECUTION_ACTIONS_SUCCESS = 30;
    public const int XP_EXECUTION_ACTIONS_PARTIAL_SUCCESS = 15;
    public const int XP_EXECUTION_ACTIONS_FAILED = 3;
    public const int XP_DETECTION_ACTIONS_SUCCESS = 10;
    public const int XP_DETECTION_ACTIONS_PARTIAL_SUCCESS = 5;
    public const int XP_DETECTION_ACTIONS_FAILED = 1;
    public const int XP_PREVENTION_ACTIONS_SUCCESS = 20;
    public const int XP_PREVENTION_ACTIONS_PARTIAL_SUCCESS = 10;
    public const int XP_PREVENTION_ACTIONS_FAILED = 2;
    public const int XP_RESPONSE_ACTIONS_SUCCESS = 20;
    public const int XP_RESPONSE_ACTIONS_PARTIAL_SUCCESS = 10;
    public const int XP_RESPONSE_ACTIONS_FAILED = 2;
    public const int XP_EXPLOITS_FOUND = 5;
    public const int XP_EXPLOITS_USED = 5;
    public const int XP_EXPLOITS_FIXED = 10;
    public const int XP_CREDENTIALS_GATHERED = 5;
    public const int XP_ADMIN_GAINED = 10;
    public const int XP_ADMIN_REVOKED = 10;
    public const int XP_DAMAGE_CAUSED = 2;
    public const int XP_DAMAGE_HEALED = 2;
    public const int XP_DAMAGE_PREVENTED = 5;
    public const int XP_INSIGHT_GAINED = 5;
    public const int XP_INSIGHT_PREVENTED = 5;
    public const int XP_SYSTEM_COMPROMISED = 20;
    public const int XP_SYSTEM_COMPROMISE_MITIGATED = 20;
    public const int XP_GAME_WON = 200;
    public const decimal XP_AUTO_DEFEAT_ASSET_OFFLINE_FACTOR_ATTACKER = 0.75M;
    public const string ACTOR_ATTRIBUTE_TEXT_INSIGHT = "ins";
    public const string ACTOR_ATTRIBUTE_TEXT_INITIATIVE = "ini";
    public const string ACTOR_ATTRIBUTE_TEXT_CREDITS = "credits";
    public const string ACTOR_ATTRIBUTE_TEXT_WEALTH = "wealth";
    public const string ACTOR_ATTRIBUTE_TEXT_DETERMINATION = "det";
    public const string ACTOR_ATTRIBUTE_TEXT_SKILL = "soph";

    public const string COMMAND_BUY_EQUIPMENT = "buy_equipment";
    public const string COMMAND_GET_VALID_ACTIONS = "get_valid_actions";
    public const string COMMAND_LEAVE_GAME = "leave_game";
    public const string COMMAND_SURRENDER = "game_surrender";
    public const string COMMAND_PRESETUP_DONE = "game_preset_done";
    public const string COMMAND_TURN_FINISHED = "game_turn_finished";
    public const string COMMAND_PLAY_ACTION = "play_action";
    public const string COMMAND_PLAYER_DISCONNECTED = "player_disconnected";
    public const string COMMAND_RESUME_GAME = "resume_game";
    public const string COMMAND_SELECT_ACTIONS = "select_actions";
    public const string COMMAND_VALIDATE_ACTION = "validate_action";
}