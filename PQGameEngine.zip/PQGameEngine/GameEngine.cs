﻿using PQGameEngine.Commands;
using PQGameEngine.Enums;
using PQGameEngine.Exceptions;
using PQGameEngine.Factories;
using PQGameEngine.Functionality;
using PQGameEngine.Functionality.Effects;
using PQGameEngine.Functionality.GameboardLog;
using PQGameEngine.GameEventMessages.Outbound;
using PQGameEngine.Instances;
using PQGameEngine.Models.Datastore;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;
using PQGameEngine.Models.Internal;
using PQGameEngine.Utils;

namespace PQGameEngine;

public class GameEngineDependencies(
    ILoggerFactory loggerFactory,
    Notifier notifier,
    IDatastore datastore)
{
    public ILogger<GameEngine> Logger { get; } = loggerFactory.CreateLogger<GameEngine>();
    public Notifier Notifier { get; } = notifier;
    public IDatastore Datastore { get; } = datastore;
}

public sealed class GameEngine
{
    private readonly ILogger _logger;
    private readonly IDatastore _datastore;
    private readonly Notifier _notifier;
    private readonly IRandom _defaultRandom;
    private readonly GameEngineStore _gameEngineStore;
    private readonly GameEngineDependencies _geDeps;

    public GameEngine(ILoggerFactory loggerFactory, IDatastore datastore, Notifier notifier,
        IRandom defaultRandom, GameEngineStore gameEngineStore)
    {
        _logger = loggerFactory.CreateLogger<GameEngine>();
        _datastore = datastore;
        _notifier = notifier;
        _defaultRandom = defaultRandom;
        _gameEngineStore = gameEngineStore;
        _geDeps = new GameEngineDependencies(loggerFactory, notifier, _datastore);
    }

    public void HandleCommand(IInGameCommand command, GameInstance game)
    {
        try
        {
            if (command is BuyEquipmentCommand bec)
            {
                Buy(bec, game);
            }
            else if (command is PlayerDisconnectedCommand pdc)
            {
                PlayerDisconnected(pdc, game);
            }
            else if (command is PlayActionCommand pac)
            {
                PlayAction(pac, game);
            }
            else if (command is SurrenderCommand suc)
            {
                Surrender(suc, game);
            }
            else if (command is PresetupDoneCommand psd)
            {
                PresetDone(psd, game);
            }
            else if (command is GameTurnFinishedCommand gtf)
            {
                TurnFinished(gtf, game);
            }
            else if (command is ValidateActionCommand vac)
            {
                ValidateAction(vac, game);
            }
            else if (command is SelectActionsCommand sac)
            {
                SelectActions(sac, game);
            }
            else if (command is LeaveCommand lgc)
            {
                LeaveGame(lgc, game);
            }
            else if (command is ResumeGameCommand rgc)
            {
                ResumeGame(rgc, game);
            }
            else if (command is GetValidActionsCommand gvac)
            {
                GetValidActions(gvac, game);
            }
            else
            {
                throw new PenQuestInvalidCommandException(command, "Unknown command");
            }
        }
        catch (PenQuestBaseException e)
        {
            _logger.LogError(e, "Game Error");
            if (command is AbstractCommand ac)
            {
                _notifier.ReportErrors(ac, e);
            }
        }
        catch (Exception e)
        {
            if (game != null!)
            {
                GracefulGameExceptionHandler(game, e);
            }
            else
            {
                throw;
            }
        }
    }

    private void GracefulGameExceptionHandler(GameInstance game, Exception e)
    {
        foreach (var a in game.Actors.Values)
        {
            _notifier.ReportCrash(a.ConnectionId, a.UserId, Errors.GameCrashed, "Game crashed unexpectedly");
        }

        _gameEngineStore.Dispose(game);
        _datastore.DiscardGame(game.Id);

        _logger.LogError(e, "Game {GameId} Crashed - players notified - cleaned up store and Db", game.Id);
    }

    public void HandleCommand(IPreGameCommand command)
    {
        try
        {
            if (command is InternalStartGameCommand sgc)
            {
                CreateGame(sgc);
            }
            else
            {
                throw new PenQuestInvalidCommandException(command, "Unknown command");
            }
        }
        catch (PenQuestBaseException e)
        {
            _logger.LogError(e, "Game Error");
            if (command is AbstractCommand ac)
            {
                _notifier.ReportErrors(ac, e);
            }
        }
        catch (Exception e)
        {
            var instance = _gameEngineStore.TryGetInstanceByConnectionId(command.GetConnectionId());
            if (instance != null && instance is GameInstance game)
            {
                GracefulGameExceptionHandler(game, e);
            }
            else
            {
                throw;
            }
        }
    }

    private void RetrieveGameData(string connectionId, GameInstance game, out ActorModel actor)
    {
        actor = game.GetActorByConnectionId(connectionId);
    }

    private void ResumeGame(ResumeGameCommand rgc, GameInstance game)
    {
        var player = _datastore.GetRunningGamePlayer(rgc.Data.ConnectionIdToResume, rgc.Data.PlayerIdToResume);

        if (player == null)
            throw new PenQuestException(Errors.PlayerNotFoundError,
                $"Player ({rgc.Data.PlayerIdToResume}|{rgc.Data.ConnectionIdToResume}) not found");
        if (player.OnlineStatus == ConnectionStates.Online)
            throw new PenQuestException(Errors.PlayerNotOfflineError,
                $"Player ({rgc.Data.PlayerIdToResume}|{rgc.Data.ConnectionIdToResume}) is not offline");

        var actor = game.Actors.Values.FirstOrDefault(x =>
            x.ConnectionId == rgc.Data.ConnectionIdToResume && x.UserId == rgc.Data.PlayerIdToResume);

        if (actor == null)
            throw new PenQuestException(Errors.PlayerNotFoundError,
                $"Actor ({rgc.Data.PlayerIdToResume}|{rgc.Data.ConnectionIdToResume}) not found");
        if (actor.IsOnline)
            throw new PenQuestException(Errors.PlayerNotOfflineError,
                $"Actor ({rgc.Data.PlayerIdToResume}|{rgc.Data.ConnectionIdToResume}) is not offline");

        var user = _datastore.LoadAndEnsureUserExists(rgc.UserId);

        actor.ConnectPlayer(rgc.ConnectionId, user);
        actor.IsOnline = true;

        _gameEngineStore.MapConnectionTo(rgc.ConnectionId, game, rgc.SourceServiceId);
        _datastore.ReconnectGamePlayer(game.Id, rgc.Data.ConnectionIdToResume, rgc.ConnectionId, rgc.UserId, true);

        _notifier.GameState(actor, game, rgc.RequestId);
        _notifier.GamePlayerChanged(game.Actors.Values.Where(x => x.Id != actor.Id), game, actor,
            rgc.Data.ConnectionIdToResume, rgc.Data.PlayerIdToResume);
    }

    public void CreateGame(InternalStartGameCommand data)
    {
        var scenTemplate = _datastore.LoadScenario(data.ScenarioId);

        ScenarioHelper.Sanitize(scenTemplate, _logger);

        foreach (var (slotId, user) in data.Players)
        {
            if (scenTemplate.Actors.TryGetValue(slotId, out var actor))
            {
                if (!string.IsNullOrWhiteSpace(actor.ConnectionId))
                {
                    throw new PenQuestException(Errors.MissingActorsErrorFatal,
                        $"Actor {slotId} already taken by userId={user.User.Id}, connectionId={user.ConnectionId}");
                }

                actor.ConnectPlayer(user.ConnectionId, user.User);
            }
            else
            {
                throw new PenQuestException(Errors.MissingActorsErrorFatal,
                    $"Actor {slotId} does not exist in scenario {data.ScenarioId}");
            }
        }

        var rnd = _defaultRandom;
        if (data.Seed.HasValue)
        {
            rnd = new SeedableRandom(data.Seed.Value);
        }

        var game = new GameInstance(data.GameId, data.Code, scenTemplate, rnd, data.GameOptions, data.XpEventId);

        _gameEngineStore.ReplaceInstance(game);

        Start(game, data.ScenarioConfig);
    }

    private void Start(GameInstance game, ScenarioConfig scenarioConfig)
    {
        GameSetupHelper.SetupGame(game, _geDeps, scenarioConfig);

        _datastore.StartGame(new NewGameModel()
        {
            Id = game.Id,
            Code = game.Code,
            ScenarioId = game.Scenario.Id,
            Players = game.Actors.Values.Select(x => new NewGameModel.PlayerInfo()
            {
                UserId = x.UserId,
                ConnectionId = x.ConnectionId,
                RoleId = x.Id,
            }).ToList()
        });

        _notifier.GameStarted(game.Actors.Values.ToList(), game);
        game.GameboardLog.AddEntry(game.Actors.Values, GameboardLogMessageType.GameStarted, _ => { });

        GamePhaseHelper.BeginGame(game, _geDeps);

        _logger.LogInformation("Game {GameId} started", game.Id);
    }

    private void GetValidActions(GetValidActionsCommand gvac, GameInstance game)
    {
        RetrieveGameData(gvac.ConnectionId, game, out var actor);

        var assetProperties = ActionHelper.GetVisibileAssetProperties(game, actor);

        var resData = new List<AllActionsPlayableMessage.AllActionsPlayableMessageContent>();

        foreach (var combo in gvac.Data.Actions ?? [])
        {
            var t = new AllActionsPlayableMessage.AllActionsPlayableMessageContent(
                combo.ActionId, combo.SupportActionIds ?? [], combo.EquipmentIds ?? []);

            if (game.Actions[combo.ActionId] is not MainActionModel mainActionModel) continue;

            var validatedAction = new ValidatedAction(mainActionModel);
            if (combo.SupportActionIds != null)
            {
                validatedAction.SupportActions.AddRange(combo.SupportActionIds
                    .Select(x => game.Actions[x] as SupportActionModel).Where(x => x != null)!);
            }

            if (combo.EquipmentIds != null)
            {
                validatedAction.Equipment.AddRange(combo.EquipmentIds?.Select(x => game.Equipment[x]));
            }

            ActionValidationHelper.CombinationChecks(validatedAction);
            if (validatedAction.Errors.Count > 0)
            {
                t.IsPlayable = false;
                resData.Add(t);
                continue;
            }

            ActionValidationHelper.GameStateChecks(game, actor, validatedAction);
            if (validatedAction.Errors.Count > 0)
            {
                t.IsPlayable = false;
                resData.Add(t);
                continue;
            }

            ActionValidationHelper.RoleChecks(actor, validatedAction);
            if (validatedAction.Errors.Count > 0)
            {
                t.IsPlayable = false;
                resData.Add(t);
                continue;
            }

            ActionValidationHelper.RequirementChecks(game, actor, validatedAction);
            if (validatedAction.Errors.Count > 0)
            {
                t.IsPlayable = false;
                resData.Add(t);
                continue;
            }

            HashSet<int> possibleTargetIds = null;

            if (validatedAction.MainAction.TargetType == TargetTypes.Single)
            {
                if (!ActionHelper.ActionHasPossibleTarget(validatedAction.MainAction.Template, assetProperties,
                        out possibleTargetIds))
                {
                    t.IsPlayable = false;
                    resData.Add(t);
                    continue;
                }

                foreach (var supportAction in validatedAction.SupportActions)
                {
                    if (!ActionHelper.ActionHasPossibleTarget(supportAction.Template, assetProperties,
                            out var supportActionTargetIds))
                    {
                        possibleTargetIds.IntersectWith(supportActionTargetIds);
                    }
                }

                if (possibleTargetIds.Count == 0)
                {
                    t.IsPlayable = false;
                    resData.Add(t);
                    continue;
                }
            }
            else
            {
                possibleTargetIds = actor.VisibleAssets.ToHashSet();
            }

            ActionValidationHelper.CheckEffectValidity(game, actor, validatedAction);
            if (validatedAction.Errors.Count > 0)
            {
                t.IsPlayable = false;
                resData.Add(t);
                continue;
            }

            t.TargetableAssetIds = possibleTargetIds.ToList();

            if (validatedAction.MainAction.IsDefenseAction && validatedAction.MainAction is DefenseActionModel dam &&
                dam.DefType == DefenseActionType.Response)
            {
                t.PossibleResponseTargetIds = new Dictionary<int, List<int>>();

                foreach (var target in possibleTargetIds)
                {
                    var resTargetIds = GetPossibleResponseTargetIds(game, validatedAction.MainAction, actor,
                        game.Assets[target], validatedAction.MainAction.PredefinedAttackMask).CounterableActionIds;
                    t.PossibleResponseTargetIds.Add(target, resTargetIds);
                }
            }

            if (possibleTargetIds.Count > 0)
            {
                t.SuccessChance = 1;
                t.DetectionChance = 0;

                foreach (var target in possibleTargetIds)
                {
                    var chances = CalcVisibleChances(game, validatedAction.MainAction, validatedAction.SupportActions,
                        validatedAction.Equipment, actor, game.Assets[target]);
                    t.SuccessChance = Math.Min(chances.successChance.Chance, t.SuccessChance);
                    t.DetectionChance = Math.Max(chances.detectionChance.Chance, t.DetectionChance);
                }
            }
            else
            {
                var chances = CalcVisibleChances(game, validatedAction.MainAction, validatedAction.SupportActions,
                    validatedAction.Equipment, actor, null);
                t.SuccessChance = chances.successChance.Chance;
                t.DetectionChance = chances.detectionChance.Chance;
            }

            t.IsPlayable = true;
            resData.Add(t);
        }

        if (resData.All(x => x.IsPlayable == false))
        {
            _notifier.ReportErrors(gvac,
                new PenQuestException(Errors.NoPlayableActionError, "There are no playable Actions."));
        }
        else
        {
            _notifier.InformActionsPlayable(actor, gvac.RequestId, resData);
        }
    }

    private void PresetDone(PresetupDoneCommand cmd, GameInstance game)
    {
        RetrieveGameData(cmd.ConnectionId, game, out var actor);

        List<int> actionsToRemove = [..actor.Actions];
        actor.Actions.Clear();
        _notifier.RemoveCardsFromHand(actor, game, actionsToRemove, []);
        game.TurnTrackers[actor.Id].MarkTurnFinished();

        GamePhaseHelper.TryMoveGamePhase(game, _geDeps);
    }

    private void TurnFinished(GameTurnFinishedCommand cmd, GameInstance game)
    {
        RetrieveGameData(cmd.ConnectionId, game, out var actor);

        if (game.TurnTrackers[actor.Id].RemainingActionPoints >= game.TurnTrackers[actor.Id].TotalActionPointsThisTurn)
            throw new PenQuestException(Errors.MustHaveSpentAtLeastOneAp,
                "You can't end your turn before spending at least one action point");

        game.TurnTrackers[actor.Id].MarkTurnFinished();

        GamePhaseHelper.TryMoveGamePhase(game, _geDeps);
    }

    public void Buy(BuyEquipmentCommand cmd, GameInstance game)
    {
        RetrieveGameData(cmd.ConnectionId, game, out var actor);

        var equipmentIds = cmd.Data.Equipment ?? [];

        if (game.Phase == GamePhase.Ended)
        {
            throw new PenQuestException(
                Errors.GamePhaseMismatchError,
                $"Shopping requires game phase Shopping but current game phase is {game.Phase}"
            );
        }

        foreach (var equipmentId in equipmentIds)
        {
            if (!game.Shops[actor.Id].Contains(equipmentId))
            {
                throw new PenQuestException(
                    Errors.NotInShopError,
                    $"The required equipment {equipmentId} is currently not in shop for player {actor.Name}({actor.Id})"
                );
            }
        }

        var tGame = game;
        var sum = equipmentIds.Sum(t => tGame.EquipmentTemplates[t].Price);
        if (sum > actor.CurrentCredits)
        {
            throw new PenQuestException(
                Errors.NotEnoughCreditsError,
                $"Actor {actor} has not enough credits. Currently: {actor.CurrentCredits} Required: {sum}"
            );
        }

        List<EquipmentModel> equipmentList = [];
        foreach (var equipmentId in equipmentIds)
        {
            var template = game.EquipmentTemplates[equipmentId];

            if ((template.IsDefenseEquipment && actor.IsAttacker) ||
                (template.IsAttackEquipment && actor.IsDefender))
            {
                throw new PenQuestException(
                    Errors.EquipmentActorMismatchError,
                    "Type of Equipment and Role of Actor do not match."
                );
            }

            var equipment = ModelFactories.CreateEquipment(game, template, actor);
            actor.Equipment.Add(equipment.Id);
            var buyEvent = new EquipmentReceiveEvent(game.Turn, actor.Id, equipment.Id, game.Shops[actor.Id].ToList());
            game.AddEvent(buyEvent);
            actor.ChangeCredits(-template.Price, buyEvent.Id);
            equipmentList.Add(equipment);
            if (equipment.IsGlobalEquipment() && equipment.IsPermanentEquipment())
            {
                EquipmentHelper.ActivatePermanentEquipment(game, equipment, out _);
            }
        }

        _notifier.AttributeChanged(actor, ChangedPlayerAttributeType.Credits,
            Math.Round(actor.CurrentCredits, 2));
        game.GameboardLog.AddEntry(actor, GameboardLogMessageType.InfoCostTotal, c => c.SetCredits(sum));

        _notifier.EquipmentReceived(actor, game, equipmentList);
        game.Shops[actor.Id].RemoveAll(x => equipmentIds.Contains(x));
        _notifier.RemoveEquipmentFromShop(actor, game, equipmentIds);
        foreach (var equipment in equipmentList)
        {
            game.GameboardLog.AddEntry(actor, GameboardLogMessageType.InventoryAddedProcured, c => c
                .SetInfo(equipment)
                .SetCredits(equipment.Price));
            game.ActorStats().EquipmentBought(actor, equipment);
        }

        game.GameboardLog.PublishNewRecords(game, _notifier);

        _logger.LogDebug("{Actor} bought equipment {EquipmentList}", actor, equipmentList);
    }

    public void ValidateAction(ValidateActionCommand cmd, GameInstance game)
    {
        RetrieveGameData(cmd.ConnectionId, game, out var actor);

        var validatedAction = ActionValidationHelper.GetValidateAction(cmd.Data, game, actor);

        var responseTargetIds = new List<int>();
        var fullCounterInfos = new List<CounterableInfoRecord>();

        foreach (var t in validatedAction.Targets)
        {
            var counterInfos =
                GetPossibleResponseTargetIds(game, validatedAction.MainAction, actor, t, validatedAction.AttackMask);
            responseTargetIds.AddRange(counterInfos.CounterableActionIds);
            fullCounterInfos.AddRange(counterInfos.FullCounterableInfo);
        }

        if (DoesActionRequireResponseTargetId(validatedAction.MainAction) && responseTargetIds.Count == 0)
        {
            validatedAction.Warnings.Add(new PenQuestErrorInfo(Errors.NoResponseTargetAvailable,
                "There are no possible counterable actions - nothing will be healed!"));
        }

        ValidateActionChanceModel? vacmSuccess = null;
        ValidateActionChanceModel? vacmDetection = null;

        if (validatedAction.Targets.Count == 0)
        {
            var chances = CalcVisibleChances(game, validatedAction.MainAction, validatedAction.SupportActions,
                validatedAction.Equipment, actor, null);
            vacmSuccess = chances.successChance;
            vacmDetection = chances.detectionChance;
        }
        else
        {
            foreach (var t in validatedAction.Targets)
            {
                var chances = CalcVisibleChances(game, validatedAction.MainAction, validatedAction.SupportActions,
                    validatedAction.Equipment, actor, t);
                if (vacmSuccess == null || chances.successChance.Chance > vacmSuccess.Chance)
                {
                    vacmSuccess = chances.successChance;
                }

                if (vacmDetection == null || vacmDetection.Chance < chances.detectionChance.Chance)
                {
                    vacmDetection = chances.detectionChance;
                }
            }
        }

        _notifier.ActionPlayable(actor, game, validatedAction.IsPlayable, vacmSuccess, vacmDetection,
            validatedAction.Errors, validatedAction.Warnings, responseTargetIds, fullCounterInfos);
    }


    public void PlayAction(PlayActionCommand cmd, GameInstance game)
    {
        RetrieveGameData(cmd.ConnectionId, game, out var actor);

        var validatedAction = ActionValidationHelper.GetValidateAction(cmd.Data, game, actor);

        _logger.LogDebug(
            "{Actor} plays {Action} on {Targets} using {AttackMask} supported by {SupportedBy} equipped with {EquipmentPlayed}",
            actor, validatedAction.MainAction, validatedAction.Targets, validatedAction.AttackMask,
            validatedAction.SupportActions, validatedAction.Equipment);

        if (!validatedAction.IsPlayable)
        {
            var actionName = game.Actions[cmd.Data.MainActionId].Name;
            throw new PenQuestException(Errors.ActionNotPlayable,
                $"Action '{actionName}'({cmd.Data.MainActionId}) is not playable");
        }

        validatedAction.MainAction.SetPlayedInfo(actor.Id, validatedAction.AttackMask,
            validatedAction.SupportActions.Select(a => a.Id),
            validatedAction.Equipment.Select(eq => eq.Id));

        var assetTracker = AssetVisibilityTracker.Create(game);

        var result =
            PlayActionHelper.CreateAndPlayActionEvents(game, _geDeps, validatedAction.MainAction, actor,
                validatedAction.ResponseTargetId, validatedAction.Targets);

        var playedActionEvent = new PlayedActionEvent(game.Turn, actor.Id, result);
        game.AddEvent(playedActionEvent);

        actor.Actions.Remove(validatedAction.MainAction.Id);
        foreach (var supportAction in validatedAction.SupportActions)
        {
            actor.Actions.Remove(supportAction.Id);
        }

        foreach (var eq in validatedAction.Equipment)
        {
            actor.Equipment.Remove(eq.Id);
            game.ActorStats().UsedEquipment(actor, eq);
        }

        _notifier.RemoveCardsFromHand(actor, game,
            new List<int>(validatedAction.SupportActions.Select(x => x.Id)) { validatedAction.MainAction.Id },
            validatedAction.Equipment.Select(x => x.Id).ToList());

        game.TurnTrackers[actor.Id].PlayedAction(validatedAction.GetTotalActionPointCost());

        assetTracker.NotifyChanges(game, _notifier);

        _notifier.ActionsDetected(actor, game, [validatedAction.MainAction]);

        var actionSuccessState = ActionSuccessState.Failed;
        if (result.Any(x => x.Success)) actionSuccessState = ActionSuccessState.PartialSuccess;
        if (result.All(x => x.Success)) actionSuccessState = ActionSuccessState.Success;

        game.ActorStats().AddActionPlayed(actor, validatedAction.MainAction, actionSuccessState);

        _notifier.ActionSuccess(actor, game, actionSuccessState, validatedAction.MainAction,
            result.Select(x => x.Success).ToList());
        foreach (var res in result)
        {
            game.GameboardLog.AddEntry(game, actor, game.Events[res.ActionEventId]);
        }

        if (actor.UserId == Constants.BOT_USER_ID)
        {
            game.TurnTrackers[actor.Id].MarkTurnFinished();
        }

        if (game.Phase == GamePhase.DefenderPreSetup && actor.IsDefender && actor.Actions.Count == 0)
        {
            game.TurnTrackers[actor.Id].MarkTurnFinished();
        }

        GamePhaseHelper.TryMoveGamePhase(game, _geDeps);

        AssetHelper.NotifyAssetsChanged(game, _geDeps, actor.Type);
    }

    public void SelectActions(SelectActionsCommand cmd, GameInstance game)
    {
        RetrieveGameData(cmd.ConnectionId, game, out var actor);

        var selection = cmd.Data.Actions;

        if (selection.Any(x => x.Amount < 1))
            throw new PenQuestException(Errors.InvalidArgument, "Invalid amount selected");

        List<BaseActionModel> newActions = [];
        int requiredAmount;

        if (game.Options.SupportActionsMode == GameOptionSupportActionsMode.ALL_AT_START)
        {
            var tGame = game;
            var amountMainActions = actor.Actions.Count(aid => tGame.Actions[aid] is MainActionModel);
            requiredAmount = ActorHelper.GetActionLimit(game, actor) - amountMainActions;
        }
        else
        {
            requiredAmount = ActorHelper.GetActionLimit(game, actor) - actor.Actions.Count;
        }

        if (actor.IsAttacker && game.Phase.NotIn(GamePhase.Attack, GamePhase.InitDraw))
        {
            throw new PenQuestException(Errors.GamePhaseMismatchError,
                $"Game phase Attack is required for you to make a selection. Current game phase is {game.Phase}");
        }

        if (actor.IsDefender && game.Phase.NotIn(GamePhase.Defense, GamePhase.InitDraw, GamePhase.DefenderPreSetup))
        {
            throw new PenQuestException(Errors.GamePhaseMismatchError,
                $"Game phase Defense is required for you to make a selection. Current game phase is {game.Phase}");
        }

        if (actor.IsDefender && game.Phase == GamePhase.DefenderPreSetup)
        {
            if (ActorHelper.GetRemainingPreSetupActionsToDraw(game, actor) == 0)
            {
                throw new PenQuestException(Errors.NotAllowedError,
                    "Don't try to cheat me - you've already drawn enough");
            }
        }
        else
        {
            var actionsSelected = selection.Sum(x => x.Amount);
            if (actionsSelected != requiredAmount)
            {
                throw new PenQuestException(Errors.IndexError,
                    $"Wrong amount of actions. [{actionsSelected}/{requiredAmount}]");
            }
        }

        if (game.TurnTrackers[actor.Id].ActionsDrawn)
        {
            throw new PenQuestException(Errors.ActorHasAlreadyDrawnCards, "Cards have already been drawn");
        }

        foreach (var templateId in selection.Select(x => x.Id))
        {
            if (!game.TurnTrackers[actor.Id].ActionsOffered.Contains(templateId))
            {
                if (game.ActionTemplates.TryGetValue(templateId, out var template))
                {
                    throw new PenQuestException(Errors.IndexError,
                        $"Action {template.Name}({templateId}) was not offered");
                }

                throw new PenQuestException(Errors.IndexError, $"Action with ID {templateId} does not exist");
            }
        }

        var tSelection = selection.Select(x => (x.Id, x.Amount)).ToList();
        foreach (var template in tSelection)
        {
            for (var i = 0; i < template.Amount; i++)
            {
                BaseActionModel selectedAction =
                    ModelFactories.CreateAction(game, game.ActionTemplates[template.Id], actor);
                actor.Actions.Add(selectedAction.Id);
                game.AddEvent(new DrawActionEvent(game.Turn, actor.Id, selectedAction.Id, tSelection));
                newActions.Add(selectedAction);
            }
        }

        if (game.Options.SupportActionsMode == GameOptionSupportActionsMode.ALL_AT_START)
        {
            var currentTurnEvents = game.Journal[game.Turn];
            var missingSupportTids = new HashSet<Guid>();
            foreach (var eid in currentTurnEvents)
            {
                if (game.Events[eid] is ActionEvent actionEvent)
                {
                    if (actionEvent.MainAction.Actor == actor.Id)
                    {
                        foreach (int said in actionEvent.MainAction.SupportedBy)
                        {
                            SupportActionModel supportAction = (SupportActionModel)game.Actions[said];
                            missingSupportTids.Add(supportAction.TemplateId);
                        }
                    }
                }
            }

            foreach (var missingTid in missingSupportTids)
            {
                BaseActionModel missingAction =
                    ModelFactories.CreateAction(game, game.ActionTemplates[missingTid], actor);
                actor.Actions.Add(missingAction.Id);
                game.AddEvent(new DrawActionEvent(game.Turn, actor.Id, missingAction.Id, []));
                newActions.Add(missingAction);
            }
        }

        _logger.LogDebug("{Actor} added actions {Actions}", actor, newActions.Select(action => action.ToString()));

        _notifier.ActionsReceived(actor, newActions, game, cmd.RequestId);

        game.TurnTrackers[actor.Id].SetHasDrawn();

        GamePhaseHelper.TryMoveGamePhase(game, _geDeps);
    }

    private void PlayerDisconnected(PlayerDisconnectedCommand pdc, GameInstance game)
    {
        RetrieveGameData(pdc.ConnectionId, game, out var actor);

        _datastore.UpdateGamePlayerOnlineStatus(game.Id, actor.ConnectionId, false);

        actor.IsOnline = false;

        UpdatePlayerStatus(game, actor);
    }

    private (ValidateActionChanceModel successChance, ValidateActionChanceModel detectionChance) CalcVisibleChances(
        GameInstance game, MainActionModel action, List<SupportActionModel> supportActions,
        List<EquipmentModel> equipment, ActorModel actor, AssetModel? target)
    {
        var successChance = new ValidateActionChanceModel(action.SuccessChance);
        var detectionChance = new ValidateActionChanceModel(action.DetectionChance);

        foreach (var supportAction in supportActions)
        {
            foreach (var effectId in supportAction.Effects)
            {
                var effect = game.Effects[effectId];
                if (effect.IsIncDecEffect())
                {
                    if (effect.Template.SuccessChance.HasValue &&
                        EffectBehaviorFactory.Create(game, _geDeps, effect)
                            .CheckApply(action, EffectTimingType.PreSuccess))
                    {
                        successChance.AddBonusFromSupportAction(effect.Template.SuccessChance.Value,
                            supportAction.Name + " - " + effect.Template.Name, effect.Id, effect.Template.Id,
                            supportAction.Id, supportAction.Template.Id);
                    }

                    if (effect.Template.DetectionChance.HasValue &&
                        EffectBehaviorFactory.Create(game, _geDeps, effect)
                            .CheckApply(action, EffectTimingType.PreSuccess))
                    {
                        detectionChance.AddBonusFromSupportAction(effect.Template.DetectionChance.Value,
                            supportAction.Name + " - " + effect.Template.Name, effect.Id, effect.Template.Id,
                            supportAction.Id, supportAction.Template.Id);
                    }
                }
            }
        }

        foreach (var eq in equipment)
        {
            foreach (var effectId in eq.Effects)
            {
                var effect = game.Effects[effectId];
                if (effect.IsIncDecEffect())
                {
                    if (effect.Template.SuccessChance.HasValue &&
                        EffectBehaviorFactory.Create(game, _geDeps, effect)
                            .CheckApply(action, EffectTimingType.PreSuccess))
                    {
                        successChance.AddBonusFromLocalEq(effect.Template.SuccessChance.Value,
                            eq.Name + " - " + effect.Template.Name, effect.Id, effect.Template.Id, eq.Id,
                            eq.Template.Id);
                    }

                    if (effect.Template.DetectionChance.HasValue &&
                        EffectBehaviorFactory.Create(game, _geDeps, effect)
                            .CheckApply(action, EffectTimingType.PreSuccess))
                    {
                        detectionChance.AddBonusFromLocalEq(effect.Template.DetectionChance.Value,
                            eq.Name + " - " + effect.Template.Name, effect.Id, effect.Template.Id, eq.Id,
                            eq.Template.Id);
                    }
                }
            }
        }

        successChance.AddBonusFromSkill(ChanceHelper.GetSuccessModifierFromSkill(actor, action), "Skill Bonus");
        successChance.AddBonusFromInsight(ChanceHelper.GetSuccessModifierFromInsight(actor), "Insight Bonus");

        foreach (var eqId in actor.Equipment)
        {
            var eq = game.Equipment[eqId];
            if (eq.IsPermanentEquipment() && eq.Active && eq.Template.Affects(action.Template))
            {
                foreach (var effectId in eq.Effects)
                {
                    var effect = game.Effects[effectId];
                    if (effect.IsIncDecEffect())
                    {
                        if (effect.Template.SuccessChance.HasValue &&
                            EffectBehaviorFactory.Create(game, _geDeps, effect)
                                .CheckApply(action, EffectTimingType.PreSuccess))
                        {
                            successChance.AddBonusFromGlobalPermEq(effect.Template.SuccessChance.Value,
                                eq.Name + " - " + effect.Template.Name, effect.Id, effect.Template.Id, eq.Id,
                                eq.Template.Id);
                        }

                        if (effect.Template.DetectionChance.HasValue &&
                            EffectBehaviorFactory.Create(game, _geDeps, effect)
                                .CheckApply(action, EffectTimingType.PreSuccess))
                        {
                            detectionChance.AddBonusFromGlobalPermEq(effect.Template.DetectionChance.Value,
                                eq.Name + " - " + effect.Template.Name, effect.Id, effect.Template.Id, eq.Id,
                                eq.Template.Id);
                        }
                    }
                }
            }
        }

        if (target != null)
        {
            foreach (var eqId in target.InfluencedByEquipment)
            {
                var eq = game.Equipment[eqId];
                if (eq.IsPermanentEquipment() && eq.Active && eq.Template.Affects(action.Template))
                {
                    if (eq.PlayedWithAction.HasValue)
                    {
                        var mainAction = (MainActionModel)game.Actions[eq.PlayedWithAction.Value];
                        if (mainAction.ActionEvents.TryGetValue(target.Id, out var eventId))
                        {
                            var actionEvent = game.Events[eventId];

                            if (actionEvent is AssetActionEvent aae && aae.Detected.ContainsKey(actor.Id))
                            {
                                foreach (var effectId in eq.Effects)
                                {
                                    var effect = game.Effects[effectId];
                                    if (effect.IsIncDecEffect())
                                    {
                                        if (effect.Template.SuccessChance.HasValue &&
                                            EffectBehaviorFactory.Create(game, _geDeps, effect).CheckApply(action,
                                                EffectTimingType.PreSuccess))
                                        {
                                            successChance.AddBonusFromLocalPermEqOnAsset(
                                                effect.Template.SuccessChance.Value,
                                                eq.Name + " - " + effect.Template.Name, effect.Id, effect.Template.Id,
                                                eq.Id, eq.Template.Id);
                                        }

                                        if (effect.Template.DetectionChance.HasValue &&
                                            EffectBehaviorFactory.Create(game, _geDeps, effect).CheckApply(action,
                                                EffectTimingType.PreSuccess))
                                        {
                                            detectionChance.AddBonusFromLocalPermEqOnAsset(
                                                effect.Template.DetectionChance.Value,
                                                eq.Name + " - " + effect.Template.Name, effect.Id, effect.Template.Id,
                                                eq.Id, eq.Template.Id);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            foreach (var eventId in target.PlayedActionEvents)
            {
                var actionEvent = game.Events[eventId] as ActionEvent;
                if (actionEvent.Succeeded == true && actionEvent.Detected.ContainsKey(actor.Id))
                {
                    foreach (var effectId in actionEvent.Effects)
                    {
                        var effect = game.Effects[effectId];
                        if (effect.IsPermanentEffect() && effect.IsIncDecEffect())
                        {
                            if (effect.Template.SuccessChance.HasValue &&
                                EffectBehaviorFactory.Create(game, _geDeps, effect)
                                    .CheckApply(action, EffectTimingType.PreSuccess))
                            {
                                successChance.AddBonusFromPlayedActions(effect.Template.SuccessChance.Value,
                                    actionEvent.MainAction.Name + " - " + effect.Template.Name, effect.Id,
                                    effect.Template.Id, actionEvent.MainAction.Id, actionEvent.MainAction.Template.Id);
                            }

                            if (effect.Template.DetectionChance.HasValue &&
                                EffectBehaviorFactory.Create(game, _geDeps, effect)
                                    .CheckApply(action, EffectTimingType.PreSuccess))
                            {
                                detectionChance.AddBonusFromPlayedActions(effect.Template.DetectionChance.Value,
                                    actionEvent.MainAction.Name + " - " + effect.Template.Name, effect.Id,
                                    effect.Template.Id, actionEvent.MainAction.Id, actionEvent.MainAction.Template.Id);
                            }
                        }
                    }
                }
            }

            foreach (var effectId in target.GetActiveAssetSpecificEffects())
            {
                var effect = game.Effects[effectId];
                if (effect.IsIncDecEffect())
                {
                    if (effect.Template.SuccessChance.HasValue &&
                        EffectBehaviorFactory.Create(game, _geDeps, effect)
                            .CheckApply(action, EffectTimingType.PreSuccess))
                    {
                        successChance.AddBonusFromAsset(effect.Template.SuccessChance.Value,
                            "Boost/Penalty" + " - " + effect.Template.Name, effect.Id, effect.Template.Id, target.Id);
                    }

                    if (effect.Template.DetectionChance.HasValue &&
                        EffectBehaviorFactory.Create(game, _geDeps, effect)
                            .CheckApply(action, EffectTimingType.PreSuccess))
                    {
                        detectionChance.AddBonusFromAsset(effect.Template.DetectionChance.Value,
                            "Boost/Penalty" + " - " + effect.Template.Name, effect.Id, effect.Template.Id, target.Id);
                    }
                }
            }
        }

        if (game.Options.ActionSuccessMode == GameOptionActionSuccessMode.ALWAYS_SUCCESS ||
            game.Phase == GamePhase.DefenderPreSetup)
        {
            if (successChance.Chance < 1.0M)
            {
                var missingChanceTo100 = 1.0M - successChance.Chance;
                successChance.AddBonusFromAlwaySuccess(missingChanceTo100, "Game Option - Always Succeed");
            }
        }

        if (game.Options.ActionDetectionMode == GameOptionActionDetectionMode.ALWAYS_DETECT)
        {
            if (detectionChance.Chance < 1.0M)
            {
                var missingChanceTo100 = 1.0M - detectionChance.Chance;
                detectionChance.AddBonusFromAlwaysDetect(missingChanceTo100, "Game Option - Always detect");
            }
        }

        return (successChance, detectionChance);
    }

    private void Surrender(SurrenderCommand cmd, GameInstance game)
    {
        RetrieveGameData(cmd.ConnectionId, game, out var actor);

        if (game.Phase == GamePhase.Ended)
        {
            _notifier.SendInfo(actor, InfoType.InvalidCommand,
                $"Command '{cmd.GetCommandName()}' not allowed in game phase {game.Phase}");
            return;
        }

        actor.MarkSurrendered();
        game.GameboardLog.AddEntry(game.Actors.Values.Where(x => x.Id != actor.Id).ToList(),
            GameboardLogMessageType.PlayerSurrendered, c => c.SetInfo(actor));
        game.AddEvent(new PlayerSurrenderedEvent(game.Turn, actor.Id));

        GamePhaseHelper.EndGame(game, _geDeps);
    }

    private void LeaveGame(LeaveCommand cmd, GameInstance game)
    {
        if (string.IsNullOrWhiteSpace(cmd.Data.ConnectionIdToLeave))
        {
            RetrieveGameData(cmd.ConnectionId, game, out var actor);

            LeaveGame(game, actor, cmd.RequestId);
        }
        else
        {
            var player = _datastore.GetRunningGamePlayer(cmd.Data.ConnectionIdToLeave);

            if (player == null)
                throw new PenQuestException(Errors.PlayerNotFoundError,
                    $"Player ({cmd.Data.ConnectionIdToLeave}) not found");
            if (player.OnlineStatus == ConnectionStates.Online)
                throw new PenQuestException(Errors.PlayerNotOfflineError,
                    $"Player ({cmd.Data.ConnectionIdToLeave}) is not offline");

            var actor = game.Actors.Values.FirstOrDefault(x =>
                x.ConnectionId == cmd.Data.ConnectionIdToLeave && x.UserId == cmd.UserId);

            if (actor == null)
                throw new PenQuestException(Errors.PlayerNotFoundError,
                    $"Actor ({cmd.UserId}|{cmd.Data.ConnectionIdToLeave}) not found");
            if (actor.IsOnline)
                throw new PenQuestException(Errors.PlayerNotOfflineError,
                    $"Actor ({cmd.UserId}|{cmd.Data.ConnectionIdToLeave}) is not offline");

            if (actor.UserId != cmd.UserId)
            {
                _notifier.ReportErrors(cmd, new PenQuestException(Errors.PlayerNotInGameError, "Mismatching user id"));
                return;
            }

            if (cmd.Data.ConnectionIdToLeave != actor.ConnectionId)
            {
                _notifier.ReportErrors(cmd,
                    new PenQuestException(Errors.PlayerNotInGameError, "Mismatching connection ids"));
                return;
            }

            var user = _datastore.LoadAndEnsureUserExists(cmd.UserId);

            actor.ConnectPlayer(cmd.ConnectionId, user);

            LeaveGame(game, actor, cmd.RequestId);
        }
    }

    private void LeaveGame(GameInstance game, ActorModel actor, long? requestId)
    {
        if (!game.Actors.ContainsKey(actor.Id))
        {
            throw new PenQuestException(Errors.PlayerNotInGameError, $"Player {actor} not in game {game}");
        }

        if (game.Phase != GamePhase.Ended)
        {
            _datastore.RemovePlayerFromRunningGame(new PlayerLeftGameModel()
            {
                GameId = game.Id,
                UserId = actor.UserId,
                ConnectionId = actor.ConnectionId,
                ActorId = actor.Id,
                HasWon = false,
                UserLeft = true
            });
        }

        _notifier.PlayerLeft(game.Actors.Values.Where(x => x.Id != actor.Id), actor);

                var tConId = actor.ConnectionId;
        var tUserId = actor.UserId;

                _gameEngineStore.UnmapConnection(actor.ConnectionId);
        actor.HasLeft = true;
        actor.DisconnectPlayer();

                                if (game.Phase != GamePhase.Ended)
        {
            if (game.HaveAllAttackersLeft || game.HaveAllDefendersLeft)
            {
                GamePhaseHelper.EndGame(game, _geDeps);
            }
        }

                if (game.HaveAllPlayersLeft)
        {
            _gameEngineStore.Remove(game);
        }

                _notifier.GameLeft(tConId, tUserId, requestId);
    }


                        private void UpdatePlayerStatus(GameInstance game, ActorModel actor)
    {
        _notifier.UpdatePlayer(game.Actors.Values, actor);
        if (game.Phase == GamePhase.Ended)
        {
            LeaveGame(game, actor, null);
        }
    }

                                private (List<int> CounterableActionIds, List<CounterableInfoRecord> FullCounterableInfo)
        GetPossibleResponseTargetIds(GameInstance game, MainActionModel action, ActorModel actor,
            AssetModel asset, string attackMask)
    {
        var possibleResponseTargetIds = new List<int>();
        var responseTargetInfos = new List<CounterableInfoRecord>();

        if (attackMask == null)
        {
            attackMask = "CIA";
        }

        if (asset != null)
        {
                                                                                                if (DoesActionRequireResponseTargetId(action))
            {
                string selfAttackMask = attackMask ?? "";
                foreach (var eventId in asset.PlayedActionEvents)
                {
                    ActionEvent actionEvent = (ActionEvent)game.Events[eventId];
                    string otherAttackMaskSet = actionEvent.AttackMaskUsed ?? "";
                                        string intersectionAttackMask = new string(
                        selfAttackMask.Where(c => otherAttackMaskSet.Contains(c)).ToArray()
                    );
                    if (actionEvent is AssetActionEvent assetActionEvent &&
                        !assetActionEvent.FullyCountered &&
                        actionEvent.Detected.ContainsKey(actor.Id) &&
                        EventHelper.GetActiveDamage(game, assetActionEvent, actor).Any(impact => impact > 0) &&
                        (action.Template.AffectedAttackActions.Contains(actionEvent.MainAction.TemplateId) ||
                         action.Template.AffectedDefenseActions.Contains(actionEvent.MainAction.TemplateId)) &&
                        intersectionAttackMask.Length > 0 &&
                        action.CurrentImpact.ApplyMask(intersectionAttackMask).Any(impact => impact < 0))
                    {
                        if (assetActionEvent.IsCurrentlyCounterable(game))
                        {
                            possibleResponseTargetIds.Add(actionEvent.MainAction.Id);
                        }

                        var wasCounterable = assetActionEvent.WasCounterable(game);
                        if (assetActionEvent.IsCurrentlyCounterable(game) || wasCounterable)
                        {
                            responseTargetInfos.Add(
                                new CounterableInfoRecord(actionEvent.MainAction.Id, wasCounterable));
                        }
                    }
                }
            }
        }

        return (possibleResponseTargetIds, responseTargetInfos);
    }

    private bool DoesActionRequireResponseTargetId(BaseActionModel action) =>
        action.CurrentImpact.Any(impact => impact < 0);
}