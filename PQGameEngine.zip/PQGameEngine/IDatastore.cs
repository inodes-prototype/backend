﻿using PQGameEngine.Enums;
using PQGameEngine.Exceptions;
using PQGameEngine.GameEventMessages.MessageModels;
using PQGameEngine.Models.Datastore;
using PQGameEngine.Models.Internal;
using PQGameEngine.Templates;

namespace PQGameEngine;

public interface IDatastore
{
    void GameFinished(GameFinishedInfoModel gameFinishedInfo);
    void RemovePlayerFromRunningGame(PlayerLeftGameModel playerInfo);
    ScenarioTemplate LoadScenario(Guid scenarioId);
    void StartGame(NewGameModel newGameModel);

    UserModel? GetPqUser(Guid userId);

    void UpdateGamePlayerOnlineStatus(Guid id, string connectionId, bool isOnline);

    void ReconnectGamePlayer(Guid gameId, string oldConnectionId, string newConnectionId, Guid newPlayerId,
        bool isOnline);

    void DiscardGame(Guid id);
    RunningGamePlayerModel? GetRunningGamePlayer(string connectionId, Guid userId);
    RunningGamePlayerModel? GetRunningGamePlayer(string connectionId);

    void GrantXp(Guid userId, PostGameXpModel xpSummary, PlayerStatCounter gameActorStatCounter, ActorTypes actorType,
        GamePlayerEndState endState, Guid? xpEventId);

    UserModel LoadAndEnsureUserExists(Guid userId)
    {
        var user = GetPqUser(userId);

        if (user == null) throw new PenQuestException(Errors.PlayerNotFoundError, $"User ({userId}) not found");

        return user;
    }
}