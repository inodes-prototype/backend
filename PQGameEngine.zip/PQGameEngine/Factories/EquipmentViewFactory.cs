﻿using PQGameEngine.GameEventMessages.MessageModels;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;
using PQGameEngine.Templates;

namespace PQGameEngine.Factories;

public static class EquipmentViewFactory
{
    public static EquipmentViewModel Create(ActorModel receiver, GameInstance game, int? turn,
        EquipmentModel equipment,
        bool setUsedOn, bool setEquiptOn)
    {
        var eqView = new EquipmentViewModel(equipment.Id, equipment.TemplateId, equipment.EquipmentType.ToViewText(),
            equipment.Name, equipment.ShortDescription, equipment.LongDescription, equipment.Price, equipment.OwnerId);

        eqView.Effects = equipment.Effects.Select(x => EffectViewFactory.Create(receiver, game, turn, game.Effects[x]))
            .ToList();
        eqView.TransferEffects = equipment.TransferEffects
            .Select(x => EffectViewFactory.Create(receiver, game, turn, game.Effects[x])).ToList();
        eqView.PossibleActions = equipment.PossibleActions.ToList();
        eqView.Impact = DamageModel.Zero.ToViewDamage();
        eqView.IsSingleUse = equipment.IsSingleUseEquipment();
        eqView.IsPassiveEquipment = equipment.IsPassiveEquipment();

        if (equipment.IsSingleUseEquipment())
        {
            if (setUsedOn && equipment.UsedOn != null)
            {
                var @event = game.Events[equipment.UsedOn!.Value];

                if (@event is AssetActionEvent aae)
                {
                    eqView.UsedOnAsset = AssetViewFactory.Create(receiver, game, turn, game.Assets[aae.AssetId], false);
                }
                else if (@event is ActionEvent ae)
                {
                    eqView.UsedOnAction = ActionViewFactory.Create(receiver, game, turn, ae.MainAction);
                }
            }
        }

        if (equipment.IsPermanentEquipment())
        {
            eqView.IsActive = equipment.Active;

            if (setEquiptOn)
            {
                var isOn = equipment.EquiptOn;


                if (isOn is AssetModel at)
                {
                    eqView.UsedOnAsset = AssetViewFactory.Create(receiver, game, turn, at, false);
                }
            }
        }

        return eqView;
    }

    public static EquipmentTemplateViewModel Create(ActorModel receiver, GameInstance game, int? turn,
        EquipmentTemplate equipment, bool onlyBaseData = false)
    {
        var eqView = new EquipmentTemplateViewModel(equipment.Id, equipment.EquipmentType.ToViewText(),
            equipment.Name, equipment.ShortDescription, equipment.LongDescription, equipment.Price, -1);

        if (!onlyBaseData)
        {
            eqView.Effects = equipment.Effects
                .Select(x => EffectViewFactory.Create(receiver, game, turn, game.Scenario.EffectTemplates[x])).ToList();
            eqView.TransferEffects = equipment.TransferEffects.Select(x =>
                EffectViewFactory.Create(receiver, game, turn, game.Scenario.EffectTemplates[x])).ToList();
            eqView.PossibleActions = equipment.PossibleActions.ToList();
            eqView.Impact = DamageModel.Zero.ToViewDamage();
            eqView.IsSingleUse = equipment.IsSingleUseEquipment();
        }

        return eqView;
    }
}