﻿using PQGameEngine.Enums;
using PQGameEngine.Models.Game;
using PQGameEngine.Templates;

namespace PQGameEngine.Factories;

public static class Extensions
{
    public static int[] ToViewDamage(this DamageModel damage)
    {
        if (damage == null) return null;
        return [damage.C, damage.I, damage.A];
    }

    public static bool[] ToViewExposed(this ExposedModel exposed)
    {
        if (exposed == null) return null;
        return [exposed.C, exposed.I, exposed.A];
    }

    public static string? ToViewText(this GamePhase phase)
    {
        return phase switch
        {
            GamePhase.Starting => "Starting",
            GamePhase.InitDraw => "InitDraw",
            GamePhase.Attack => "Attack",
            GamePhase.Defense => "Defense",
            GamePhase.Ended => "Ended",
            GamePhase.DefenderPreSetup => "DefenderPreSetup",
            _ => null
        };
    }

    public static List<string> GetGoalDescription(this GoalSetTemplate goalSet, bool isAttacker)
    {
        var t = new List<string>();
        if (isAttacker)
        {
            if (!string.IsNullOrWhiteSpace(goalSet.AttackerSummary.GoalDescription))
            {
                t.Add(goalSet.AttackerSummary.GoalDescription);
            }

            t.AddRange(goalSet.Goals.Select(x => x.Description));
        }
        else
        {
            t.Add(goalSet.DefenderSummary.GoalDescription);
        }

        return t;
    }

    public static string GetMissionDescription(this GoalSetTemplate goalSet, bool isAttacker)
    {
        return isAttacker
            ? goalSet.AttackerSummary.MissionDescription
            : goalSet.DefenderSummary.MissionDescription;
    }
}