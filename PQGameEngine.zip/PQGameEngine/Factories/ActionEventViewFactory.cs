﻿using PQGameEngine.Functionality;
using PQGameEngine.GameEventMessages.MessageModels;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Factories;

public static class ActionEventViewFactory
{
    public static ActionEventViewModel Create(ActorModel receiver, GameInstance game, int? turn,
        ActionEvent actionEvent)
    {
        if (actionEvent.Detected.TryGetValue(receiver.Id, out var onTurn))
        {
            var aeView = new ActionEventViewModel();

            aeView.TurnDetected = onTurn;
            aeView.Succeeded = actionEvent.Succeeded == true;
            aeView.Deflected = actionEvent.Deflected;

            var deflectedBy = new List<ActionTemplateViewModel>();
            var deflectedDmg = DamageModel.Zero;
            foreach (var dd in actionEvent.DeflectedBy)
            {
                if (game.Events[dd.eventId] is ActionEvent dae)
                {
                    var a = ActionViewFactory.Create(receiver, game, turn, dae.MainAction.Template,
                        deflectedDmg: dd.deflectedDmg);
                    deflectedBy.Add(a);

                    deflectedDmg += dd.deflectedDmg;
                }
            }

            aeView.DeflectedBy = deflectedBy;
            aeView.DeflectedDamage = deflectedDmg.ToViewDamage();


            if (actionEvent is AssetActionEvent aae)
            {
                aeView.AssetId = aae.AssetId;
                aeView.CurrentAssetDamage = game.Assets[aae.AssetId].CurrentDamage.ToViewDamage();
                aeView.AppliedDependencyDamageToAssetIds = aae.AppliedDependencyDamage.Select(x => x.Key).ToList();
                aeView.DamageDealt = aae.DamageDealt.ToViewDamage();
                aeView.ActiveDamage = EventHelper.GetActiveDamage(game, aae, receiver).ToViewDamage();
                aeView.IsCounterable = aae.IsCounterable;
                aeView.LastTurnToCounter = aae.LastTurnToCounter;

                aeView.CounteredActionIds = aae.CounteredByEvents
                    .Where(eventId => game.Events[eventId] is ActionEvent ae && ae.Detected.ContainsKey(receiver.Id))
                    .Select(counter_event_id => (game.Events[counter_event_id] as ActionEvent).MainAction.Id)
                    .ToList();

                aeView.FullyCountered = aae.FullyCountered;
            }

            if (actionEvent is ActionEvent ae)
            {
                if (ae.Counters != null && game.Events[ae.Counters!.Value] is ActionEvent counteredActionEvent)
                {
                    aeView.CountersActionId = counteredActionEvent.MainAction.Id;
                }
            }

            return aeView;
        }

        return null;
    }
}