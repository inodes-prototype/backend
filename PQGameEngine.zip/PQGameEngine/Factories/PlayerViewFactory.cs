﻿using PQGameEngine.GameEventMessages.MessageModels;
using PQGameEngine.Instances;
using PQGameEngine.Models.Datastore;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.Internal;

namespace PQGameEngine.Factories;

public static class PlayerViewFactory
{
    public static PlayerViewModel Create(ActorModel receiver, GameInstance game, ActorModel actor)
    {
        return new PlayerViewModel(actor.Id, actor.ConnectionId, actor.Username, actor.AvatarId, actor.IsOnline,
            actor.UserId);
    }
}