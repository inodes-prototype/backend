﻿using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.Internal;
using PQGameEngine.Templates;

namespace PQGameEngine.Factories;

public static class ModelFactories
{
    public static BaseActionModel CreateAction(GameInstance game, ActionTemplate template, ActorModel owner)
    {
        BaseActionModel? am = null;

        if (template.IsMainAction)
        {
            am = new MainActionModel(game.GetNextActionId(), template, owner.Id,
                CreateEffects(game, template.Effects, owner, template.Id, null));
        }

        if (template.IsDefenseAction)
        {
            am = new DefenseActionModel(game.GetNextActionId(), template, owner.Id,
                CreateEffects(game, template.Effects, owner, template.Id, null));
        }

        if (template.IsSupportAction)
        {
            am = new SupportActionModel(game.GetNextActionId(), template, owner.Id,
                CreateEffects(game, template.Effects, owner, template.Id, null),
                CreateEffects(game, template.TransferEffects, owner, template.Id, null));
        }

        if (am == null)
        {
            throw new ArgumentException("Unknown action template provided");
        }

        game.Actions.Add(am.Id, am);

        return am;
    }

    public static EquipmentModel CreateEquipment(GameInstance game, EquipmentTemplate template, ActorModel owner)
    {
        var em = new EquipmentModel(game.GetNextEquipmentId(), template, owner.Id,
            CreateEffects(game, template.Effects, owner, null, template.Id),
            CreateEffects(game, template.TransferEffects, owner, null, template.Id));

        game.Equipment.Add(em.Id, em);

        return em;
    }

    public static List<int> CreateEffects(GameInstance game, IList<int> effectTemplateIds, ActorModel owner,
        Guid? actionTemplateSourceId, Guid? equipmentTemplateSourceId)
    {
        var ids = new List<int>();

        foreach (var effectTemplateId in effectTemplateIds)
        {
            ids.Add(CreateEffect(game, effectTemplateId, owner.Id, actionTemplateSourceId, equipmentTemplateSourceId));
        }

        return ids;
    }

    public static int CreateEffect(GameInstance game, int effectTemplateId, int owningActorId,
        Guid? actionTemplateSourceId, Guid? equipmentTemplateSourceId,
        CustomIsEffectApplicable? customCheckApply = null)
    {
        var effectTemplate = game.Scenario.EffectTemplates[effectTemplateId];

        var eid = game.GetNextEeffectId();

        var effect = new EffectModel(eid, effectTemplate, owningActorId, actionTemplateSourceId,
            equipmentTemplateSourceId, customCheckApply);

        game.Effects.Add(eid, effect);

        return eid;
    }

    public static AssetModel CreateAsset(AssetTemplate t)
    {
        return new AssetModel(t);
    }
}