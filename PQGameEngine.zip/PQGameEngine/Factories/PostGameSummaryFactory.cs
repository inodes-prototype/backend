using PQGameEngine.Enums;
using PQGameEngine.GameEventMessages.MessageModels;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Factories;

public static class PostGameSummaryFactory
{
    public static PostGameSummaryViewModel Create(GameInstance game, ActorModel actor, GamePlayerEndState endState)
    {
        var stats = game.ActorStatCounters[actor.Id];

        var summary = new PostGameSummaryViewModel
        {
            EndState = endState,
            TurnsPlayed = game.Turn,
            AttackerUndetectedTurns = game.Actors.Values.First(x => x.IsAttacker).FirstActionDetectedInTurn,
            ActionsPlayed = stats.ActionsPlayed,
            ActionsSucceeded = stats.ActionsPlayedSuccessfully,
            ActionsDetected = stats.ActionsDetected,
            MostValuableAction = GetMva(game, stats.Mva?.ActionId),
            DamageDealt = stats.DamageCaused,
            DamageHealed = stats.DamageHealed,
            EquipmentPurchased = stats.EquipmentBought,
            CreditsSpent = stats.CreditsSpent,
            CreditsSpentTotal = game.ActorStatCounters.Values.Sum(x => x.CreditsSpent),
            ActionHistory = CreateHistory(game),
        };

        return summary;
    }

    private static List<MainActionModel> GetPlayedActions(GameInstance game, ActorModel? actor = null)
    {
        return game.Events.Values
            .Where(x => x is ActionEvent ae && (actor == null || ae.Actor == actor.Id))
            .Cast<ActionEvent>()
            .Select(x => x.MainAction)
            .DistinctBy(x => x.Id)
            .ToList();
    }

    private static PostGameSummaryViewModel.MostValuableActionViewModel? GetMva(GameInstance game, int? actionId)
    {
        if (actionId == null) return null;

        var action = game.Actions[actionId.Value];

        return new PostGameSummaryViewModel.MostValuableActionViewModel
        {
            Id = action.Template.Id,
            Name = action.Name,
            Description = action.ShortDescription
        };
    }

    private static List<PostGameSummaryViewModel.ActionHistoryEntry> CreateHistory(GameInstance game)
    {
        var playedActions = GetPlayedActions(game);
        var list = new List<PostGameSummaryViewModel.ActionHistoryEntry>();

        foreach (var playedAction in playedActions)
        {
            var actionEvents = playedAction.ActionEvents.Values
                .Select(x => game.Events[x])
                .Where(x => x is ActionEvent)
                .Cast<ActionEvent>()
                .ToList();

            var assetActionEvents = actionEvents
                .Where(x => x is AssetActionEvent)
                .Cast<AssetActionEvent>()
                .ToList();

            var actor = game.Actors[actionEvents[0].Actor];

            var t = new PostGameSummaryViewModel.ActionHistoryEntry
            {
                Action = new PostGameSummaryViewModel.ActionHistoryEntry.ActionInfo
                {
                    Id = playedAction.Id,
                    TemplateId = playedAction.Template.Id,
                    Name = playedAction.Name,
                },
                Player = new PostGameSummaryViewModel.ActionHistoryEntry.PlayerInfo
                {
                    Name = actor.Name,
                    ActorType = actor.Type
                },
                Turn = (game.Events[playedAction.ActionEvents.Values.First()] as ActionEvent)!.Turn,
                Success = playedAction.TargetType == TargetTypes.Untargeted ? actionEvents[0].Succeeded : null,
                FirstRoundDetected = actionEvents[0].Detected.Where(a => a.Key != actionEvents[0].Actor)
                    .Select(a => a.Value).OrderBy(a => a).FirstOrDefault(),
                Targets = assetActionEvents.Select(x => new PostGameSummaryViewModel.ActionHistoryEntry.AssetTarget
                {
                    Id = x.AssetId,
                    Name = game.Assets[x.AssetId].Template.Name,
                    FirstRoundDetected = x.Detected.Where(a => a.Key != x.Actor).Select(a => a.Value).OrderBy(a => a)
                        .FirstOrDefault(),
                    Impact = new()
                    {
                        C = x.DamageDealt.C,
                        I = x.DamageDealt.I,
                        A = x.DamageDealt.A,
                    },
                    Success = x.Succeeded == true,
                    ExposedAssets = ToAssetTargetBaseList(game, x.ExposedAssets),
                    UnexposedAssets = ToAssetTargetBaseList(game, x.UnexposedAssets),
                    CompromisedTypes = x.CompromisedTypes,
                    UncompromisedTypes = x.UncompromisedTypes,
                    CredentialsGathered = x.GeneratedEquipment.Any(e =>
                        game.Equipment[e].Template.EquipmentType == EquipmentSubTypes.CREDENTIALS),
                    ExploitsFound = x.GeneratedEquipment.Any(e =>
                        game.Equipment[e].Template.EquipmentType == EquipmentSubTypes.EXPLOIT),
                }).ToList(),
            };

            list.Add(t);
        }

        return list;
    }

    private static List<PostGameSummaryViewModel.ActionHistoryEntry.AssetTargetBase> ToAssetTargetBaseList(
        GameInstance game, List<int> assetIds)
    {
        return assetIds.Select(a => game.Assets[a]).Select(a =>
            new PostGameSummaryViewModel.ActionHistoryEntry.AssetTargetBase()
            {
                Id = a.Id,
                Name = a.Template.Name
            }).ToList();
    }
}