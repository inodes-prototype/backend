using PQGameEngine.Functionality.GameboardLog;
using PQGameEngine.GameEventMessages.MessageModels;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Factories;

public static class GameboardLogEventViewFactory
{
    public static List<GameLogEvent> Create(ActorModel receiver, GameInstance game,
        IReadOnlyCollection<LogEntry> entries)
    {
        return entries.Select(x => Create(receiver, game, x)).ToList();
    }

    public static GameLogEvent Create(ActorModel receiver, GameInstance game, LogEntry entry)
    {
        return new GameLogEvent()
        {
            Type = entry.Type,
            Payload = entry.Payload,
            Created = entry.Created,
            Id = entry.Id,
        };
    }
}