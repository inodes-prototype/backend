﻿using PQGameEngine.GameEventMessages.MessageModels;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Factories;

public static class GoalViewFactory
{
    public static GoalViewModel Create(ActorModel receiver, GameInstance game, int? turn, BaseGoalModel goal)
    {
        var goalView = new GoalViewModel();

        if (goal is AssetGoalModel assetGoal)
        {
            goalView.Type = "asset_goal";
            goalView.Asset = assetGoal.AssetId > 0
                ? AssetViewFactory.Create(receiver, game, turn, game.Assets[assetGoal.AssetId], false)
                : null;
            goalView.Damage = assetGoal.Damage.ToViewDamage();
            goalView.Exposed = assetGoal.Exposed.ToViewExposed();
            goalView.AttackStage = assetGoal.AttackStage.ToViewText();
        }
        else if (goal is ActorGoalModel actorGoal)
        {
            goalView.Type = "asset_goal";
            goalView.Insight = actorGoal.Insight;
            goalView.Credits = actorGoal.Credits;
        }
        else if (goal is DefenderNotExceededActorGoal defenderNotExceededActor)
        {
            goalView.Type = "asset_goal";
            goalView.Insight = defenderNotExceededActor.Insight;
            goalView.Credits = defenderNotExceededActor.Credits;
            goalView.Defender = ActorViewFactory.Create(receiver, game, turn,
                game.Actors[defenderNotExceededActor.DefenderId], false);
        }
        else
        {
            throw new ArgumentException("Invalid goal type on goal id " + goal.Id + " in scenario " +
                                        game.Scenario.Id);
        }

        return goalView;
    }
}