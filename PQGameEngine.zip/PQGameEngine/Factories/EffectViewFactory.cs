﻿using PQGameEngine.Enums;
using PQGameEngine.GameEventMessages.MessageModels;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Templates;

namespace PQGameEngine.Factories;

public static class EffectViewFactory
{
    public static EffectViewModel Create(ActorModel receiver, GameInstance game, int? turn, EffectModel effect)
    {
        var effectView = Create(receiver, game, turn, effect.Template);

        effectView.OwnerId = effect.OwnerId;

        if (effect.IsPermanentEffect())
        {
            effectView.Active = effect.IsActive;
            effectView.Turns = effect.RemainingTurns;
        }

        if (effect.Template.Type == EffectTypes.DAMAGE_SHIELD || effect.Template.Type == EffectTypes.INSIGHT_PREVENTION)
        {
            effectView.Value = effect.Template.ShieldStrength.Value;
            if (effect.RemainingTurns > 0 && effect.Template.ShieldProbabilities.Count > 0)
            {
                effectView.Probability = effect.Template.ShieldProbabilities.FirstOrDefault(x =>
                        x.Turn == (effect.Template.Duration ?? EffectModel.MAX_EFFECT_TURNS) - effect.RemainingTurns +
                        1)
                    ?.Proability ?? 0;
            }
            else
            {
                effectView.Probability = 0;
            }
        }

        return effectView;
    }

    public static EffectViewModel Create(ActorModel receiver, GameInstance game, int? turn, EffectTemplate effect)
    {
        var effectView = new EffectViewModel(effect.Type, effect.IsPermanentEffect(),
            effect.Type.ToViewText(effect.Duration), effect.Id, effect.Name, effect.Description,
            effect.Scope.ToViewText(), 0);

        if (effect.IsIncDecEffect())
        {
            var a = new List<string>();

            if (effect.DetectionChance.HasValue)
            {
                effectView.Value = effect.DetectionChance.Value;
                a.Add("detection_chance");
            }

            if (effect.SuccessChance.HasValue)
            {
                effectView.Value = effect.SuccessChance.Value;
                a.Add("success_chance");
            }

            if (effect.Credits.HasValue)
            {
                effectView.Value = effect.Credits.Value;
                a.Add("credits");
            }

            if (effect.Insight.HasValue)
            {
                effectView.Value = effect.Insight.Value;
                a.Add("ins");
            }

            effectView.Attributes = a.ToArray();
        }

        if (effect.Type == EffectTypes.DAMAGE_SHIELD || effect.Type == EffectTypes.INSIGHT_PREVENTION)
        {
            effectView.Value = effect.ShieldStrength.Value;
            if (effect.ShieldProbabilities.Count > 0)
            {
                effectView.Probability = effect.ShieldProbabilities.OrderBy(x => x.Turn).First().Proability;
            }
            else
            {
                effectView.Probability = 0;
            }
        }

        if (effect.Type == EffectTypes.GRANT_EQUIPMENT)
        {
            effectView.GrantedEquipment = effect.GrantEquipment.Select(eq =>
                EquipmentViewFactory.Create(receiver, game, turn, game.EquipmentTemplates[eq.EquipmentId],
                    onlyBaseData: true)).ToList();
        }

        if (effect.Type == EffectTypes.STEAL_CREDITS)
        {
            effectView.Value = effect.Credits ?? 0;
        }

        return effectView;
    }
}