﻿using PQGameEngine.Functionality;
using PQGameEngine.GameEventMessages.MessageModels;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Factories;

public static class GameViewFactory
{
    public static GameViewModel Create(ActorModel receiver, GameInstance game, int? turn)
    {
        var gameView = new GameViewModel();

        gameView.ScenarioId = game.Scenario.Id;
        gameView.ScenarioName = game.Scenario.Name;
        gameView.ScenarioDescription = game.Scenario.Description;
        gameView.GamePhase = game.Phase.ToViewText();
        gameView.ActionsToSelect = ActorHelper.GetNumberOfActionsToDraw(game, receiver);
        gameView.Turn = game.Turn;

        gameView.Players = game.Actors.Values.Select(x => PlayerViewFactory.Create(receiver, game, x)).ToList();
        gameView.Actors = game.Actors.Values.ToDictionary(x => x.ConnectionId,
            x => ActorViewFactory.Create(receiver, game, turn, x, true));

        gameView.ActionsOffered = game.TurnTrackers?[receiver.Id].ActionsOffered
            .Select(x => ActionViewFactory.Create(receiver, game, turn, game.ActionTemplates[x])).ToList();

        gameView.GameboardLog =
            GameboardLogEventViewFactory.Create(receiver, game, game.GameboardLog.GetRecords(receiver));

        gameView.EquipmentShopOffer = game.Shops[receiver.Id]
            .Select(x => EquipmentViewFactory.Create(receiver, game, null, game.EquipmentTemplates[x])).ToList();

        return gameView;
    }
}