﻿using PQGameEngine.GameEventMessages.MessageModels;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;
using PQGameEngine.Templates;

namespace PQGameEngine.Factories;

public static class ActionViewFactory
{
    public static ActionViewModel Create(ActorModel receiver, GameInstance game, int? turn, BaseActionModel action)
    {
        var actionView = new ActionViewModel(action.Id,
            action.TemplateId,
            action.Name,
            action.ShortDescription,
            action.LongDescription,
            action.Template.Impact.ToViewDamage(),
            action.Template.SophReq,
            action.AssetCategories,
            action.AttackStage,
            action.Oses,
            action.Template.ActionPointCost);

        actionView.Effects = action.Effects.Select(x => EffectViewFactory.Create(receiver, game, turn, game.Effects[x]))
            .ToList();

        actionView.RequiresAdmin = action.Template.RequireAdmin;

        actionView.RequiredEquipment = action.Template.RequiredEquipment
            .Where(x => game.EquipmentTemplates.ContainsKey(x)).Select(x =>
                EquipmentViewFactory.Create(receiver, game, turn, game.EquipmentTemplates[x], true)).ToList();

        if (action.IsMainAction && action is MainActionModel ma)
        {
            actionView.CardType = "main";

            actionView.SuccessChance = action.Template.SuccessChance;
            actionView.DetectionChance = action.Template.DetectionChance;
            actionView.DetectionChanceFailed = action.Template.DetectionChanceFailed;

            actionView.TargetType = action.Template.TargetType.ToViewText();

            actionView.SupportedBy = ma.SupportedBy
                .Select(x => ActionViewFactory.Create(receiver, game, turn, game.Actions[x])).ToList();
            actionView.PlayedWithEquipment = ma.EquipmentPlayedWith.Select(x =>
                EquipmentViewFactory.Create(receiver, game, turn, game.Equipment[x], false, false)).ToList();

            actionView.PredefinedAttackMask = action.Template.PredefinedAttackMask;
            actionView.RequiredAttackMask = !action.Template.HasPredefinedAttackMask();
            actionView.AttackMaskUsed = ma.AttackMaskUsed;
            actionView.Actor = ma.Actor;

            actionView.Events = ma.ActionEvents
                .Where(x => game.Events[x.Value] is ActionEvent ae && ae.Detected.ContainsKey(receiver.Id)).Select(x =>
                    ActionEventViewFactory.Create(receiver, game, turn, game.Events[x.Value] as ActionEvent)).ToList();
        }
        else if (action.IsSupportAction && action is SupportActionModel sa)
        {
            actionView.CardType = "support";

            actionView.TransferEffects = sa.TransferEffects
                .Select(x => EffectViewFactory.Create(receiver, game, turn, game.Effects[x])).ToList();

            actionView.PossibleActions = sa.ValidMainActions.ToList();
        }

        if (action.IsDefenseAction && action is DefenseActionModel da)
        {
            actionView.CardType = "main";
            actionView.ActorType = "defense";
            actionView.DefType = da.DefType;
        }
        else
        {
            actionView.ActorType = "attack";
        }

        return actionView;
    }

    public static ActionTemplateViewModel Create(ActorModel actor, GameInstance game, int? turn,
        ActionTemplate action,
        DamageModel? deflectedDmg = null)
    {
        var actionView = new ActionTemplateViewModel(
            action.Id,
            action.Name,
            action.ShortDescription,
            action.LongDescription,
            action.Impact.ToViewDamage(),
            action.SophReq,
            action.AssetCategories,
            action.AttackStage,
            action.Oses,
            action.ActionPointCost);

        actionView.Effects = action.Effects
            .Select(x => EffectViewFactory.Create(actor, game, turn, game.Scenario.EffectTemplates[x])).ToList();

        actionView.RequiresAdmin = action.RequireAdmin;

        actionView.RequiredEquipment = action.RequiredEquipment.Where(x => game.EquipmentTemplates.ContainsKey(x))
            .Select(x => EquipmentViewFactory.Create(actor, game, turn, game.EquipmentTemplates[x], true)).ToList();

        if (action.IsMainAction)
        {
            actionView.CardType = "main";

            actionView.SuccessChance = action.SuccessChance;
            actionView.DetectionChance = action.DetectionChance;
            actionView.DetectionChanceFailed = action.DetectionChanceFailed;

            actionView.TargetType = action.TargetType.ToViewText();

            actionView.PredefinedAttackMask = action.PredefinedAttackMask;
            actionView.RequiredAttackMask = !action.HasPredefinedAttackMask();
        }
        else if (action.IsSupportAction)
        {
            actionView.CardType = "support";

            actionView.TransferEffects = action.TransferEffects
                .Select(x => EffectViewFactory.Create(actor, game, turn, game.Scenario.EffectTemplates[x])).ToList();

            actionView.PossibleActions = action.ValidMainActions.ToList();
        }

        if (action.IsDefenseAction)
        {
            actionView.CardType = "main";
            actionView.ActorType = "defense";
            actionView.DefType = action.DefenseType;
        }
        else
        {
            actionView.ActorType = "attack";
        }

        if (deflectedDmg.HasValue)
        {
            actionView.DeflectedDamage = deflectedDmg.Value.ToViewDamage();
        }

        return actionView;
    }
}