﻿using PQGameEngine.Enums;
using PQGameEngine.GameEventMessages.MessageModels;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Factories;

public static class AssetViewFactory
{
    public static AssetViewModel Create(ActorModel receiver, GameInstance game, int? turn, AssetModel asset,
        bool setPlayedActions)
    {
        var assetView = new AssetViewModel(asset.Id, asset.Template.Name, asset.Template.Category);

        if (receiver.VisibleAssets.Contains(asset.Id))
        {
            assetView.InitiallyExposed = asset.Template.InitiallyExposed;
            assetView.Os = asset.Template.Os;
            assetView.Description = asset.Template.Description;

            if (turn.HasValue && turn < game.Turn)
            {
                ExposedModel? lastExposedModel = null;

                foreach (var (exposedModel, eventId) in asset.ExposedHistory)
                {
                    if (eventId == null || game.Events[eventId].Turn <= turn.Value)
                    {
                        lastExposedModel = exposedModel;
                    }
                }

                if (lastExposedModel != null)
                {
                    assetView.Exposed = lastExposedModel.Value.ToViewExposed();
                }
                else
                {
                    assetView.Exposed = ExposedModel.NotExposed.ToViewExposed();
                }
            }
            else
            {
                assetView.Exposed = asset.CurrentExposedState.ToViewExposed();
            }

            var viewableDmg = DamageModel.Zero;

            foreach (var (dmgModel, eventId) in asset.DamageHistory)
            {
                if (turn.HasValue && game.Events[eventId].Turn <= turn.Value &&
                    game.Events[eventId] is ActionEvent ae && ae.Detected.ContainsKey(receiver.Id))
                {
                    viewableDmg = viewableDmg + dmgModel;
                }
            }

            assetView.Damage = viewableDmg.ToViewDamage();

            if (viewableDmg.I == 3 || receiver.Known3IDmgOnAssets.ContainsKey(asset.Id))
            {
                assetView.Dependencies = asset.Template.Dependencies.Select(v => v.targetAssetId).ToList();
                assetView.AttackVectors = asset.Template.AttackVectors?.Select(kvp => kvp.Key).ToList() ?? [];
                assetView.KnownAttackVectors = asset.Template.AttackVectors?.Select(x => new AttackVectorViewModel()
                {
                    TargetAssetId = x.Key,
                    ExposedMask = x.Value
                }).ToList();
                receiver.Known3IDmgOnAssets.TryAdd(asset.Template.Id, turn ?? 0);
            }

            var childAssets = new List<int>();
            foreach (var t in asset.Template.ChildAssetIds ?? [])
            {
                if (receiver.VisibleAssets.Contains(t) || receiver.KnownAssets.Contains(t))
                {
                    childAssets.Add(t);
                }
            }

            assetView.ChildAssets = childAssets;

            if (asset.Template.ParentAssetId.HasValue &&
                (receiver.VisibleAssets.Contains(asset.Template.ParentAssetId.Value) ||
                 receiver.KnownAssets.Contains(asset.Template.ParentAssetId.Value)))
            {
                assetView.ParentAssetId = asset.Template.ParentAssetId.Value;
            }

            var permanentEffects = new List<EffectViewModel>();
            var playedActions = new List<ActionViewModel>();

            var maxAtkStage = asset.InitialAttackStage;

            if (receiver.IsDefender)
            {
                maxAtkStage = maxAtkStage.Previous();
            }

            if (setPlayedActions)
            {
                foreach (var eventId in asset.PlayedActionEvents)
                {
                    var gameEvent = game.Events[eventId];

                    if (turn == null || gameEvent.Turn <= turn.Value)
                    {
                        if (gameEvent is ActionEvent ae && ae.Detected.ContainsKey(receiver.Id))
                        {
                            if (receiver.IsAttacker)
                            {
                                maxAtkStage = asset.CurrentAttackStage;
                            }
                            else if (receiver.IsDefender)
                            {
                                if (ae.IsAttackAction)
                                {
                                    if (ae.WasEffectiveAction() && maxAtkStage < ae.MainAction.AttackStage)
                                    {
                                        maxAtkStage = ae.MainAction.AttackStage;
                                    }
                                    else if (ae.Succeeded == false &&
                                             maxAtkStage < ae.MainAction.AttackStage.Previous())
                                    {
                                        maxAtkStage = ae.MainAction.AttackStage.Previous();
                                    }
                                }
                            }

                            if (asset.EventsGrantingAdminAccess.Contains(eventId))
                            {
                                assetView.HasAdminRights = true;
                            }

                            if (asset.EventsRevokingAdminAccess.Contains(eventId))
                            {
                                assetView.HasAdminRights = false;
                            }

                            playedActions.Add(ActionViewFactory.Create(receiver, game, turn, ae.MainAction));

                            foreach (var effectId in ae.Effects)
                            {
                                var effect = game.Effects[effectId];
                                if (effect.IsPermanentEffect() && effect.IsActive)
                                {
                                    if (effect.Template.Type == EffectTypes.DAMAGE_SHIELD)
                                    {
                                        assetView.ShieldActive = true;
                                    }

                                    permanentEffects.Add(EffectViewFactory.Create(receiver, game, turn, effect));
                                }
                            }
                        }
                    }
                }
            }

            assetView.PlayedActions = playedActions;
            assetView.PermanentEffects = permanentEffects;
            assetView.AttackStage = maxAtkStage;
        }
        else if (receiver.KnownAssets.Contains(asset.Id))
        {
            assetView.HasPreviouslyBeenSeen = true;

            assetView.InitiallyExposed = asset.Template.InitiallyExposed;
            assetView.Os = asset.Template.Os;
            assetView.Description = asset.Template.Description;

            assetView.Exposed = ExposedModel.NotExposed.ToViewExposed();
            assetView.Damage = DamageModel.Zero.ToViewDamage();

            assetView.PlayedActions = [];
            assetView.PermanentEffects = [];

            if (receiver.Known3IDmgOnAssets.ContainsKey(asset.Id))
            {
                assetView.Dependencies = asset.Template.Dependencies.Select(v => v.targetAssetId).ToList();
                assetView.AttackVectors = asset.Template.AttackVectors?.Select(kvp => kvp.Key).ToList() ?? [];
                assetView.KnownAttackVectors = asset.Template.AttackVectors?.Select(x => new AttackVectorViewModel()
                {
                    TargetAssetId = x.Key,
                    ExposedMask = x.Value
                }).ToList();
            }

            var childAssets = new List<int>();
            foreach (var t in asset.Template.ChildAssetIds ?? [])
            {
                if (receiver.VisibleAssets.Contains(t) || receiver.KnownAssets.Contains(t))
                {
                    childAssets.Add(t);
                }
            }

            assetView.ChildAssets = childAssets;

            if (asset.Template.ParentAssetId.HasValue &&
                (receiver.VisibleAssets.Contains(asset.Template.ParentAssetId.Value) ||
                 receiver.KnownAssets.Contains(asset.Template.ParentAssetId.Value)))
            {
                assetView.ParentAssetId = asset.Template.ParentAssetId.Value;
            }
        }

        var activeExploits = new List<EquipmentViewModel>();

        foreach (var eqId in asset.InfluencedByEquipment)
        {
            var eq = game.Equipment[eqId];

            if (eq.PlayedWithAction.HasValue)
            {
                var action = game.Actions[eq.PlayedWithAction.Value] as MainActionModel;

                var detected = false;

                foreach (var eventId in action!.ActionEvents.Values)
                {
                    if (game.Events[eventId] is ActionEvent ae && ae.Detected.ContainsKey(receiver.Id))
                    {
                        detected = true;
                        break;
                    }
                }

                if (detected)
                {
                    var ev = EquipmentViewFactory.Create(receiver, game, turn, eq, setUsedOn: false,
                        setEquiptOn: false);

                    if (eq.EquipmentType == EquipmentSubTypes.EXPLOIT)
                    {
                        activeExploits.Add(ev);
                    }
                }
            }
        }

        assetView.ActiveExploits = activeExploits;
        assetView.IsOffline = asset.IsOffline;

        if (receiver.Id == asset.Owner)
        {
            assetView.Dependencies = asset.Template.Dependencies?.Select(v => v.targetAssetId).ToList() ?? [];
            assetView.AttackVectors = asset.Template.AttackVectors?.Select(kvp => kvp.Key).ToList() ?? [];
            assetView.KnownAttackVectors = asset.Template.AttackVectors?.Select(x => new AttackVectorViewModel()
            {
                TargetAssetId = x.Key,
                ExposedMask = x.Value
            }).ToList();
            if (game.Options.AvailabilityPenalty == GameOptionDefenderAvailabilityPenaltyMode.Enabled)
            {
                assetView.PenaltyOfflineRounds = asset.Template.Def3APenaltyRoundsToLoose;
                if (asset.IsOffline)
                {
                    assetView.OfflineSinceTurn = game.Events[asset.LastEventIdCausing3ADamage].Turn;
                }
            }
        }

        return assetView;
    }
}