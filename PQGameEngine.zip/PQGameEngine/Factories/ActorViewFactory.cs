﻿using PQGameEngine.GameEventMessages.MessageModels;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Factories;

public static class ActorViewFactory
{
    private const int ATTRB_INS_BORDER = 5;

    public static ActorViewModel Create(ActorModel receiver, GameInstance game, int? turn, ActorModel actor,
        bool detailed)
    {
        var actorView = new ActorViewModel(actor.Id, actor.ConnectionId, actor.UserId, actor.AvatarId, actor.IsOnline,
            actor.Name)
        {
            ActorType = actor.Type,
        };

        if (actor.IsAttacker)
        {
            actorView.Type = "attacker";
            actorView.HasBeenDetected = actor.FirstActionDetected;
        }
        else if (actor.IsDefender)
        {
            actorView.Type = "defender";
        }
        else
        {
            throw new ArgumentException("Unsupported actor [" + actor.Id + "] type " + actor.Type +
                                        " in scenario " + game.Scenario.Id);
        }

        if (receiver.CurrentIns > ATTRB_INS_BORDER || receiver.ConnectionId == actor.ConnectionId)
        {
            actorView.Skill = AccumulateProperty(game, actor.InitialSoph, actor.HistorySoph, turn, receiver.Id,
                (a, b) => a + b);
            actorView.Determination = AccumulateProperty(game, actor.InitialDet, actor.HistoryDet, turn, receiver.Id,
                (a, b) => a + b);
            actorView.Wealth = AccumulateProperty(game, actor.InitialWealth, actor.HistoryWealth, turn, receiver.Id,
                (a, b) => a + b);
        }

        if (receiver.ConnectionId == actor.ConnectionId)
        {
            actorView.ActionPoints = game.TurnTrackers[actor.Id].RemainingActionPoints;
            actorView.Description = actor.Description;
            actorView.Insight = AccumulateProperty(game, actor.InitialIns, actor.HistoryIns, turn, receiver.Id,
                (a, b) => a + b);
            actorView.Initiative = AccumulateProperty(game, actor.InitialIni, actor.HistoryIni, turn, receiver.Id,
                (a, b) => a + b);
            actorView.Credits = AccumulateProperty(game, actor.InitialCredits, actor.HistoryCredits, turn, receiver.Id,
                (a, b) => a + b);
            if (actor.IsDefender)
            {
                actorView.InsightShield = actor.GetRemainingInsightShieldStrength();
            }

            if (detailed)
            {
                actorView.Actions = actor.Actions
                    .Select(x => ActionViewFactory.Create(receiver, game, turn, game.Actions[x])).ToList();
                actorView.Equipment = actor.Equipment.Select(x =>
                    EquipmentViewFactory.Create(receiver, game, turn, game.Equipment[x], true, true)).ToList();

                actorView.Assets = actor.OwnAssets
                    .Select(x => AssetViewFactory.Create(receiver, game, turn, game.Assets[x], true)).ToList();
                actorView.VisibleAssets = actor.VisibleAssets.Where(x => !actor.OwnAssets.Contains(x))
                    .Select(x => AssetViewFactory.Create(receiver, game, turn, game.Assets[x], true)).ToList();

                actorView.VisibleAssets.AddRange(actor.KnownAssets
                    .Where(x => !actor.VisibleAssets.Contains(x) && !actor.OwnAssets.Contains(x)).Select(x =>
                        AssetViewFactory.Create(receiver, game, turn, game.Assets[x], true)));

                if (actor.IsDefender)
                {
                }
                else if (actor.IsAttacker)
                {
                    actorView.Goals = game.GetGoalsOfActor(actor.Id).Select(x =>
                        GoalViewFactory.Create(receiver, game, turn, x)).ToList();
                }
                else
                {
                    throw new ArgumentException("Invalid actor type " + actor.Type);
                }

                actorView.MissionDescription = game.Scenario.ActiveGoalSet.GetMissionDescription(actor.IsAttacker);
                actorView.GoalDescription = game.Scenario.ActiveGoalSet.GetGoalDescription(actor.IsAttacker);
            }
        }

        return actorView;
    }

    private static T AccumulateProperty<T>(GameInstance game, T initialValue, List<(T, Guid)> history, int? turn,
        int? actorId, Func<T, T, T> sumFunc)
    {
        var t = initialValue;

        foreach (var (changeVal, eventId) in history)
        {
            if (game.Events.TryGetValue(eventId, out var @event) && @event is ActionEvent ae)
            {
                if (turn == null || turn.Value <= @event.Turn)
                {
                    if (actorId == null || ae.Detected.ContainsKey(actorId.Value))
                    {
                        t = sumFunc(t, changeVal);
                    }
                }
            }
            else
            {
                t = sumFunc(t, changeVal);
            }
        }

        return t;
    }

    private static T AccumulateProperty<T>(GameInstance game, T initialValue, List<(T, int)> history, int? turn,
        int? actorId, Func<T, T, T> sumFunc)
    {
        var t = initialValue;

        foreach (var (changeVal, eventId) in history)
        {
            t = sumFunc(t, changeVal);
        }

        return t;
    }
}