using PQGameEngine.Enums;
using PQGameEngine.GameEventMessages.MessageModels;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.Internal;

namespace PQGameEngine.Factories;

public static class PostGameXpFactory
{
    public static PostGameXpModel Create(GameInstance game, ActorModel actor, GamePlayerEndState endState)
    {
        var stats = game.ActorStatCounters[actor.Id];

        if (game.Actors.Values.All(x => x.UserId == actor.UserId))
            return new PostGameXpModel { XpDisabledReason = "played.vs.self" };

        var res = new PostGameXpModel();

        if (endState == GamePlayerEndState.Won)
        {
            res.XpDetails.Add("won", Constants.XP_GAME_WON);
        }
        else if (endState == GamePlayerEndState.AutoDefeatAssetOffline)
        {
            if (actor.IsAttacker)
            {
                res.XpDetails.Add("wonAssetOffline",
                    (int)(Constants.XP_GAME_WON * Constants.XP_AUTO_DEFEAT_ASSET_OFFLINE_FACTOR_ATTACKER));
            }
        }

        if (actor.IsAttacker)
        {
            res.XpDetails.Add("reconActions", Sum(stats.ReconActions,
                Constants.XP_RECON_ACTIONS_SUCCESS,
                Constants.XP_RECON_ACTIONS_PARTIAL_SUCCESS,
                Constants.XP_RECON_ACTIONS_FAILED));
            res.XpDetails.Add("initialAccessActions", Sum(stats.InitialAccessActions,
                Constants.XP_INITIAL_ACCESS_ACTIONS_SUCCESS,
                Constants.XP_INITIAL_ACCESS_ACTIONS_PARTIAL_SUCCESS,
                Constants.XP_INITIAL_ACCESS_ACTIONS_FAILED));
            res.XpDetails.Add("executionActions", Sum(stats.ExecutionActions,
                Constants.XP_EXECUTION_ACTIONS_SUCCESS,
                Constants.XP_EXECUTION_ACTIONS_PARTIAL_SUCCESS,
                Constants.XP_EXECUTION_ACTIONS_FAILED));

            res.XpDetails.Add("exploitsFound", stats.ExploitsFound * Constants.XP_EXPLOITS_FOUND);
            res.XpDetails.Add("exploitsUsed", stats.ExploitsUsed * Constants.XP_EXPLOITS_USED);
            res.XpDetails.Add("credentialsGathered", stats.CredentialsGathered * Constants.XP_CREDENTIALS_GATHERED);
            res.XpDetails.Add("adminGained", stats.AdminGained * Constants.XP_ADMIN_GAINED);
            res.XpDetails.Add("damageCaused", stats.DamageCaused * Constants.XP_DAMAGE_CAUSED);
            res.XpDetails.Add("systemCompromised", stats.SystemsCompromised.Count * Constants.XP_SYSTEM_COMPROMISED);
        }

        if (actor.IsDefender)
        {
            res.XpDetails.Add("detectionActions", Sum(stats.DetectionActions,
                Constants.XP_DETECTION_ACTIONS_SUCCESS,
                Constants.XP_DETECTION_ACTIONS_PARTIAL_SUCCESS,
                Constants.XP_DETECTION_ACTIONS_FAILED));
            res.XpDetails.Add("preventionActions", Sum(stats.PreventionActions,
                Constants.XP_PREVENTION_ACTIONS_SUCCESS,
                Constants.XP_PREVENTION_ACTIONS_PARTIAL_SUCCESS,
                Constants.XP_PREVENTION_ACTIONS_FAILED));
            res.XpDetails.Add("responseActions", Sum(stats.ResponseActions,
                Constants.XP_RESPONSE_ACTIONS_SUCCESS,
                Constants.XP_RESPONSE_ACTIONS_PARTIAL_SUCCESS,
                Constants.XP_RESPONSE_ACTIONS_FAILED));

            res.XpDetails.Add("exploitsFixed", stats.ExploitsFixed * Constants.XP_EXPLOITS_FIXED);
            res.XpDetails.Add("adminRevoked", stats.AdminRevoked * Constants.XP_ADMIN_REVOKED);
            res.XpDetails.Add("damageHealed", stats.DamageHealed * Constants.XP_DAMAGE_HEALED);
            res.XpDetails.Add("damagePrevented", stats.DamagePrevented * Constants.XP_DAMAGE_PREVENTED);
            res.XpDetails.Add("insightPrevented", stats.InsightPrevented * Constants.XP_INSIGHT_PREVENTED);
            res.XpDetails.Add("systemCompromiseMitigated",
                stats.CompromisedSystemsMitigated.Count * Constants.XP_SYSTEM_COMPROMISE_MITIGATED);
        }

        res.XpDetails.Add("insightGained", stats.InsightGained * Constants.XP_INSIGHT_GAINED);

        if (game.Actors.Values.Any(x => x.IsBot()))
        {
            foreach (var t in res.XpDetails.Keys)
            {
                res.XpDetails[t] = (int)(res.XpDetails[t] * Constants.XP_BOT_FACTOR);
            }
        }

        res.Sum = res.XpDetails.Values.Sum();

        return res;
    }

    private static int Sum(PlayerStatCounter.ActionPlayedCounter t, int xpSuccess, int xpPartial, int xpFailed)
    {
        return t.Success * xpSuccess + t.PartialSuccess * xpPartial + t.Failed * xpFailed;
    }
}