﻿namespace PQGameEngine.GameEventMessages.Inbound;

public class SelectActionEvent : ICommandEventArgs
{
    public List<SelectedAction> Actions { get; set; } = default!;

    public class SelectedAction
    {
        public Guid Id { get; set; }
        public int Amount { get; set; }
    }
}