﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Inbound;

public class BuyEquipmentEvent : ICommandEventArgs
{
    [JsonPropertyName("equipment")]
    public List<Guid>? Equipment { get; set; }
}