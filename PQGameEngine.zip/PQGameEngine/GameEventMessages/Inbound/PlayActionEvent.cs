﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Inbound;

public class PlayActionEvent : ICommandEventArgs
{
    [JsonPropertyName("action_id")]
    public int MainActionId { get; set; }

    [JsonPropertyName("target_asset_id")]
    public int? TargetId { get; set; }

    [JsonPropertyName("attack_mask")]
    public string? AttackMask { get; set; }

    [JsonPropertyName("equipment_ids")]
    public List<int>? EquipmentIds { get; set; }

    [JsonPropertyName("support_action_ids")]
    public List<int>? SupportActionIds { get; set; }

    [JsonPropertyName("response_target_id")]
    public int? ResponseTargetId { get; set; }
}