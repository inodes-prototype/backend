﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Inbound;

public class ResumeGameEvent : ICommandEventArgs
{
    [JsonPropertyName("connection_id")]
    public string ConnectionIdToResume { get; set; }

    [JsonPropertyName("player_id")]
    public Guid PlayerIdToResume { get; set; }
}