﻿namespace PQGameEngine.GameEventMessages.Inbound;

public interface ICommandEventArgs
{
}