﻿using System.Text.Json.Serialization;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Inbound;

public class StartBotGameEvent : ICommandEventArgs
{
    [JsonPropertyName("amount_games")]
    public int? GamesToCreate { get; set; }

    [JsonPropertyName("attacker")]
    public short? BotTypeAttacker { get; set; }

    [JsonPropertyName("defender")]
    public short? BotTypeDefender { get; set; }

    [JsonPropertyName("scenario")]
    public Guid? ScenarioIdToCreate { get; set; }

    [JsonPropertyName("options")]
    public GameOptionsViewModel? Options { get; set; }
}