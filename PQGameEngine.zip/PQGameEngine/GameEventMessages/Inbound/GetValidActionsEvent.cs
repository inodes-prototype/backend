﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Inbound;

public class GetValidActionsEvent : ICommandEventArgs
{
    [JsonPropertyName("actions")]
    public List<ValidAction>? Actions { get; set; }

    public class ValidAction
    {
        [JsonPropertyName("action_id")]
        public int ActionId { get; set; }

        [JsonPropertyName("support_action_ids")]
        public List<int>? SupportActionIds { get; set; }

        [JsonPropertyName("equipment_ids")]
        public List<int>? EquipmentIds { get; set; }
    }
}