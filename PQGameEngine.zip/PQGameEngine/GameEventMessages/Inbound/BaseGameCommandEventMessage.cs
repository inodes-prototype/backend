﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Inbound;

public class BaseGameCommandEventMessage : ICommandEventArgs
{
    [JsonPropertyName("event")]
    public string Event { get; set; }

    [JsonPropertyName("request_id")]
    public long RequestId { get; set; }

    [JsonPropertyName("data")]
    public object Data { get; set; }
}