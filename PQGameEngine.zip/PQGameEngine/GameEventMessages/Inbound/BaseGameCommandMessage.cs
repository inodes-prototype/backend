﻿using System.Text.Json;

namespace PQGameEngine.GameEventMessages.Inbound;

public class BaseGameCommandMessage(
    string source,
    Guid userId,
    string connectionId,
    JsonElement data,
    Guid? sourceServiceId)
{
    public string Source { get; } = source;
    public Guid UserId { get; } = userId;
    public string ConnectionId { get; } = connectionId;
    public JsonElement Data { get; } = data;
    public Guid? SourceServiceId { get; } = sourceServiceId;
}