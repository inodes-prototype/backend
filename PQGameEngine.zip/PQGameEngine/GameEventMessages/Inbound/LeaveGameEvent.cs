﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Inbound;

public class LeaveGameEvent : ICommandEventArgs
{
    [JsonPropertyName("connection_id")]
    public string? ConnectionIdToLeave { get; set; }
}