﻿using System.Text.Json.Serialization;
using PQGameEngine.Enums;

namespace PQGameEngine.GameEventMessages.MessageModels;

public class GameOptionsViewModel
{
    [JsonPropertyName("action_success_mode")]
    public GameOptionActionSuccessMode ActionSuccessMode { get; set; }

    [JsonPropertyName("action_detection_mode")]
    public GameOptionActionDetectionMode ActionDetectionMode { get; set; }

    [JsonPropertyName("equipment_shop_mode")]
    public GameOptionEquipmentShopMode EquipmentShopMode { get; set; }

    [JsonPropertyName("action_shop_mode")]
    public GameOptionActionShopMode ActionShopMode { get; set; }

    [JsonPropertyName("support_actions_mode")]
    public GameOptionSupportActionsMode SupportActionsMode { get; set; }

    [JsonPropertyName("initial_asset_stage")]
    public GameOptionInitialAssetStage InitialAssetStage { get; set; }

    [JsonPropertyName("initial_action_mode")]
    public GameOptionInitActionsMode InitActionsMode { get; set; }

    [JsonPropertyName("manual_def_type_mode")]
    public GameOptionManualDefType ManualDefTypeMode { get; set; }

    [JsonPropertyName("infiniteShields")]
    public bool InfiniteShields { get; set; }

    [JsonPropertyName("multiTargetSuccess")]
    public GameOptionMultiTargetSuccessMode MultiTargetSuccess { get; set; }

    [JsonPropertyName("defenderActionsDetectable")]
    public GameOptionDefenderActionsDetectableMode DefenderActionsDetectable { get; set; }

    [JsonPropertyName("availabilityPenalty")]
    public GameOptionDefenderAvailabilityPenaltyMode AvailabilityPenalty { get; set; }

    [JsonPropertyName("defenderPreSetupMode")]
    public GameOptionDefenderPreSetupMode DefenderPreSetupMode { get; set; }
}