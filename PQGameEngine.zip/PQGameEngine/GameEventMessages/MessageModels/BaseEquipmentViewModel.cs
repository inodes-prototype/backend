using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.MessageModels;

public abstract class BaseEquipmentViewModel<T> where T : notnull
{
    public BaseEquipmentViewModel(T id, string type, string name, string shortDescription,
        string longDescription, decimal price, int ownerId)
    {
        Id = id;
        Name = name;
        ShortDescription = shortDescription;
        LongDescription = longDescription;
        Price = price;
        Owner = ownerId;
        Type = type;
    }

    [JsonPropertyName("type")]
    public string Type { get; set; }

    [JsonPropertyName("id")]
    public T Id { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; }

    [JsonPropertyName("short_description")]
    public string ShortDescription { get; set; }

    [JsonPropertyName("long_description")]
    public string LongDescription { get; set; }

    [JsonPropertyName("effects")]
    public List<EffectViewModel>? Effects { get; set; }

    [JsonPropertyName("transfer_effects")]
    public List<EffectViewModel>? TransferEffects { get; set; }

    [JsonPropertyName("price")]
    public decimal? Price { get; set; }

    [JsonPropertyName("owner")]
    public int? Owner { get; set; }

    [JsonPropertyName("active")]
    public bool IsActive { get; set; }

    [JsonPropertyName("possible_actions")]
    public List<Guid>? PossibleActions { get; set; }

    [JsonPropertyName("impact")]
    public int[] Impact { get; set; }

    [JsonPropertyName("used_on_asset")]
    public AssetViewModel? UsedOnAsset { get; set; }

    [JsonPropertyName("used_on_action")]
    public ActionViewModel? UsedOnAction { get; set; }

    [JsonPropertyName("equipt_on_asset")]
    public AssetViewModel? EquiptOnAsset { get; set; }

    [JsonPropertyName("equipt_on_action")]
    public ActionViewModel? EquiptOnAction { get; set; }

    [JsonPropertyName("isSingleUse")]
    public bool IsSingleUse { get; set; }

    [JsonPropertyName("isPassiveEquipment")]
    public bool IsPassiveEquipment { get; set; }
}