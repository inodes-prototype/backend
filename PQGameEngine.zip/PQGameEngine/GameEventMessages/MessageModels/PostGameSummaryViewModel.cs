using PQGameEngine.Enums;

namespace PQGameEngine.GameEventMessages.MessageModels;

public class PostGameSummaryViewModel
{
    public GamePlayerEndState EndState { get; set; }
    public int TurnsPlayed { get; set; }
    public int? AttackerUndetectedTurns { get; set; }
    public int ActionsPlayed { get; set; }
    public int ActionsDetected { get; set; }
    public MostValuableActionViewModel? MostValuableAction { get; set; }
    public int DamageDealt { get; set; }
    public int DamageHealed { get; set; }
    public int EquipmentPurchased { get; set; }
    public decimal CreditsSpent { get; set; }
    public int ActionsSucceeded { get; set; }
    public List<ActionHistoryEntry> ActionHistory { get; set; } = default!;
    public decimal CreditsSpentTotal { get; set; }

    public class MostValuableActionViewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = default!;
        public string Description { get; set; } = default!;
    }

    public class ActionHistoryEntry
    {
        public int Turn { get; set; }
        public ActionInfo Action { get; set; } = default!;
        public PlayerInfo Player { get; set; } = default!;
        public List<AssetTarget> Targets { get; set; } = [];

        public bool? Success { get; set; }

        public int? FirstRoundDetected { get; set; }

        public class ActionInfo
        {
            public Guid TemplateId { get; set; }
            public string Name { get; set; } = default!;
            public int Id { get; set; }
        }

        public class PlayerInfo
        {
            public string Name { get; set; }
            public ActorTypes ActorType { get; set; }
        }

        public class AssetTargetBase
        {
            public int Id { get; set; }
            public string Name { get; set; } = default!;
        }

        public class AssetTarget : AssetTargetBase
        {
            public ImpactModel? Impact { get; set; }
            public bool Success { get; set; }
            public int? FirstRoundDetected { get; set; }
            public List<AssetTargetBase> ExposedAssets { get; set; }
            public List<AssetTargetBase> UnexposedAssets { get; set; }
            public List<char> CompromisedTypes { get; set; }
            public List<char> UncompromisedTypes { get; set; }
            public bool CredentialsGathered { get; set; }
            public bool ExploitsFound { get; set; }

            public class ImpactModel
            {
                public int C { get; set; }
                public int I { get; set; }
                public int A { get; set; }
            }
        }
    }
}