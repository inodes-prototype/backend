namespace PQGameEngine.GameEventMessages.MessageModels;

public class PostGameXpModel
{
    public Dictionary<string, int> XpDetails { get; set; } = [];
    public int Sum { get; set; }
    public string? XpDisabledReason { get; set; }

    public bool IsXpGranted()
    {
        return string.IsNullOrWhiteSpace(XpDisabledReason);
    }
}