﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.MessageModels;

public class EquipmentViewModel(
    int id,
    Guid templateId,
    string type,
    string name,
    string shortDescription,
    string longDescription,
    decimal price,
    int ownerId)
    : BaseEquipmentViewModel<int>(id, type, name, shortDescription,
        longDescription, price, ownerId)
{
    [JsonPropertyName("template_id")]
    public Guid TemplateId { get; set; } = templateId;
}