using PQGameEngine.Enums;

namespace PQGameEngine.GameEventMessages.MessageModels;

public class GameLogEvent
{
    public long Id { get; set; }
    public DateTimeOffset Created { get; set; }
    public GameboardLogMessageType Type { get; set; }
    public Dictionary<string, object> Payload { get; set; } = default!;
}