﻿using System.Text.Json.Serialization;
using PQGameEngine.Enums;

namespace PQGameEngine.GameEventMessages.MessageModels;

public class ActionViewModel(
    int id,
    Guid templateId,
    string name,
    string shortDescription,
    string longDescription,
    int[] impact,
    int sophReq,
    HashSet<AssetCategories> assetCategories,
    AttackStages attackStage,
    HashSet<Oses> oses,
    short actionPointCost)
    : BaseActionViewModel<int>(id, name, shortDescription, longDescription, impact,
        sophReq, assetCategories, attackStage, oses, actionPointCost)
{
    [JsonPropertyName("template_id")]
    public Guid TemplateId { get; set; } = templateId;
}