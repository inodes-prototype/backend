﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.MessageModels;

public class GameViewModel
{
    [JsonPropertyName("actions_offered")]
    public List<ActionTemplateViewModel>? ActionsOffered { get; set; }

    [JsonPropertyName("phase")]
    public string? GamePhase { get; set; }

    public List<PlayerViewModel> Players { get; set; } = default!;

    [JsonPropertyName("roles")]
    public Dictionary<string, ActorViewModel> Actors { get; set; } = default!;

    [JsonPropertyName("scenario_id")]
    public Guid ScenarioId { get; set; }

    [JsonPropertyName("shop")]
    public List<EquipmentTemplateViewModel>? EquipmentShopOffer { get; set; }

    [JsonPropertyName("amount_selection")]
    public int ActionsToSelect { get; set; }

    public int Turn { get; set; }

    public string ScenarioName { get; set; } = default!;

    public string ScenarioDescription { get; set; } = default!;

    public List<GameLogEvent> GameboardLog { get; set; } = [];
}