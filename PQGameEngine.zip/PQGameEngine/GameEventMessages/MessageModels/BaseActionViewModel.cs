using System.Text.Json.Serialization;
using PQGameEngine.Enums;

namespace PQGameEngine.GameEventMessages.MessageModels;

public abstract class BaseActionViewModel<T> where T : notnull
{
    public BaseActionViewModel(T id, string name, string shortDescription, string longDescription,
        int[] impact, int sophReq, HashSet<AssetCategories> assetCategories, AttackStages attackStage,
        HashSet<Oses> oses, short actionPointCost)
    {
        Id = id;
        Name = name;
        ShortDescription = shortDescription;
        LongDescription = longDescription;
        Impact = impact;
        SophRequirement = sophReq;
        AssetCategories = assetCategories;
        AttackStage = attackStage;
        Oses = oses;
        ActionPointCost = actionPointCost;
    }

    [JsonPropertyName("id")]
    public T Id { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; }

    public short ActionPointCost { get; set; }

    [JsonPropertyName("short_description")]
    public string ShortDescription { get; set; }

    [JsonPropertyName("long_description")]
    public string LongDescription { get; set; }

    [JsonPropertyName("effects")]
    public List<EffectViewModel>? Effects { get; set; }

    [JsonPropertyName("impact")]
    public int[]? Impact { get; set; }

    [JsonPropertyName("soph_requirement")]
    public int? SophRequirement { get; set; }

    [JsonPropertyName("requiresAdmin")]
    public bool RequiresAdmin { get; set; }

    [JsonPropertyName("requiredEquipment")]
    public List<EquipmentTemplateViewModel>? RequiredEquipment { get; set; }

    [JsonPropertyName("asset_categories")]
    public HashSet<AssetCategories> AssetCategories { get; set; }

    [JsonPropertyName("attack_stage")]
    public AttackStages AttackStage { get; set; }

    [JsonPropertyName("oses")]
    public HashSet<Oses> Oses { get; set; }

    [JsonPropertyName("card_type")]
    public string? CardType { get; set; }

    [JsonPropertyName("success_chance")]
    public decimal? SuccessChance { get; set; }

    [JsonPropertyName("detection_chance")]
    public decimal? DetectionChance { get; set; }

    [JsonPropertyName("detection_chance_failed")]
    public decimal? DetectionChanceFailed { get; set; }

    [JsonPropertyName("target_type")]
    public string TargetType { get; set; }

    [JsonPropertyName("supported_by")]
    public List<ActionViewModel>? SupportedBy { get; set; }

    [JsonPropertyName("equipment_played_with")]
    public List<EquipmentViewModel>? PlayedWithEquipment { get; set; }

    [JsonPropertyName("attack_mask_used")]
    public string? AttackMaskUsed { get; set; }

    [JsonPropertyName("actor")]
    public int? Actor { get; set; }

    [JsonPropertyName("events")]
    public List<ActionEventViewModel>? Events { get; set; }

    [JsonPropertyName("predefined_attack_mask")]
    public string? PredefinedAttackMask { get; set; }

    [JsonPropertyName("requires_attack_mask")]
    public bool? RequiredAttackMask { get; set; }

    [JsonPropertyName("transfer_effects")]
    public List<EffectViewModel>? TransferEffects { get; set; }

    [JsonPropertyName("possible_actions")]
    public List<Guid> PossibleActions { get; set; }

    [JsonPropertyName("actor_type")]
    public string ActorType { get; set; }

    [JsonPropertyName("def_type")]
    public DefenseActionType DefType { get; set; }

    [JsonPropertyName("deflectedDamage")]
    public int[] DeflectedDamage { get; set; }
}