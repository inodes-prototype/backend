﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.MessageModels;

public class PlayerViewModel(
    int slotId,
    string connectionId,
    string name,
    Guid? avatarId,
    bool isOnline,
    Guid userId)
{
    public int Id { get; } = slotId;

    [JsonPropertyName("connection_id")]
    public string ConnectionId { get; } = connectionId;

    public string Name { get; } = name;

    [JsonPropertyName("avatar_id")]
    public Guid? AvatarId { get; } = avatarId;

    [JsonPropertyName("online")]
    public bool IsOnline { get; } = isOnline;

    [JsonPropertyName("user_id")]
    public Guid UserId { get; } = userId;
}