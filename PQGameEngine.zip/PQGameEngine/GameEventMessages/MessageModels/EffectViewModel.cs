﻿using System.Text.Json.Serialization;
using PQGameEngine.Enums;

namespace PQGameEngine.GameEventMessages.MessageModels;

public class EffectViewModel
{
    public EffectViewModel()
    {
    }

    public EffectViewModel(EffectTypes effectType,
        bool isPermanent,
        string type,
        int id,
        string name,
        string description,
        string scope,
        int ownerId)
    {
        EffectType = effectType;
        IsPermanent = isPermanent;
        Type = type;
        Id = id;
        Name = name;
        Description = description;
        Scope = scope;
        OwnerId = ownerId;
    }

    [JsonPropertyName("effectType")]
    public EffectTypes EffectType { get; set; }

    [JsonPropertyName("isPermanent")]
    public bool IsPermanent { get; set; }

    [JsonPropertyName("type")]
    public string Type { get; set; } = default!;

    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; } = default!;

    [JsonPropertyName("description")]
    public string Description { get; set; } = default!;

    [JsonPropertyName("scope")]
    public string Scope { get; set; } = default!;

    [JsonPropertyName("owner_id")]
    public int OwnerId { get; set; }

    [JsonPropertyName("active")]
    public bool? Active { get; set; }

    [JsonPropertyName("turns")]
    public int? Turns { get; set; }

    [JsonPropertyName("num_effects")]
    public short? NumEffects { get; set; }

    [JsonPropertyName("attributes")]
    public string[]? Attributes { get; set; }

    [JsonPropertyName("value")]
    public decimal Value { get; set; }

    [JsonPropertyName("probability")]
    public decimal? Probability { get; set; }

    [JsonPropertyName("equipment")]
    public List<EquipmentTemplateViewModel>? GrantedEquipment { get; set; }
}