﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.MessageModels;

public class GoalViewModel
{
    public string Type { get; set; } = default!;

    public AssetViewModel? Asset { get; set; }

    public int[]? Damage { get; set; }

    public bool[]? Exposed { get; set; }

    [JsonPropertyName("attack_stage")]
    public string? AttackStage { get; set; }

    [JsonPropertyName(Constants.ACTOR_ATTRIBUTE_TEXT_INSIGHT)]
    public int? Insight { get; set; }

    [JsonPropertyName(Constants.ACTOR_ATTRIBUTE_TEXT_CREDITS)]
    public decimal? Credits { get; set; }

    public ActorViewModel? Defender { get; set; }
}