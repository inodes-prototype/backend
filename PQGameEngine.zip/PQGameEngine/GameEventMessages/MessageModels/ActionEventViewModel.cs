﻿using System.Text.Json.Serialization;
using PQGameEngine.Enums;

namespace PQGameEngine.GameEventMessages.MessageModels;

public class ActionEventViewModel
{
    [JsonPropertyName("turn_detected")]
    public int TurnDetected { get; set; }

    [JsonPropertyName("succeeded")]
    public bool Succeeded { get; set; }

    [JsonPropertyName("deflected")]
    public DeflectedType Deflected { get; set; }

    [JsonPropertyName("deflectedBy")]
    public List<ActionTemplateViewModel>? DeflectedBy { get; set; }

    [JsonPropertyName("deflectedDamage")]
    public int[]? DeflectedDamage { get; set; }


    [JsonPropertyName("asset")]
    public int? AssetId { get; set; }

    [JsonPropertyName("current_asset_damage")]
    public int[]? CurrentAssetDamage { get; set; }

    [JsonPropertyName("applied_dependency_damage")]
    public List<int>? AppliedDependencyDamageToAssetIds { get; set; }

    [JsonPropertyName("damage_dealt")]
    public int[]? DamageDealt { get; set; }

    [JsonPropertyName("active_damage")]
    public int[]? ActiveDamage { get; set; }

    [JsonPropertyName("countered")]
    public List<int>? CounteredActionIds { get; set; }

    [JsonPropertyName("fully_countered")]
    public bool? FullyCountered { get; set; }

    [JsonPropertyName("counters")]
    public int? CountersActionId { get; set; }

    [JsonPropertyName("isCounterable")]
    public bool? IsCounterable { get; set; }

    [JsonPropertyName("lastTurnToCounter")]
    public int? LastTurnToCounter { get; set; }
}