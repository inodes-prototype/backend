﻿using System.Text.Json.Serialization;
using PQGameEngine.Enums;

namespace PQGameEngine.GameEventMessages.MessageModels;

public class ActorViewModel(int id, string connectionId, Guid userId, Guid? avatarId, bool isOnline, string name)
{
    [JsonPropertyName("id")]
    public int Id { get; } = id;

    [JsonPropertyName("type")]
    public string Type { get; set; } = default!;

    [JsonPropertyName("connection_id")]
    public string ConnectionId { get; } = connectionId;

    [JsonPropertyName("user_id")]
    public Guid UserId { get; } = userId;

    [JsonPropertyName("avatar_id")]
    public Guid? AvatarId { get; } = avatarId;

    [JsonPropertyName("online")]
    public bool IsOnline { get; } = isOnline;

    [JsonPropertyName("name")]
    public string Name { get; } = name;

    [JsonPropertyName("description")]
    public string Description { get; set; } = default!;

    [JsonPropertyName(Constants.ACTOR_ATTRIBUTE_TEXT_SKILL)]
    public int? Skill { get; set; }

    [JsonPropertyName(Constants.ACTOR_ATTRIBUTE_TEXT_DETERMINATION)]
    public int? Determination { get; set; }

    [JsonPropertyName(Constants.ACTOR_ATTRIBUTE_TEXT_WEALTH)]
    public int? Wealth { get; set; }

    [JsonPropertyName(Constants.ACTOR_ATTRIBUTE_TEXT_INSIGHT)]
    public int? Insight { get; set; }

    [JsonPropertyName(Constants.ACTOR_ATTRIBUTE_TEXT_INITIATIVE)]
    public int? Initiative { get; set; }

    [JsonPropertyName(Constants.ACTOR_ATTRIBUTE_TEXT_CREDITS)]
    public decimal? Credits { get; set; }

    public int? InsightShield { get; set; }

    [JsonPropertyName("actions")]
    public List<ActionViewModel> Actions { get; set; } = [];

    [JsonPropertyName("equipment")]
    public List<EquipmentViewModel> Equipment { get; set; } = [];

    [JsonPropertyName("visible_assets")]
    public List<AssetViewModel> VisibleAssets { get; set; } = [];

    [JsonPropertyName("goal_descriptions")]
    public List<string>? GoalDescription { get; set; }

    [JsonPropertyName("mission_description")]
    public string MissionDescription { get; set; } = default!;

    [JsonPropertyName("goals")]
    public List<GoalViewModel>? Goals { get; set; }

    [JsonPropertyName("assets")]
    public List<AssetViewModel> Assets { get; set; } = [];

    public bool? HasBeenDetected { get; set; }
    public ActorTypes ActorType { get; set; }
    public int ActionPoints { get; set; }
}