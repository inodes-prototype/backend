namespace PQGameEngine.GameEventMessages.MessageModels;

public class EquipmentTemplateViewModel(
    Guid templateId,
    string type,
    string name,
    string shortDescription,
    string longDescription,
    decimal price,
    int ownerId)
    : BaseEquipmentViewModel<Guid>(templateId, type, name, shortDescription,
        longDescription, price, ownerId);