﻿using System.Text.Json.Serialization;
using PQGameEngine.Enums;

namespace PQGameEngine.GameEventMessages.MessageModels;

public class AssetViewModel(int id, string name, AssetCategories category)
{
    [JsonPropertyName("id")]
    public int Id { get; set; } = id;

    [JsonPropertyName("name")]
    public string Name { get; set; } = name;

    [JsonPropertyName("description")]
    public string Description { get; set; }

    [JsonPropertyName("initially_exposed")]
    public bool? InitiallyExposed { get; set; }

    [JsonPropertyName("exposed")]
    public bool[] Exposed { get; set; }

    [JsonPropertyName("dependencies")]
    public List<int> Dependencies { get; set; }

    [Obsolete("Replaced by 'KnownAttackVectors'")]
    [JsonPropertyName("attack_vectors")]
    public List<int> AttackVectors { get; set; }

    [JsonPropertyName("attack_stage")]
    public AttackStages AttackStage { get; set; }

    [JsonPropertyName("category")]
    public AssetCategories Category { get; set; } = category;

    [JsonPropertyName("os")]
    public Oses Os { get; set; }

    [JsonPropertyName("played_actions")]
    public List<ActionViewModel> PlayedActions { get; set; }

    [JsonPropertyName("damage")]
    public int[]? Damage { get; set; }

    [JsonPropertyName("permanent_effects")]
    public List<EffectViewModel> PermanentEffects { get; set; }

    [JsonPropertyName("active_exploits")]
    public List<EquipmentViewModel> ActiveExploits { get; set; }

    public List<AttackVectorViewModel>? KnownAttackVectors { get; set; }

    [JsonPropertyName("shield")]
    public bool? ShieldActive { get; set; }

    [JsonPropertyName("parent_asset")]
    public int? ParentAssetId { get; set; }

    [JsonPropertyName("child_assets")]
    public List<int> ChildAssets { get; set; }

    [JsonPropertyName("hasBeenSeen")]
    public bool? HasPreviouslyBeenSeen { get; set; }

    [JsonPropertyName("hasAdminRights")]
    public bool HasAdminRights { get; set; }

    [JsonPropertyName("isOffline")]
    public bool IsOffline { get; set; }

    public int? PenaltyOfflineRounds { get; set; }

    public int? OfflineSinceTurn { get; set; }
}