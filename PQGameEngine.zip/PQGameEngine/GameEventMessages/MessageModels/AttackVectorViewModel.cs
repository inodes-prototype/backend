namespace PQGameEngine.GameEventMessages.MessageModels;

public class AttackVectorViewModel
{
    public int TargetAssetId { get; set; }
    public string? ExposedMask { get; set; }
}