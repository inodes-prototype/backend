using PQGameEngine.Enums;

namespace PQGameEngine.GameEventMessages.MessageModels;

public class ActionTemplateViewModel(
    Guid templateId,
    string name,
    string shortDescription,
    string longDescription,
    int[] impact,
    int sophReq,
    HashSet<AssetCategories> assetCategories,
    AttackStages attackStage,
    HashSet<Oses> oses,
    short actionPointCost)
    : BaseActionViewModel<Guid>(templateId, name, shortDescription, longDescription, impact,
        sophReq, assetCategories, attackStage, oses, actionPointCost);