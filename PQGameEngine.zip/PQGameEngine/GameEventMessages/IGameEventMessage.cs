﻿namespace PQGameEngine.GameEventMessages;

public interface IGameEventMessage
{
    string GetEventType();
}