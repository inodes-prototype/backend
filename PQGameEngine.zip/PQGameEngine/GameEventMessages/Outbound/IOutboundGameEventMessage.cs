﻿namespace PQGameEngine.GameEventMessages.Outbound;

public interface IOutboundGameEventMessage
{
}