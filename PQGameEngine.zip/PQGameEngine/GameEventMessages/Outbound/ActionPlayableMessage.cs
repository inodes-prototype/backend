﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Outbound;

public class ActionPlayableMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("detection_chance")]
    public decimal DetectionChance { get; set; }

    [JsonPropertyName("errors")]
    public ErrorMessage? Errors { get; set; }

    [JsonPropertyName("playable")]
    public bool IsPlayable { get; set; }

    [JsonPropertyName("response_target_ids")]
    public List<int> ResponseTargetIds { get; set; } = default!;

    public WarningInfos Warnings { get; set; } = default!;

    public List<ResponseTargetInfoModel> ResponseTargetInfos { get; set; } = [];

    [JsonPropertyName("success_chance")]
    public decimal SuccessChance { get; set; }

    [JsonPropertyName("successModifier")]
    public List<ActionChanceModifier>? SuccessModifier { get; set; }

    [JsonPropertyName("detectionModifier")]
    public List<ActionChanceModifier>? DetectionModifier { get; set; }

    public class ActionChanceModifier
    {
        [JsonPropertyName("bonus")]
        public decimal Bonus { get; set; }

        [JsonPropertyName("reason")]
        public string Reason { get; set; } = default!;

        [JsonPropertyName("code")]
        public string Code { get; set; } = default!;
    }

    public class ResponseTargetInfoModel
    {
        public int ActionId { get; set; }
        public bool IsExpired { get; set; }
    }

    public class WarningInfos
    {
        public bool NoResponseTargetAvailable { get; set; }
        public bool InvalidAttackMask { get; set; }
    }
}