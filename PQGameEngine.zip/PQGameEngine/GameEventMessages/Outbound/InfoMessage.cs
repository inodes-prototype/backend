using PQGameEngine.Enums;

namespace PQGameEngine.GameEventMessages.Outbound;

public class InfoMessage : IOutboundGameEventMessage
{
    public InfoType Type { get; set; }
    public string Message { get; set; } = default!;
}