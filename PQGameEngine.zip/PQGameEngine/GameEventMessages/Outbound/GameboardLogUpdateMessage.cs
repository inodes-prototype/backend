using System.Text.Json.Serialization;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Outbound;

public class GameboardLogUpdateMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("events")]
    public List<GameLogEvent> Events { get; set; }
}