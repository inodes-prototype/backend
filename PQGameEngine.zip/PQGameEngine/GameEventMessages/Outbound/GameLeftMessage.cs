﻿namespace PQGameEngine.GameEventMessages.Outbound;

public class GameLeftMessage : IOutboundGameEventMessage
{
}