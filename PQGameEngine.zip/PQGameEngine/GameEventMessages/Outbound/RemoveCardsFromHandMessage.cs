﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Outbound;

public class RemoveCardsFromHandMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("actionIds")]
    public List<int> ActionIds { get; set; }

    [JsonPropertyName("equipmentIds")]
    public List<int> EquipmentIds { get; set; }
}