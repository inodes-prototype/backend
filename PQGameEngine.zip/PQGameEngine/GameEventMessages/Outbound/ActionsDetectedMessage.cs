﻿using System.Text.Json.Serialization;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Outbound;

public class ActionsDetectedMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("actions")]
    public List<ActionViewModel> Actions { get; set; }
}