﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Outbound;

public class WrappedOutboundMessage(string eventName, IOutboundGameEventMessage data, long? requestId)
    : IGameEventMessage
{
    [JsonPropertyName("event")]
    public string EventName { get; set; } = eventName;

    [JsonPropertyName("data")]
    public object Data { get; set; } = data;

    [JsonPropertyName("request_id")]
    public long? RequestId { get; set; } = requestId;

    public string GetEventType()
    {
        return EventName;
    }
}