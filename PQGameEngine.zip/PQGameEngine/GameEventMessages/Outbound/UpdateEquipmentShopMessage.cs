﻿using System.Text.Json.Serialization;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Outbound;

public class UpdateEquipmentShopMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("equipment")]
    public List<EquipmentTemplateViewModel> Equipment { get; set; }
}