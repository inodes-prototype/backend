﻿using System.Text.Json.Serialization;
using PQGameEngine.Enums;

namespace PQGameEngine.GameEventMessages.Outbound;

public class AttributeChangedMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("attribute")]
    public string Attribute { get; set; } = default!;

    [JsonPropertyName("value")]
    public decimal Value { get; set; }

    public ChangedPlayerAttributeType AttributeType { get; set; }
}