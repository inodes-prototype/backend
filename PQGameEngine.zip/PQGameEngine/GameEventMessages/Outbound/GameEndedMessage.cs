﻿using PQGameEngine.Enums;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Outbound;

public class GameEndedMessage : IOutboundGameEventMessage
{
    public string EndMessage { get; set; } = default!;
    public GamePlayerEndState EndState { get; set; }
    public PostGameSummaryViewModel PostGameSummary { get; set; } = default!;
    public PostGameXpModel XpSummary { get; set; } = default!;
}