﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Outbound;

public class GameTurnChangedMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("currentTurn")]
    public int CurrentTurn { get; set; }
}