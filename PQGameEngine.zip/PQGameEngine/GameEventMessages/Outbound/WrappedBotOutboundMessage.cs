﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Outbound;

public class WrappedBotOutboundMessage : IBotEventMessage
{
    public WrappedBotOutboundMessage(string command, IOutboundBotEventMessage data)
    {
        Command = command;
        Data = data;
    }

    [JsonPropertyName("command")]
    public string Command { get; set; }

    [JsonPropertyName("command_data")]
    public object Data { get; set; }

    public void InjectGameServerId(object gameServerId)
    {
        if (Data is IOutboundBotEventMessage obem)
        {
            obem.InjectGameServerId(gameServerId);
        }
    }
}