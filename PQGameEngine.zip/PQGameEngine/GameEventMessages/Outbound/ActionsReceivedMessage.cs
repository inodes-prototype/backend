﻿using System.Text.Json.Serialization;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Outbound;

public class ActionsReceivedMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("new_actions")]
    public List<ActionViewModel> Actions { get; set; }
}