﻿using System.Text.Json.Serialization;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Outbound;

public class UpdatePlayerMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("player")]
    public PlayerViewModel Player { get; set; } = default!;
}