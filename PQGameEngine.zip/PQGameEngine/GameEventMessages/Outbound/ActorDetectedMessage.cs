namespace PQGameEngine.GameEventMessages.Outbound;

public class ActorDetectedMessage : IOutboundGameEventMessage
{
    public int ActorId { get; set; }
}