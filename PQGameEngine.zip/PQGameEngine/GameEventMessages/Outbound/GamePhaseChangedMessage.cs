﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Outbound;

public class GamePhaseChangedMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("game_phase")]
    public string? GamePhase { get; set; }
}