﻿using System.Text.Json.Serialization;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Outbound;

public class GamePlayerChangedMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("new_connection_id")]
    public string NewConnectionId { get; set; }

    [JsonPropertyName("new_player_id")]
    public Guid NewPlayerId { get; set; }

    [JsonPropertyName("old_connection_id")]
    public string OldConnectionId { get; set; }

    [JsonPropertyName("old_player_id")]
    public Guid OldPlayerId { get; set; }

    [JsonPropertyName("player")]
    public PlayerViewModel Player { get; set; }
}