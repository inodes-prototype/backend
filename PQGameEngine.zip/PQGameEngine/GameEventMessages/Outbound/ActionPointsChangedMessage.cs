namespace PQGameEngine.GameEventMessages.Outbound;

public class ActionPointsChangedMessage : IOutboundGameEventMessage
{
    public int ActionPoints { get; set; }
}