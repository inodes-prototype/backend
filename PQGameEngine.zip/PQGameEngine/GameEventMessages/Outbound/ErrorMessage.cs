﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Outbound;

public class ErrorMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("multiple_errors")]
    public bool MultipleErrors { get; set; }

    [JsonPropertyName("error_id")]
    public List<int> ErrorIds { get; set; } = [];

    [JsonPropertyName("error_message")]
    public List<string> ErrorMessages { get; set; } = [];
}