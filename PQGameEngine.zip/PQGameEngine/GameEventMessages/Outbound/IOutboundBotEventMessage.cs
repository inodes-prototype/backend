﻿namespace PQGameEngine.GameEventMessages.Outbound;

public interface IOutboundBotEventMessage
{
    void InjectGameServerId(object gameServerId);
}