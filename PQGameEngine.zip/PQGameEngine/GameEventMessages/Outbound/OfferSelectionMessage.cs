﻿using System.Text.Json.Serialization;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Outbound;

public class OfferSelectionMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("actions")]
    public List<ActionTemplateViewModel> Actions { get; set; }

    [JsonPropertyName("amount_selection")]
    public int AmountToSelect { get; set; }
}