﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Outbound;

public class AllActionsPlayableMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("playable_results")]
    public Dictionary<string, AllActionsPlayableMessageContent> PlayableInformation { get; set; } = [];

    public class AllActionsPlayableMessageContent(int actionId, List<int> supportActionIds, List<int> equipmentIds)
    {
        [JsonPropertyName("playable")]
        public bool IsPlayable { get; set; }

        [JsonPropertyName("possible_targets")]
        public List<int> TargetableAssetIds { get; set; } = [];

        [JsonPropertyName("possible_response_target_ids")]
        public Dictionary<int, List<int>> PossibleResponseTargetIds { get; set; } = [];

        [JsonPropertyName("success_chance")]
        public decimal SuccessChance { get; set; }

        [JsonPropertyName("detection_chance")]
        public decimal DetectionChance { get; set; }


        [JsonPropertyName("action_id")]
        public int MainActionId { get; set; } = actionId;

        [JsonPropertyName("support_action_ids")]
        public List<int> SupportActionsIds { get; set; } = supportActionIds;

        [JsonPropertyName("equipment_ids")]
        public List<int> EquipmentIds { get; set; } = equipmentIds;
    }
}