﻿using System.Text.Json.Serialization;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Outbound;

public class GameStartedMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("game")]
    public GameViewModel Game { get; set; } = default!;
}