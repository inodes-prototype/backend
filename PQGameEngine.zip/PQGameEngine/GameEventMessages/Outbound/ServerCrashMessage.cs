﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Outbound;

public class ServerCrashMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("reason")]
    public string Reason { get; set; }

    [JsonPropertyName("code")]
    public int Code { get; set; }
}