﻿using System.Text.Json.Serialization;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Outbound;

public class AssetChangedMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("asset")]
    public AssetViewModel Asset { get; set; }
}