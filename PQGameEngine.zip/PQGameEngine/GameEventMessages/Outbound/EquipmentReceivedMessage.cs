﻿using System.Text.Json.Serialization;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Outbound;

public class EquipmentReceivedMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("equipment")]
    public List<EquipmentViewModel> Equipment { get; set; }
}