using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Outbound;

public class RemoveEquipmentFromShopMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("equipmentIds")]
    public List<Guid> EquipmentIds { get; set; }
}