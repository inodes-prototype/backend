﻿using System.Text.Json.Serialization;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Outbound;

public class ActionSuccessMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("action")]
    public ActionViewModel Action { get; set; }

    [JsonPropertyName("successful")]
    public List<bool> SuccessInfo { get; set; }
}