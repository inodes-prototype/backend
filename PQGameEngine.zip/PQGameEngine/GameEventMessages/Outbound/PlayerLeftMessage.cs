﻿using System.Text.Json.Serialization;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Outbound;

public class PlayerLeftMessage : IOutboundGameEventMessage
{
    [JsonPropertyName("player")]
    public PlayerViewModel Player { get; set; }

    [JsonPropertyName("slot")]
    public int Slot { get; set; }
}