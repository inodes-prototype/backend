﻿using System.Text.Json.Serialization;
using PQGameEngine.GameEventMessages.MessageModels;

namespace PQGameEngine.GameEventMessages.Outbound;

public class AssetVisibilityChangedMessage : IOutboundGameEventMessage
{
    public AssetVisibilityChangedMessage(List<int> hidden, List<AssetViewModel> revealed)
    {
        Changes = new AssetVisibilityChangedContent()
        {
            HiddenAssets = hidden,
            RevealedAssets = revealed
        };
    }

    [JsonPropertyName("asset_changes")]
    public AssetVisibilityChangedContent Changes { get; set; }

    public class AssetVisibilityChangedContent
    {
        [JsonPropertyName("hidden")]
        public List<int> HiddenAssets { get; set; }

        [JsonPropertyName("revealed")]
        public List<AssetViewModel> RevealedAssets { get; set; }
    }
}