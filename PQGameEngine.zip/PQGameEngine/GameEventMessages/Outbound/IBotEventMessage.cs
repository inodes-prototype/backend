﻿namespace PQGameEngine.GameEventMessages.Outbound;

public interface IBotEventMessage
{
    void InjectGameServerId(object gameServerId);
}