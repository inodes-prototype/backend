﻿using System.Text.Json.Serialization;

namespace PQGameEngine.GameEventMessages.Outbound;

public class RequestBotSetReadyMessage : IOutboundBotEventMessage
{
    [JsonPropertyName("game_code")]
    public string GameCode { get; }

    [JsonPropertyName("game_server_id")]
    public object? GameServerId { get; set; }

    public RequestBotSetReadyMessage(string gameCode)
    {
        GameCode = gameCode;
    }

    public void InjectGameServerId(object gameServerId)
    {
        GameServerId = gameServerId;
    }
}