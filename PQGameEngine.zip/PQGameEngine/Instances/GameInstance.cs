﻿using PQGameEngine.Enums;
using PQGameEngine.Exceptions;
using PQGameEngine.Functionality.GameboardLog;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.Internal;
using PQGameEngine.Templates;

namespace PQGameEngine.Instances;

public class GameInstance : IInstance
{
    public Guid Id { get; }

    public string Code { get; }

    public GameboardLogCollector GameboardLog { get; } = new();

    public Dictionary<int, PlayerStatCounter> ActorStatCounters { get; } = new();

    public ScenarioTemplate Scenario { get; }

    public IRandom Random { get; }

    public GameOptionsModel Options { get; }

    public Dictionary<int, List<Guid>> Journal { get; }

    public Dictionary<int, int> JournalIdx { get; }

    public Dictionary<Guid, Models.GameEvents.GameEvent> Events { get; }

    public HashSet<Guid> EventsToHandleEachTurn { get; }

    public List<Guid> EventList { get; }

    public Dictionary<int, List<Guid>> ActionDecksMain { get; }

    public Dictionary<int, List<Guid>> ActionDecksSupport { get; }

    public int Turn { get; private set; }

        public Dictionary<int, BaseActionModel> Actions { get; }

                            public Dictionary<int, EquipmentModel> Equipment { get; }

                public Dictionary<int, EffectModel> Effects { get; }

                    public Dictionary<int, List<Guid>> Shops { get; }

                public GamePhase Phase { get; private set; }

    public GameInstance(Guid id, string code, ScenarioTemplate scenario, IRandom random,
        GameOptionsModel? options = null, Guid? xpEventId = null)
    {
        if (id == Guid.Empty) throw new ArgumentException($"Invalid game id {id}");

        if (scenario == null!)
        {
            throw new PenQuestException(Errors.IsNoneError, "No scenario specified");
        }

        Id = id;
        Code = code;
        Scenario = scenario;
        Random = random;
        Options = options ?? new GameOptionsModel();
        Journal = [];
        JournalIdx = [];
        Events = [];
        EventList = [];
        EventsToHandleEachTurn = [];
        ActionDecksMain = [];
        ActionDecksSupport = [];
        Actions = [];
        Equipment = [];
        Shops = [];
        Phase = GamePhase.Starting;
        Effects = [];
        XpEventId = xpEventId;
    }

                public Guid? XpEventId { get; }

                public Dictionary<int, AssetModel> Assets => Scenario.Assets;

    public Dictionary<int, ActorModel> Actors => Scenario.Actors;

                public Dictionary<int, ActorModel> Attackers => Scenario.Attackers;

                public Dictionary<int, ActorModel> Defenders => Scenario.Defenders;

    private List<ActionTemplate> _actionTemplatesAttacker = null!;

    public List<ActionTemplate> ActionTemplatesAttacker
    {
        get
        {
            if (_actionTemplatesAttacker == null!)
            {
                _actionTemplatesAttacker = Scenario.ActionTemplates
                    .Where(x => Scenario.AttackerActionTemplates.Contains(x.Key)).Select(x => x.Value).ToList();
            }

            return _actionTemplatesAttacker;
        }
    }

    private List<ActionTemplate> _actionTemplatesDefender = null!;

    public List<ActionTemplate> ActionTemplatesDefender
    {
        get
        {
            if (_actionTemplatesDefender == null!)
            {
                _actionTemplatesDefender = Scenario.ActionTemplates
                    .Where(x => Scenario.DefenderActionTemplates.Contains(x.Key)).Select(x => x.Value).ToList();
            }

            return _actionTemplatesDefender;
        }
    }

    public Dictionary<Guid, ActionTemplate> ActionTemplates => Scenario.ActionTemplates;

    private List<EquipmentTemplate> _equipmentTemplatesAttacker = null!;

    public List<EquipmentTemplate> EquipmentTemplatesAttacker
    {
        get
        {
            if (_equipmentTemplatesAttacker == null!)
            {
                _equipmentTemplatesAttacker = Scenario.EquipmentTemplates
                    .Where(x => Scenario.AttackerEquipmentTemplates.Contains(x.Key)).Select(x => x.Value).ToList();
            }

            return _equipmentTemplatesAttacker;
        }
    }

    private List<EquipmentTemplate> _equipmentTemplatesDefender = null!;

    public List<EquipmentTemplate> EquipmentTemplatesDefender
    {
        get
        {
            if (_equipmentTemplatesDefender == null!)
            {
                _equipmentTemplatesDefender = Scenario.EquipmentTemplates
                    .Where(x => Scenario.DefenderEquipmentTemplates.Contains(x.Key)).Select(x => x.Value).ToList();
            }

            return _equipmentTemplatesDefender;
        }
    }

    public Dictionary<int, TurnTracker> TurnTrackers { get; } = [];

    public Dictionary<Guid, EquipmentTemplate> EquipmentTemplates => Scenario.EquipmentTemplates;

    private int _nextActionId;

    public int GetNextActionId()
    {
        _nextActionId++;
        return _nextActionId;
    }

    private int _nextEquipmentId;

    public int GetNextEquipmentId()
    {
        _nextEquipmentId++;
        return _nextEquipmentId;
    }

    private int _nextEffectId;

    public int GetNextEeffectId()
    {
        _nextEffectId++;
        return _nextEffectId;
    }

    public List<AssetModel> GetExposedAssets(HashSet<AssetCategories> assetCategories = null, string attackMask = null)
    {
        List<AssetModel> assets = [];
        if (assetCategories != null! && assetCategories.Count == 0 || attackMask == "")
        {
            return assets;
        }

        if (string.IsNullOrWhiteSpace(attackMask))
        {
            attackMask = "CIA";
        }

        foreach (var asset in Scenario.Assets.Values)
        {
            if (assetCategories != null && !assetCategories.Contains(asset.Template.Category))
            {
                continue;
            }

            if (attackMask.All(scale => asset.CurrentExposedState.IsExposed(scale)))
            {
                assets.Add(asset);
            }
        }

        return assets;
    }

    public void InitTurnTrackerAttacker()
    {
        foreach (var actor in Attackers.Values)
        {
            TurnTrackers[actor.Id].InitForNewTurn();
        }
    }

    public void InitTurnTrackerDefender()
    {
        foreach (var actor in Defenders.Values)
        {
            TurnTrackers[actor.Id].InitForNewTurn();
        }
    }

    public void AddEvent(Models.GameEvents.GameEvent @event)
    {
        Events.Add(@event.Id, @event);
        EventList.Add(@event.Id);
        if (!Journal.ContainsKey(Turn))
        {
            Journal.Add(Turn, [@event.Id]);
        }
        else
        {
            Journal[Turn].Add(@event.Id);
        }
    }

    public void SetTurn(int turn)
    {
        Turn = turn;
    }

    public void SetPhase(GamePhase phase)
    {
        Phase = phase;
    }

    public bool HaveAllPlayersLeft => Actors.All(x => x.Value.HasLeft);
    public bool HaveAllAttackersLeft => Attackers.All(x => x.Value.HasLeft);
    public bool HaveAllDefendersLeft => Defenders.All(x => x.Value.HasLeft);

    public ActorModel GetActorByConnectionId(string connectionId)
    {
        var t = Actors.Values.FirstOrDefault(x => x.ConnectionId == connectionId);
        if (t != null) return t;

        throw new PenQuestFatalException("Actor of connectionId=" + connectionId + " not found");
    }

    public IReadOnlyCollection<BaseGoalModel> GetGoalsOfActor(int id)
    {
        if (!Actors.TryGetValue(id, out var actor))
            throw new PenQuestFatalException($"Invalid actor id {id}");

                return Scenario.Goals;
    }
}