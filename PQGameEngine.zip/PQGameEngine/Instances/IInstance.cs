namespace PQGameEngine.Instances;

public interface IInstance
{
    Guid Id { get; }
    string Code { get; }
}