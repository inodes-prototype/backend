using System.Collections.Concurrent;
using PQGameEngine.Instances;

namespace PQGameEngine;

public class GameEngineStore
{
    private readonly Action<Guid> _instanceCreatedCallback;
    private readonly Action<Guid> _scheduleInstanceRemovalCallback;
    private readonly IGameEngineMetrics? _metrics;
    private readonly ConcurrentDictionary<Guid, IInstance> _instanceStore = [];
    private readonly ConcurrentReverseAccessDictionary<string, Guid> _connectionToInstanceMapping = new();
    private readonly ConcurrentReverseAccessDictionary<string, Guid> _codeToInstanceMapping = new();
    private readonly ConcurrentReverseAccessDictionary<string, Guid> _connectionToSourceServiceMapping = new();

    public GameEngineStore(Action<Guid> instanceCreatedCallback,
        Action<Guid> scheduleInstanceRemovalCallback, IGameEngineMetrics? metrics = null)
    {
        _instanceCreatedCallback =
            instanceCreatedCallback ?? throw new ArgumentNullException(nameof(instanceCreatedCallback));
        _scheduleInstanceRemovalCallback =
            scheduleInstanceRemovalCallback ?? throw new ArgumentNullException(nameof(scheduleInstanceRemovalCallback));
        _metrics = metrics;
    }

    public void Remove(IInstance instance)
    {
        if (!_instanceStore.Remove(instance.Id, out _))
        {
            throw new ArgumentException($"Instance {instance.Id} does not exist");
        }

        _metrics?.DecreaseRunningGameCounter();
        _connectionToInstanceMapping.RemoveMappingByValue(instance.Id, out var droppedConnectionIds);
        foreach (var connectionId in droppedConnectionIds)
        {
            _connectionToSourceServiceMapping.RemoveMapping(connectionId);
        }

        _codeToInstanceMapping.RemoveMappingByValue(instance.Id, out _);
        _scheduleInstanceRemovalCallback(instance.Id);
    }

    public void Dispose(IInstance instance)
    {
        Remove(instance);
    }

    public void RegisterNew(IInstance instance)
    {
        if (!_instanceStore.TryAdd((Guid)instance.Id, instance))
        {
            throw new ArgumentException($"Instance {instance.Id} already in store");
        }

        if (!_codeToInstanceMapping.TryAddMapping(instance.Code, instance.Id))
        {
            throw new ArgumentException($"Instance code {instance.Code} already used");
        }

        _metrics?.IncreaseRunningGameCounter();
        _instanceCreatedCallback(instance.Id);
    }

    public void ReplaceInstance(GameInstance game)
    {
        if (!_instanceStore.ContainsKey(game.Id))
        {
            throw new ArgumentException($"Instance {game.Id} not found");
        }

        _instanceStore[game.Id] = game;
    }

    public void UnmapConnection(string connectionId)
    {
        _connectionToInstanceMapping.RemoveMapping(connectionId);
        _connectionToSourceServiceMapping.RemoveMapping(connectionId);
    }

    public void MapConnectionTo(string connectionId, IInstance instance, Guid? sourceServiceId)
    {
        if (!_connectionToInstanceMapping.TryAddMapping(connectionId, instance.Id))
        {
            throw new ArgumentException($"Connection {connectionId} already connected");
        }

        if (sourceServiceId.HasValue)
        {
            _connectionToSourceServiceMapping.TryAddMapping(connectionId, sourceServiceId.Value);
        }
    }

    public IInstance? TryGetInstanceByConnectionId(string connectionId)
    {
        if (_connectionToInstanceMapping.TryGetValue(connectionId, out var instanceId))
        {
            if (_instanceStore.TryGetValue(instanceId, out var instance))
            {
                return instance;
            }
        }

        return null;
    }

    public IInstance? TryGetInstance(Guid instanceId)
    {
        return _instanceStore.GetValueOrDefault(instanceId);
    }

    public IInstance? TryGetInstanceByGamecode(string code)
    {
        if (_codeToInstanceMapping.TryGetValue(code, out var instanceId))
        {
            if (_instanceStore.TryGetValue(instanceId, out var instance))
            {
                return instance;
            }
        }

        return null;
    }

    private class StringToGuidMapping
    {
        private readonly ConcurrentDictionary<string, Guid> _stringToGuid = [];
        private readonly ConcurrentDictionary<Guid, ConcurrentDictionary<string, object>> _reverseMapping = [];

        public bool TryAddMapping(string s, Guid g)
        {
            if (!_stringToGuid.TryAdd(s, g)) return false;

            var b = _reverseMapping.GetOrAdd(g, _ => []);
            b.TryAdd(s, null!);

            return true;
        }

        public void RemoveMapping(string s)
        {
            _stringToGuid.Remove(s, out var g);

            if (_reverseMapping.TryGetValue(g, out var list))
            {
                list.TryRemove(s, out _);
                if (list.Count == 0)
                {
                    _reverseMapping.TryRemove(g, out _);
                }
            }
        }

        public void RemoveMappingByValue(Guid g)
        {
            if (_reverseMapping.TryRemove(g, out var list))
            {
                foreach (var s in list.Keys)
                {
                    _stringToGuid.TryRemove(s, out _);
                }
            }
        }

        public bool TryGetValue(string connectionId, out Guid id)
        {
            return _stringToGuid.TryGetValue(connectionId, out id);
        }
    }

    private class ConcurrentReverseAccessDictionary<TKey, TValue>
        where TKey : notnull
        where TValue : notnull
    {
        private readonly ConcurrentDictionary<TKey, TValue> _keyToValue = [];
        private readonly ConcurrentDictionary<TValue, ConcurrentDictionary<TKey, object>> _valueToKeys = [];

        public bool TryAddMapping(TKey key, TValue value)
        {
            if (!_keyToValue.TryAdd(key, value)) return false;

            var b = _valueToKeys.GetOrAdd(value, _ => []);
            b.TryAdd(key, null!);

            return true;
        }

        public void RemoveMapping(TKey key)
        {
            if (_keyToValue.Remove(key, out var value))
            {
                if (_valueToKeys.TryGetValue(value, out var list))
                {
                    list.TryRemove(key, out _);
                    if (list.IsEmpty)
                    {
                        _valueToKeys.TryRemove(value, out _);
                    }
                }
            }
        }

        public void RemoveMappingByValue(TValue value, out IReadOnlyList<TKey> removedKeys)
        {
            var tRemovedKeys = new HashSet<TKey>();
            if (_valueToKeys.TryRemove(value, out var keyList))
            {
                foreach (var key in keyList.Keys)
                {
                    if (_keyToValue.TryRemove(key, out _))
                    {
                        tRemovedKeys.Add(key);
                    }
                }
            }

            removedKeys = tRemovedKeys.ToList();
        }

        public bool TryGetValue(TKey key, out TValue? value)
        {
            return _keyToValue.TryGetValue(key, out value);
        }

        public IReadOnlyList<TKey> GetKeysWithValue(TValue value)
        {
            return _valueToKeys.TryGetValue(value, out var keys) ? [..keys.Keys] : [];
        }
    }

    public int GetInstanceCount()
    {
        return _instanceStore.Count;
    }

    public IReadOnlyList<string> GetConnectionIdsOf(Guid sourceServiceId)
    {
        return _connectionToSourceServiceMapping.GetKeysWithValue(sourceServiceId);
    }
}