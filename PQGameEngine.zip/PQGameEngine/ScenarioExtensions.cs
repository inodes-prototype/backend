using PQGameEngine.Enums;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Templates;

namespace PQGameEngine;

public static class ScenarioExtensions
{
    public static bool IsDefenderPreSetupModeEnabled(this ScenarioTemplate scenarioTemplate, GameInstance game)
    {
        return game.Options.DefenderPreSetupMode switch
        {
            GameOptionDefenderPreSetupMode.ScenarioDefined when
                scenarioTemplate.ActiveGoalSet.DefenderPreSetupActionLimit > 0 => true,
            GameOptionDefenderPreSetupMode.AttributeBased => true,
            _ => false
        };
    }

    public static int GetDefenderPreSetupActionNumber(this ScenarioTemplate scenarioTemplate, GameInstance game,
        ActorModel actor)
    {
        return game.Options.DefenderPreSetupMode switch
        {
            GameOptionDefenderPreSetupMode.ScenarioDefined =>
                scenarioTemplate.ActiveGoalSet.DefenderPreSetupActionLimit ?? 0,
            GameOptionDefenderPreSetupMode.AttributeBased => actor.CurrentDet,
            _ => 0
        };
    }
}