﻿namespace PQGameEngine;

public static class GeneralExtensions
{
    public static bool In<T>(this T field, params T[] values) where T : struct
    {
        if (values == null! || values.Length == 0) return false;
        foreach (var value in values)
        {
            if (field.Equals(value)) return true;
        }

        return false;
    }

    public static bool NotIn<T>(this T field, params T[] values) where T : struct
    {
        if (values == null! || values.Length == 0) return false;
        return !field.In(values);
    }

    public static bool IsNullOrWhitespace(this string? s)
    {
        return string.IsNullOrWhiteSpace(s);
    }

    public static T TryConvertTo<T>(this short num)
    {
        var o = (object)(int)num;
        if (!Enum.IsDefined(typeof(T), o))
            throw new InvalidCastException($"Value {num} is not defined in '{typeof(T)}'");
        return (T)o;
    }

    public static T TryConvertTo<T>(this int num)
    {
        var o = (object)num;
        if (!Enum.IsDefined(typeof(T), o))
            throw new InvalidCastException($"Value {num} is not defined in '{typeof(T)}'");
        return (T)o;
    }
}