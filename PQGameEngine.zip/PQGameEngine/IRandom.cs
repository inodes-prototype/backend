﻿namespace PQGameEngine;

public interface IRandom
{
    int Next(int count);

    int Next(int minValue, int maxValue);

    void Shuffle<T>(T[] array);
}