using PQGameEngine.Enums;
using PQGameEngine.Templates;

namespace PQGameEngine.Functionality;

public interface IAffectsActions
{
    HashSet<Guid> AffectedAttackActions { get; }
    HashSet<Guid> AffectedDefenseActions { get; }

    public bool Affects(ActionTemplate actionTemplate, bool dontAffectOnEmptyList = false)
    {
        var affectedActions = actionTemplate.ActionType
            switch
            {
                ActionTypes.Attack => AffectedAttackActions,
                ActionTypes.Defense => AffectedDefenseActions,
                _ => throw new ArgumentException(
                    $"Invalid action type {actionTemplate.ActionType} on action {actionTemplate.Id}")
            };

        if (affectedActions == null! || affectedActions.Count == 0)
        {
            if (dontAffectOnEmptyList) return false;
            return true;
        }

        return affectedActions.Contains(actionTemplate.Id);
    }
}