using PQGameEngine.Enums;
using PQGameEngine.Factories;
using PQGameEngine.Functionality.Effects;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality;

public static class EventHelper
{
    public static void MarkEventDetected(GameInstance game, GameEngineDependencies geDeps, ActionEvent actionEvent,
        ActorModel detectingActor)
    {
        if (!actionEvent.Detected.TryAdd(detectingActor.Id, game.Turn)) return;

        game.ActorStats().ActionDetected(detectingActor);

        var eventActor = game.Actors[actionEvent.Actor];
        if (eventActor.IsAttacker && detectingActor.IsDefender)
        {
            DetectionHelper.TryFlagAttackerDetectedFirstTime(game, geDeps, eventActor, detectingActor);
        }
    }

    public static void ApplyPermanentEquipment(GameInstance game, GameEngineDependencies geDeps,
        ActionEvent actionEvent, ActorModel actor)
    {
        ApplyOnlyPermanentEquipment(game, geDeps, actor.Equipment, actionEvent, actor, true);

        if (actor.Id != actionEvent.Actor)
        {
            ActorModel originalActor = game.Actors[actionEvent.Actor];
            ApplyOnlyPermanentEquipment(game, geDeps, originalActor.Equipment, actionEvent, actor, true);
        }

        if (actionEvent is AssetActionEvent assetActionEvent)
        {
            AssetModel asset = game.Assets[assetActionEvent.AssetId];

            ApplyOnlyPermanentEquipment(game, geDeps, asset.InfluencedByEquipment, actionEvent, actor, false);

            if (asset.Owner != actor.Id && asset.Owner != actionEvent.Actor)
            {
                ActorModel assetOwnerActor = game.Actors[asset.Owner.Value];
                ApplyOnlyPermanentEquipment(game, geDeps, assetOwnerActor.Equipment, actionEvent, actor, true);
            }
        }
    }

    private static void ApplyOnlyPermanentEquipment(GameInstance game, GameEngineDependencies geDeps,
        List<int> equipment, ActionEvent actionEvent, ActorModel actor, bool globalEquipmentOnly)
    {
        foreach (int equipmentId in equipment)
        {
            EquipmentModel eq = game.Equipment[equipmentId];

            if (globalEquipmentOnly && !eq.IsGlobalEquipment())
            {
                continue;
            }

            if (eq.IsPermanentEquipment() && eq.Active && eq.Template.Affects(actionEvent.MainAction.Template))
            {
                ApplyEquipment(game, geDeps, eq, actionEvent, actor);
                actionEvent.InfluencedByEquipment.Add(eq.Id);
            }
        }
    }

    public static void ApplyEquipment(GameInstance game, GameEngineDependencies geDeps, EquipmentModel equipment,
        ActionEvent actionEvent, ActorModel actor)
    {
        foreach (var effectId in equipment.Effects)
        {
            var effect = game.Effects[effectId];
            EffectBehaviorFactory.Create(game, geDeps, effect)
                .Apply(actionEvent, EffectTimingType.PreSuccess, actionEvent);
        }

        foreach (var effectId in equipment.TransferEffects)
        {
            var t = game.Effects[effectId];
            actionEvent.AddEffect(ModelFactories.CreateEffect(game, t.Template.Id, t.OwnerId, null,
                equipment.Template.Id));
        }
    }

    public static DamageModel GetActiveDamage(GameInstance game, AssetActionEvent actionEvent, ActorModel? actor)
    {
        if (actionEvent.AssetId == 0) return DamageModel.Zero;

        if (actor != null && !actionEvent.Detected.ContainsKey(actor.Id))
            return DamageModel.Zero;

        DamageModel currentDamageDealt = actionEvent.DamageDealt;

        foreach (var defActionEventId in actionEvent.CounteredByEvents)
        {
            var defActionEvent = (ActionEvent)game.Events[defActionEventId];
            if ((actor == null || defActionEvent.Detected.ContainsKey(actor.Id)) &&
                defActionEvent is AssetActionEvent assetActionEvent)
            {
                currentDamageDealt += assetActionEvent.DamageDealt;
            }
        }

        return currentDamageDealt;
    }
}