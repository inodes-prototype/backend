﻿using PQGameEngine.Enums;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality;

public static class AssetHelper
{
    public static void NotifyAssetsChanged(GameInstance game, GameEngineDependencies geDeps, ActorTypes actorType)
    {
        foreach (var asset in game.Assets.Values)
        {
            if (asset.HasAssetChanged(actorType))
            {
                geDeps.Notifier.AssetChanged(game.Actors.Values.Where(x => x.Type == actorType), game, asset);
                asset.ResetAssetChangedState(actorType);
            }
        }
    }

    public static DamageModel DealDamageToAsset(GameInstance game, GameEngineDependencies geDeps, AssetModel asset,
        DamageModel incomingDamage, AssetActionEvent actionEvent, ActorModel actor, int turn)
    {
        if (incomingDamage.All(x => x == 0))
        {
            return DamageModel.Zero;
        }

        var oldDamage = asset.CurrentDamage;
        var newDamage = new DamageModel(
            Math.Max((-1) * oldDamage.C, Math.Min(Constants.DMG_MAX - oldDamage.C, incomingDamage.C)),
            Math.Max((-1) * oldDamage.I, Math.Min(Constants.DMG_MAX - oldDamage.I, incomingDamage.I)),
            Math.Max((-1) * oldDamage.A, Math.Min(Constants.DMG_MAX - oldDamage.A, incomingDamage.A))
        );

        if (newDamage.All(x => x == 0))
        {
            return newDamage;
        }

        asset.AddDamage(newDamage, actionEvent.Id);
        geDeps.Logger.LogDebug(
            "Damage on {Asset} changed due to {ActionEvent}: {PreviousCurrentDamage} + {IncomingDamage} = {CurrentDamage}",
            asset, actionEvent, oldDamage, incomingDamage, asset.CurrentDamage);


        if (oldDamage.I < Constants.DMG_MAX && asset.CurrentDamage.I == Constants.DMG_MAX)
        {
            ExposeAttackVector(game, geDeps, asset, actionEvent, actor);
        }
        else if (oldDamage.I == Constants.DMG_MAX && asset.CurrentDamage.I < Constants.DMG_MAX)
        {
            foreach (var (assetId, exposedType) in asset.Template.AttackVectors ?? [])
            {
                var nextAsset = game.Assets[assetId];
                if (nextAsset.ExposedPointerCount == 1)
                {
                    nextAsset.SetExposed(ExposedModel.NotExposed, actionEvent.Id);
                    actionEvent.UnexposedAssets.Add(nextAsset.Id);
                    geDeps.Logger.LogDebug("Unexposed asset {Asset}", nextAsset);
                    foreach (var actorId in nextAsset.RevealedTo)
                    {
                        if (actorId != nextAsset.Owner && !nextAsset.CurrentExposedState.Any())
                        {
                            var actorSeen = game.Actors[actorId];
                            RemoveVisibleAsset(geDeps, actorSeen, nextAsset);
                        }
                    }
                }

                asset.ExposedPointerCount -= 1;
            }
        }

        if (oldDamage.A == Constants.DMG_MAX && asset.CurrentDamage.A < Constants.DMG_MAX)
        {
            UncoverAttackVector(game, geDeps, asset, new HashSet<int>(), actionEvent, actor: actor);
        }

        if (oldDamage.A < Constants.DMG_MAX && asset.CurrentDamage.A == Constants.DMG_MAX)
        {
            CoverAttackVector(game, geDeps, asset, new HashSet<int>(), actionEvent);
        }

        foreach (char c in "CIA")
        {
            if (oldDamage[c] < Constants.DMG_MAX && asset.CurrentDamage[c] == Constants.DMG_MAX)
            {
                actionEvent.CompromisedTypes.Add(c);
                ApplyDependencyDamage(game, geDeps, asset, c, actionEvent, actor, turn, false);
                game.ActorStats().CompromisedSystem(actor, asset);
            }
            else if (oldDamage[c] == Constants.DMG_MAX &&
                     asset.CurrentDamage[c] < Constants.DMG_MAX)
            {
                actionEvent.UncompromisedTypes.Add(c);
                ApplyDependencyDamage(game, geDeps, asset, c, actionEvent, actor, turn, true);
                game.ActorStats().UnCompromisedSystem(actor, asset);
            }
        }

        if (asset.First3CDamageEventId == null && asset.CurrentDamage['C'] == 3 && actor.IsAttacker)
        {
            asset.First3CDamageEventId = actionEvent.Id;
            actionEvent.InitiallyCompromisedTypes.Add('C');
            actor.ChangeIns(1, actionEvent.Id);
            geDeps.Notifier.AttributeChanged(actor, ChangedPlayerAttributeType.Insight, actor.CurrentIns);
        }

        if (asset.First3IDamageEventId == null && asset.CurrentDamage['I'] == 3 && actor.IsAttacker)
        {
            asset.First3IDamageEventId = actionEvent.Id;
            actionEvent.InitiallyCompromisedTypes.Add('I');
        }

        if (asset.First3ADamageEventId == null && asset.CurrentDamage['A'] == 3 && actor.IsAttacker)
        {
            asset.First3ADamageEventId = actionEvent.Id;
            actionEvent.InitiallyCompromisedTypes.Add('A');
        }

        return newDamage;
    }

    private static void ApplyDependencyDamage(GameInstance game, GameEngineDependencies geDeps, AssetModel asset,
        char damageType, AssetActionEvent actionEvent, ActorModel actor, int turn, bool unapply)
    {
        foreach (var (nextAssetId, depDamage) in asset.Template.Dependencies)
        {
            var nextAsset = game.Assets[nextAssetId];

            if (depDamage[damageType] > 0)
            {
                if (unapply)
                {
                    foreach (var eventId in asset.PlayedActionEvents)
                    {
                        if (game.Events[eventId] is AssetActionEvent aae &&
                            aae.AppliedDependencyDamage.TryGetValue(nextAssetId, out var prevAppliedDepDmg) &&
                            prevAppliedDepDmg[damageType] > 0)
                        {
                            var dmgToRevert = prevAppliedDepDmg.ApplyMask(damageType.ToString());

                            DealDamageToAsset(game, geDeps, nextAsset, dmgToRevert.Invert(), actionEvent, actor,
                                game.Turn);

                            var remainingDepDmg = prevAppliedDepDmg - dmgToRevert;

                            if (remainingDepDmg == DamageModel.Zero)
                            {
                                aae.AppliedDependencyDamage.Remove(nextAssetId);
                            }
                            else
                            {
                                aae.AppliedDependencyDamage[nextAssetId] = remainingDepDmg;
                            }

                            nextAsset.MarkAssetAsChanged();
                        }
                    }
                }
                else
                {
                    if (nextAsset.IsOffline)
                    {
                        continue;
                    }

                    var damage = depDamage.ApplyMask(damageType.ToString());
                    var appliedDamage = DealDamageToAsset(game, geDeps, nextAsset, damage, actionEvent, actor, turn);

                    if (appliedDamage[damageType] > 0)
                    {
                        if (actionEvent.AppliedDependencyDamage.TryGetValue(nextAssetId, out var currentDepDmgOnAsset))
                        {
                            currentDepDmgOnAsset[damageType] = appliedDamage[damageType];
                            actionEvent.AppliedDependencyDamage[nextAssetId] = currentDepDmgOnAsset;
                        }
                        else
                        {
                            actionEvent.AppliedDependencyDamage.Add(nextAssetId, appliedDamage);
                        }

                        nextAsset.MarkAssetAsChanged();
                    }
                }
            }
        }
    }

    private static void ExposeAttackVector(GameInstance game, GameEngineDependencies geDeps, AssetModel asset,
        AssetActionEvent actionEvent, ActorModel actor)
    {
        foreach (var (assetId, exposedType) in asset.Template.AttackVectors ?? [])
        {
            var neighboringAsset = game.Assets[assetId];
            actionEvent.ExposedAssets.Add(neighboringAsset.Id);
            ExposeSingleAsset(geDeps, neighboringAsset, ExposedModel.From(exposedType), actionEvent, actor);
            actionEvent.AddExposedAssetInfo(neighboringAsset.Id);
        }
    }

    private static void UncoverAttackVector(GameInstance game, GameEngineDependencies geDeps, AssetModel asset,
        HashSet<int> assetsAlreadyExposed, AssetActionEvent actionEvent, ActorModel actor)
    {
        if (!assetsAlreadyExposed.Contains(asset.Id))
        {
            if (asset.ExposedHistory.Count > 0)
            {
                ExposeSingleAsset(geDeps, asset, asset.ExposedHistory[^1].Item1, actionEvent, actor);
            }
            else
            {
                ExposeSingleAsset(geDeps, asset, asset.Template.InitialExposedState, actionEvent, actor);
            }

            if (asset.PreviouslyExposedTo.Count > 0)
            {
                foreach (int actorId in asset.PreviouslyExposedTo)
                {
                    var exposedActor = game.Actors[actorId];
                    AddVisibleAsset(geDeps, exposedActor, asset);
                }

                asset.PreviouslyExposedTo.Clear();
            }

            assetsAlreadyExposed.Add(asset.Id);

                                    if (asset.CurrentDamage.I == Constants.DMG_MAX)
            {
                foreach (var (nextAssetId, exposedType) in asset.Template.AttackVectors ?? [])
                {
                    var nextAsset = game.Assets[nextAssetId];
                    UncoverAttackVector(game, geDeps, nextAsset, assetsAlreadyExposed, actionEvent, actor);
                }
            }
        }
    }

                private static void ExposeSingleAsset(GameEngineDependencies geDeps, AssetModel asset, ExposedModel exposed,
        ActionEvent actionEvent, ActorModel actor)
    {
        asset.SetExposed(exposed, actionEvent.Id);
        asset.ExposedPointerCount++;
        geDeps.Logger.LogDebug("Changed exposed status of {Asset} to {ExposedState}", asset, exposed);

        if (actor != null! && exposed.Any())
        {
            AddVisibleAsset(geDeps, actor, asset);
        }
    }

                private static void AddVisibleAsset(GameEngineDependencies geDeps, ActorModel actor, AssetModel asset)
    {
        if (actor.VisibleAssets.Add(asset.Id))
        {
            actor.KnownAssets.Add(asset.Id);
        }

        asset.RevealedTo.Add(actor.Id);

        geDeps.Logger.LogDebug("Actor {Actor} sees new asset {Asset}", actor, asset);
    }

                    private static void CoverAttackVector(GameInstance game, GameEngineDependencies geDeps, AssetModel asset,
        HashSet<int> assetsAlreadyCovered, ActionEvent actionEvent)
    {
        if (!assetsAlreadyCovered.Contains(asset.Id))
        {
            if (asset.ExposedPointerCount == 1)
            {
                asset.PreviouslyExposedTo.Clear();
                foreach (var t in asset.RevealedTo)
                {
                    asset.PreviouslyExposedTo.Add(t);
                }

                asset.SetExposed(ExposedModel.NotExposed, actionEvent.Id);
                geDeps.Logger.LogDebug("Unexposed asset {Asset}", asset);

                foreach (var actorId in asset.RevealedTo)
                {
                    if (actorId != asset.Owner)
                    {
                        var actor = game.Actors[actorId];
                        RemoveVisibleAsset(geDeps, actor, asset);
                    }
                }

                assetsAlreadyCovered.Add(asset.Id);

                                                if (asset.CurrentDamage.I == Constants.DMG_MAX)
                {
                    foreach (var (nextAssetId, _) in asset.Template.AttackVectors ?? [])
                    {
                        var nextAsset = game.Assets[nextAssetId];
                        CoverAttackVector(game, geDeps, nextAsset, assetsAlreadyCovered, actionEvent);
                    }
                }
            }

            asset.ExposedPointerCount--;
        }
    }

                private static void RemoveVisibleAsset(GameEngineDependencies geDeps, ActorModel actor, AssetModel asset)
    {
        if (actor.VisibleAssets.Contains(asset.Id))
        {
            actor.VisibleAssets.Remove(asset.Id);
        }

        if (asset.RevealedTo.Contains(actor.Id))
        {
            asset.RevealedTo.Remove(actor.Id);
        }

        geDeps.Logger.LogDebug("Actor {Actor} no longer sees asset {Asset}", actor, asset);
    }

    public static List<AssetModel> GetRelevantAssetsForDefPenalty(GameInstance game, ActorModel? owner)
    {
        if (game.Options.AvailabilityPenalty != GameOptionDefenderAvailabilityPenaltyMode.Enabled) return [];

        var res = new List<AssetModel>();
        foreach (var asset in game.Assets.Values.Where(x => owner == null || owner.OwnAssets.Contains(x.Id)))
        {
            if (asset.Template.Def3APenaltyRoundsToLoose > 0 && asset.IsOffline)
            {
                res.Add(asset);
            }
        }

        return res;
    }
}