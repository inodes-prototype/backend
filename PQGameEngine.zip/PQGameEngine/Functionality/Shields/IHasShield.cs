namespace PQGameEngine.Functionality.Shields;

public interface IHasShield<out TShieldType> where TShieldType : ShieldBase
{
    public IReadOnlyCollection<TShieldType> GetAvailableShields();
}