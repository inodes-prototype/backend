using PQGameEngine.Enums;
using PQGameEngine.Functionality.Effects;
using PQGameEngine.Instances;
using PQGameEngine.Models.GameEvents;
using PQGameEngine.Models.Internal;

namespace PQGameEngine.Functionality.Shields;

public class InsightShieldHelper(GameInstance game, GameEngineDependencies geDeps, IHasInsightShield target)
    : ShieldHelperBase<InsightShield, IHasInsightShield, ActorModifier>(game, geDeps, target)
{
    public static InsightShieldHelper Create(GameInstance game, GameEngineDependencies geDeps, IHasInsightShield target)
    {
        return new InsightShieldHelper(game, geDeps, target);
    }

    protected override bool AutoDetectionOfShield { get; } = false;

    protected override bool CheckShieldApplies(InsightShield shield, ActorModifier applyShieldTo)
    {
        var actionEventCausingImpact = (ActionEvent)Game.Events[applyShieldTo.EventId];
        return EffectBehaviorFactory.Create(Game, GeDeps, shield.GrantingEffect)
            .CheckApply(actionEventCausingImpact, EffectTimingType.PostSuccess);
    }

    protected override bool ApplyShield(InsightShield shield, ActorModifier applyShieldTo)
    {
        if (applyShieldTo.TryReduceValueBy(shield.GrantingEffect.Id,
                shield.GrantingEffect.RemainigShieldStrength, out var reduction))
        {
            shield.GrantingEffect.ReduceShieldAmount(reduction, applyShieldTo.EventId);
            Game.ActorStats().InsightPrevented(Game.Actors[shield.CausingEvent.Actor], reduction);
            return true;
        }

        return false;
    }
}