using PQGameEngine.Enums;
using PQGameEngine.Functionality.Effects;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality.Shields;

public class DamageShieldHelper(GameInstance game, GameEngineDependencies geDeps, IHasDamageShield target)
    : ShieldHelperBase<DamageShield, IHasDamageShield, AssetActionEvent>(game, geDeps, target)
{
    public static DamageShieldHelper Create(GameInstance game, GameEngineDependencies geDeps, IHasDamageShield target)
    {
        return new DamageShieldHelper(game, geDeps, target);
    }

    protected override bool CheckShieldApplies(DamageShield shield, AssetActionEvent applyShieldTo)
    {
        return EffectBehaviorFactory.Create(Game, GeDeps, shield.GrantingEffect)
            .CheckApply(applyShieldTo, EffectTimingType.PostSuccess);
    }

    protected override bool ApplyShield(DamageShield shield, AssetActionEvent applyShieldTo)
    {
        var relevantImpact = applyShieldTo.CurrentImpact.ApplyMask(applyShieldTo.AttackMaskUsed);
        var relevantDamageSum = relevantImpact.Sum();
        decimal prob = 1;
        if (shield.GrantingEffect.Template.ShieldProbabilities.Count > 0)
        {
            prob = shield.GrantingEffect.Template.ShieldProbabilities[0].Proability;
            if (shield.GrantingEffect.RemainingTurns > 0 &&
                shield.GrantingEffect.Template.ShieldProbabilities.Count > 1)
            {
                var t = shield.GrantingEffect.Template.ShieldProbabilities.FirstOrDefault(x =>
                    x.Turn == (shield.GrantingEffect.Template.Duration ?? EffectModel.MAX_EFFECT_TURNS) -
                    shield.GrantingEffect.RemainingTurns + 1);

                if (t == null)
                {
                    t = shield.GrantingEffect.Template.ShieldProbabilities.MaxBy(x => x.Turn);
                }

                prob = t!.Proability;
            }
        }

        var newImpact = applyShieldTo.CurrentImpact;
        if (Game.Random.DidMyRollSucceed(prob, out _))
        {
            var absorbedDmg = 0;
            if (relevantDamageSum <= shield.GrantingEffect.RemainigShieldStrength)
            {
                newImpact = DamageModel.Zero;
                applyShieldTo.Deflected = DeflectedType.FullyDeflected;
                applyShieldTo.DeflectedBy.Add((shield.CausingEvent.Id, DeflectedType.FullyDeflected, relevantImpact));
                shield.GrantingEffect.ReduceShieldAmount(relevantDamageSum, shield.CausingEvent.Id);
                absorbedDmg = relevantDamageSum;
                Game.ActorStats().DamagePrevented(Game.Actors[shield.CausingEvent.Actor], relevantDamageSum);
                GeDeps.Logger.LogDebug("shield fully deflected the attack");
            }
            else if (relevantDamageSum > shield.GrantingEffect.RemainigShieldStrength)
            {
                newImpact = applyShieldTo.CurrentImpact;
                while (shield.GrantingEffect.RemainigShieldStrength > 0)
                {
                    var asset = Game.Assets[applyShieldTo.AssetId];
                    var potentialDamage = asset.CurrentDamage + relevantImpact;
                    var maxPotentialDamage = potentialDamage.MaxIdx();
                    var reducedBy = Math.Min(newImpact[maxPotentialDamage],
                        shield.GrantingEffect.RemainigShieldStrength);
                    var reducedByDamage = DamageModel.Zero;
                    reducedByDamage[maxPotentialDamage] = reducedBy;
                    newImpact -= reducedByDamage;
                    relevantImpact -= reducedByDamage;
                    shield.GrantingEffect.ReduceShieldAmount(reducedBy, shield.CausingEvent.Id);
                    absorbedDmg += reducedBy;
                    Game.ActorStats().DamagePrevented(Game.Actors[shield.CausingEvent.Actor], reducedBy);
                }

                applyShieldTo.Deflected = DeflectedType.PartiallyDeflected;
                applyShieldTo.DeflectedBy.Add(
                    (shield.CausingEvent.Id, DeflectedType.PartiallyDeflected, relevantImpact));
            }

            applyShieldTo.SetImpact(newImpact);

            GeDeps.Logger.LogDebug(
                "damage shield {Effect} absorbed {AbsorbedDamage} damage points - shield left: {Damage}",
                shield.GrantingEffect, absorbedDmg, shield.GrantingEffect.RemainigShieldStrength);

            return true;
        }

        return false;
    }
}