using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality.Shields;

public abstract class ShieldHelperBase<TShieldType, THasShield, TShieldApplicable>
    where TShieldType : ShieldBase
    where THasShield : IHasShield<TShieldType>
    where TShieldApplicable : IShieldApplicable<TShieldType>
{
    protected readonly THasShield Target;
    protected readonly GameInstance Game;
    protected readonly GameEngineDependencies GeDeps;

    protected ShieldHelperBase(GameInstance game, GameEngineDependencies geDeps, THasShield target)
    {
        Target = target;
        Game = game;
        GeDeps = geDeps;
    }

    protected virtual bool AutoDetectionOfShield { get; } = true;

    public void TryApplyTo(TShieldApplicable applyShieldTo)
    {
        foreach (var shield in Target.GetAvailableShields())
        {
            if (IsShieldActive(shield.GrantingEffect))
            {
                if (CheckShieldApplies(shield, applyShieldTo))
                {
                    var wasApplied = ApplyShield(shield, applyShieldTo);
                    if (wasApplied && AutoDetectionOfShield)
                    {
                        MarkDetected(shield, applyShieldTo);
                    }
                }
            }

            if (shield.GrantingEffect.RemainigShieldStrength <= 0 && shield.GrantingEffect.IsActive)
            {
                shield.GrantingEffect.Deactivate();
            }
        }
    }

    private void MarkDetected(TShieldType shield, TShieldApplicable applyShieldTo)
    {
        var affectedSourceActionEvent = (ActionEvent)Game.Events[applyShieldTo.GetSourceActionEventId()];

        if (shield.CausingEvent is AssetActionEvent se && !se.Detected.ContainsKey(affectedSourceActionEvent.Actor))
        {
            se.Detected[affectedSourceActionEvent.Actor] = Game.Turn;
        }

        if (affectedSourceActionEvent.MainAction.Detectable)
        {
            EventHelper.MarkEventDetected(Game, GeDeps, affectedSourceActionEvent,
                Game.Actors[shield.GrantingEffect.OwnerId]);
            GeDeps.Notifier.ActionsDetected(Game.Actors[shield.GrantingEffect.OwnerId], Game,
                [affectedSourceActionEvent.MainAction]);
        }

        if (affectedSourceActionEvent is AssetActionEvent aee)
        {
            Game.Assets[aee.AssetId].MarkAssetAsChanged();
        }
    }

    protected virtual bool IsShieldActive(EffectModel effect)
    {
        return effect.IsActive && effect.RemainigShieldStrength > 0;
    }

    protected virtual bool CheckShieldApplies(TShieldType shield, TShieldApplicable applyShieldTo)
    {
        return true;
    }

    protected abstract bool ApplyShield(TShieldType shield, TShieldApplicable applyShieldTo);
}