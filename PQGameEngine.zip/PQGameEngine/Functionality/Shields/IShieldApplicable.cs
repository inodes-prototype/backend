namespace PQGameEngine.Functionality.Shields;

public interface IShieldApplicable<TShieldType> where TShieldType : ShieldBase
{
    Guid GetSourceActionEventId();
}