namespace PQGameEngine.Functionality.Shields;

public interface IHasInsightShield : IHasShield<InsightShield>
{
    public List<InsightShield> InsightShields { get; }

    IReadOnlyCollection<InsightShield> IHasShield<InsightShield>.GetAvailableShields()
    {
        return InsightShields;
    }
}