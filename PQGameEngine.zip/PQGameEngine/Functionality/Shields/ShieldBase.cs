using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality.Shields;

public abstract class ShieldBase(EffectModel grantingEffect, ActionEvent causingEvent)
{
    public EffectModel GrantingEffect { get; } = grantingEffect;
    public ActionEvent CausingEvent { get; } = causingEvent;
}