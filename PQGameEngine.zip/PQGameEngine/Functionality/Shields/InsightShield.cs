using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality.Shields;

public class InsightShield(EffectModel grantingEffect, ActionEvent causingEvent)
    : ShieldBase(grantingEffect, causingEvent)
{
}