namespace PQGameEngine.Functionality.Shields;

public interface IHasDamageShield : IHasShield<DamageShield>
{
    public List<DamageShield> DamageShields { get; }

    IReadOnlyCollection<DamageShield> IHasShield<DamageShield>.GetAvailableShields()
    {
        return DamageShields;
    }
}