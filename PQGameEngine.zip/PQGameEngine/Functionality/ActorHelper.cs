﻿using PQGameEngine.Enums;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality;

public static class ActorHelper
{
    public static int GetActionLimit(GameInstance game, ActorModel actor)
    {
        if (actor.IsDefender && game.Phase == GamePhase.DefenderPreSetup)
            return game.Scenario.GetDefenderPreSetupActionNumber(game, actor);

        return 3 + actor.CurrentDet;
    }

    public static bool IsActorMissingActions(GameInstance game, ActorModel actor)
    {
        return actor.Actions.Count < GetActionLimit(game, actor);
    }

    public static int GetNumberOfActionsToDraw(GameInstance game, ActorModel actor)
    {
        if (actor.IsDefender && game.Phase == GamePhase.DefenderPreSetup)
        {
            return GetRemainingPreSetupActionsToDraw(game, actor);
        }

        var requiredAmount = 0;

        if (game.Options.SupportActionsMode == GameOptionSupportActionsMode.ALL_AT_START)
        {
            int amountMainActions = actor.Actions.Count(aid => game.Actions[aid].IsMainAction);
            requiredAmount = GetActionLimit(game, actor) - amountMainActions;
        }
        else
        {
            requiredAmount = GetActionLimit(game, actor) - actor.Actions.Count;
        }

        if (requiredAmount < 0)
            return 0;

        return requiredAmount;
    }

    public static int GetRemainingPreSetupActionsToDraw(GameInstance game, ActorModel actor)
    {
        if (!actor.IsDefender || game.Phase != GamePhase.DefenderPreSetup) return 0;

        var alreadyPlayedActions =
            game.Events.Values.Count(x => x is PlayedActionEvent pae && pae.ActorId == actor.Id);
        return game.Scenario.GetDefenderPreSetupActionNumber(game, actor) - actor.Actions.Count -
               alreadyPlayedActions;
    }

    public static void GrantDefenderIncome(GameInstance game, Notifier notifier, ActorModel defender)
    {
        var addCredits = true;

        decimal assetOfflineCreditPenalty = 0;
        decimal income = 0;

        if (game.Options.AvailabilityPenalty == GameOptionDefenderAvailabilityPenaltyMode.Enabled)
        {
            foreach (var assetId in defender.OwnAssets)
            {
                var asset = game.Assets[assetId];

                if (asset.IsOffline)
                {
                    if (asset.Template.Def3APenaltyNoIncome)
                    {
                        addCredits = false;

                        game.GameboardLog.AddEntry(defender, GameboardLogMessageType.DefPenaltyIncomeFrozen, c => c
                            .SetInfo(game.Assets[assetId])
                        );
                    }

                    if (asset.Template.Def3APenaltyCreditsPerRound > 0)
                    {
                        assetOfflineCreditPenalty += asset.Template.Def3APenaltyCreditsPerRound ?? 0;

                        game.GameboardLog.AddEntry(defender, GameboardLogMessageType.DefPenaltyIncomePenalty, c => c
                            .SetInfo(game.Assets[assetId])
                            .SetCredits(asset.Template.Def3APenaltyCreditsPerRound!.Value)
                        );
                    }
                }
            }
        }

        if (addCredits)
        {
            var turnIncome = defender.GetIncomePerTurn();
            income = turnIncome;

            game.GameboardLog.AddEntry(defender, GameboardLogMessageType.InfoIncomePeriodicDefender, c => c
                .SetCredits(turnIncome)
            );
        }

        income = income - assetOfflineCreditPenalty;

        if (income != 0)
        {
            var incomeEvent = new IncomePerTurnEvent(game.Turn, defender.Id, income);
            game.AddEvent(incomeEvent);
            defender.ChangeCredits(income, incomeEvent.Id);
            notifier.AttributeChanged(defender, ChangedPlayerAttributeType.Credits,
                Math.Round(defender.CurrentCredits, 2));
        }
    }

    public static bool HasLostBecauseOf3APenatly(GameInstance game, ActorModel actor)
    {
        if (!actor.IsDefender) throw new ArgumentException($"Invalid actor '{actor.Type}'");

        foreach (var asset in AssetHelper.GetRelevantAssetsForDefPenalty(game, actor))
        {
            if (game.Events[asset.LastEventIdCausing3ADamage].Turn + asset.Template.Def3APenaltyRoundsToLoose <=
                game.Turn)
            {
                return true;
            }
        }

        return false;
    }

    public static void ReportAutoDefeatToGameboardLog(GameInstance game, ActorModel actor)
    {
        if (!actor.IsDefender) throw new ArgumentException($"Invalid actor '{actor.Type}'");

        foreach (var asset in AssetHelper.GetRelevantAssetsForDefPenalty(game, actor))
        {
            game.GameboardLog.AddEntry(actor, GameboardLogMessageType.DefPenaltyAutoDefeat, c => c
                .SetTurn(game.Events[asset.LastEventIdCausing3ADamage].Turn +
                    asset.Template.Def3APenaltyRoundsToLoose!.Value - game.Turn)
                .SetInfo(asset)
            );
        }
    }

    public static bool IsOutOfTurns(ActorModel actor)
    {
        if (!actor.IsAttacker) throw new ArgumentException($"Invalid actor '{actor.Type}'");

        if (actor.FirstActionDetected && actor.CurrentIni <= 0)
        {
            return true;
        }

        return false;
    }

    public static bool HasGoalsFulfilled(GameInstance game, ActorModel actor)
    {
        if (!actor.IsAttacker) throw new ArgumentException($"Invalid actor '{actor.Type}'");

        return GoalHelper.AreAttackerGoalsAchieved(game, actor);
    }

    public static Dictionary<int, (GamePlayerEndState state, string message)> DetermineEndGameStatePerPlayer(
        GameInstance game)
    {
        if (game.Actors.Values.Any(x => x.HasSurrendered))
        {
            return game.Actors.Values.ToDictionary(x => x.Id,
                x => (x.HasSurrendered ? GamePlayerEndState.Surrendered : GamePlayerEndState.Won,
                    x.HasSurrendered ? "You surrendered." : Constants.DEFAULT_SURRENDER_MESSAGE));
        }

        var onlineAttackers = game.Attackers.Values.Where(x => !x.HasLeft).ToList();

        if (onlineAttackers.Count == 0)
        {
            return game.Actors.Values.ToDictionary(x => x.Id,
                x => (x.IsAttacker ? GamePlayerEndState.Lost : GamePlayerEndState.Won,
                    x.IsAttacker ? "You left ..." : Constants.DEFAULT_SURRENDER_MESSAGE));
        }

        var onlineDefenders = game.Defenders.Values.Where(x => !x.HasLeft).ToList();

        if (onlineDefenders.Count == 0)
        {
            return game.Actors.Values.ToDictionary(x => x.Id,
                x => (x.IsDefender ? GamePlayerEndState.Lost : GamePlayerEndState.Won,
                    x.IsDefender ? "You left ..." : Constants.DEFAULT_SURRENDER_MESSAGE));
        }

        if (onlineAttackers.Any(x => HasGoalsFulfilled(game, x)))
        {
            return game.Actors.Values.ToDictionary(x => x.Id,
                x => (x.IsDefender ? GamePlayerEndState.Lost : GamePlayerEndState.Won,
                    x.IsDefender ? x.LostText : x.WonText));
        }

        if (onlineDefenders.Any(x => HasLostBecauseOf3APenatly(game, x)))
        {
            return game.Actors.Values.ToDictionary(x => x.Id,
                x => (DRAW: GamePlayerEndState.AutoDefeatAssetOffline,
                    x.IsAttacker ? Constants.DEFAULT_DRAW_MESSAGE_ATTACKER : Constants.DEFAULT_DRAW_MESSAGE_DEFENDER));
        }

        if (onlineAttackers.All(IsOutOfTurns))
        {
            return game.Actors.Values.ToDictionary(x => x.Id,
                x => (x.IsAttacker ? GamePlayerEndState.Lost : GamePlayerEndState.Won,
                    x.IsAttacker ? x.LostText : x.WonText));
        }

        throw new InvalidOperationException("This must not happen");
    }

    public static int GetMinApValue(ActorModel actor)
    {
        var minApValue = Constants.GAME_ENGINE_ACTION_POINTS_MIN_VALUE;
        if (actor is { IsAttacker: true, CurrentIni: <= 1 })
        {
            minApValue = 0;
        }

        return minApValue;
    }
}