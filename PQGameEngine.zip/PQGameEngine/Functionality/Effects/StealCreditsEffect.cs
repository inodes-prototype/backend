using PQGameEngine.Enums;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality.Effects;

public class StealCreditsEffect(GameInstance game, GameEngineDependencies geDeps, EffectModel effect)
    : EffectBehaviorBase(game, geDeps, effect)
{
    protected override bool SkipAutoChecksInApply { get; } = true;

    protected override void ApplyEffect(IEffectApplicable target, EffectTimingType timingFilter,
        ActionEvent activeEvent)
    {
        var actorPlayingIt = Game.Actors[Effect.OwnerId];

        foreach (var targetActor in Game.Actors.Values.Where(x => x.Id != actorPlayingIt.Id))
        {
            if (!CheckApplyInternal(targetActor, timingFilter)) continue;

            var toSteal = Effect.Template.Credits!.Value;

            if (targetActor.CurrentCredits < toSteal)
            {
                toSteal = targetActor.CurrentCredits;
            }

            activeEvent.AddActorModifier(actorPlayingIt, ModifiableAttributes.Credits, toSteal, Effect);

            activeEvent.AddActorModifier(targetActor, ModifiableAttributes.Credits, -toSteal, Effect);
        }
    }
}