using PQGameEngine.Enums;
using PQGameEngine.Factories;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality.Effects;

public class GrantEquipmentEffect(GameInstance game, GameEngineDependencies geDeps, EffectModel effect)
    : EffectBehaviorBase(game, geDeps, effect)
{
    protected override void ApplyEffect(IEffectApplicable target, EffectTimingType timingFilter,
        ActionEvent activeEvent)
    {
        foreach (var teq in Effect.Template.GrantEquipment)
        {
            decimal roll = -1;

            if (teq.DropChance == null || Game.Random.DidMyRollSucceed(teq.DropChance!.Value, out roll))
            {
                var actorPlayingIt = Game.Actors[Effect.OwnerId];

                var eq = ModelFactories.CreateEquipment(Game, Game.EquipmentTemplates[teq.EquipmentId], actorPlayingIt);

                actorPlayingIt.Equipment.Add(eq.Id);

                var gameEvent = new EquipmentReceiveEvent(Game.Turn, actorPlayingIt.Id, eq.Id, null);

                Game.AddEvent(gameEvent);

                GeDeps.Notifier.EquipmentReceived(actorPlayingIt, Game, [eq]);

                GeDeps.Logger.LogDebug("Granted equipment {Eq} to {Actor} (chance: {Chance}, rolled: {Rolled})", eq,
                    actorPlayingIt, teq.DropChance, roll < 0 ? null : roll);

                Effect.GeneratedEquipment.Add(eq.Id);

                activeEvent.GeneratedEquipment.Add(eq.Id);

                game.ActorStats().EquipmentReceived(actorPlayingIt, eq);
            }
        }
    }
}