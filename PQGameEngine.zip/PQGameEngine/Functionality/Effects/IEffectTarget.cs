namespace PQGameEngine.Functionality.Effects;

public interface IEffectTarget
{
}