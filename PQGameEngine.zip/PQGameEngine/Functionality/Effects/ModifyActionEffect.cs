using PQGameEngine.Enums;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality.Effects;

public class ModifyActionEffect(GameInstance game, GameEngineDependencies geDeps, EffectModel effect)
    : EffectBehaviorBase(game, geDeps, effect)
{
    protected override bool CheckEffectCompatibility { get; } = true;

    protected override void ApplyEffect(IEffectApplicable target, EffectTimingType timingFilter,
        ActionEvent activeEvent)
    {
        if (target is BaseActionModel bam)
        {
            if (Effect.Template.SkillReq.HasValue)
            {
                bam.ChangeSophReq(bam.CurrentSophReq + Effect.Template.SkillReq.Value, activeEvent.Id);
                target.SetEffectApplied(Effect);
            }
        }

        if (target is ActionEvent ae)
        {
            if (Effect.Template.DetectedChanceFailed.HasValue)
            {
                ae.ChangeDetectionChanceFailed(Effect.Template.DetectedChanceFailed.Value, activeEvent.Id, Effect.Id);
                target.SetEffectApplied(Effect);
            }

            if (Effect.Template.DetectionChance.HasValue)
            {
                ae.ChangeDetectionChance(Effect.Template.DetectionChance.Value, activeEvent.Id, Effect.Id);
                target.SetEffectApplied(Effect);
            }

            if (Effect.Template.SuccessChance.HasValue)
            {
                ae.ChangeSuccessChance(Effect.Template.SuccessChance.Value, activeEvent.Id, Effect.Id);
                target.SetEffectApplied(Effect);
            }
        }
    }
}