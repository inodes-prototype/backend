using PQGameEngine.Enums;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality.Effects;

public interface IEffectBehaviour
{
    void Apply<TEffectTarget>(TEffectTarget target, EffectTimingType timingFilter, ActionEvent activeEvent)
        where TEffectTarget : IEffectApplicable, IEffectTarget;

    bool CheckApply<TEffectTarget>(TEffectTarget target, EffectTimingType timingFilter)
        where TEffectTarget : IEffectApplicable, IEffectTarget;

    void InitializeEffect(ActionEvent initializingActionEvent);
}