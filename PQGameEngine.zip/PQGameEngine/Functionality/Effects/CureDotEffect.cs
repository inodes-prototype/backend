using PQGameEngine.Enums;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;
using PQGameEngine.Templates;

namespace PQGameEngine.Functionality.Effects;

public class CureDotEffect(GameInstance game, GameEngineDependencies geDeps, EffectModel effect)
    : EffectBehaviorBase(game, geDeps, effect)
{
    protected override bool CheckEffectCompatibility { get; } = true;

    protected override bool IsEffectApplicable(IEffectApplicable target, EffectTimingType timingFilter)
    {
        if (target is not AssetModel) return false;
        return base.IsEffectApplicable(target, timingFilter);
    }

    protected override void ApplyEffect(IEffectApplicable target, EffectTimingType timingFilter,
        ActionEvent activeEvent)
    {
        var asset = (AssetModel)target;

        ActionTemplate? currentlyPlayedActionTemplate = null;

        if (Effect.ActionTemplateSourceId.HasValue)
        {
            currentlyPlayedActionTemplate = Game.ActionTemplates[Effect.ActionTemplateSourceId.Value];
        }

        foreach (var eventId in asset.PlayedActionEvents)
        {
            var e = Game.Events[eventId];

            if (e is AssetActionEvent aae)
            {
                if (currentlyPlayedActionTemplate == null ||
                    currentlyPlayedActionTemplate.AffectedAttackActions.Contains(aae.MainAction.Template.Id) ||
                    currentlyPlayedActionTemplate.AffectedDefenseActions.Contains(aae.MainAction.Template.Id))
                {
                    foreach (var teid in aae.Effects)
                    {
                        var te = Game.Effects[teid];
                        if (te.Template.Type == EffectTypes.APPLY_DOT && te.IsActive)
                        {
                            te.Deactivate();
                            GeDeps.Logger.LogDebug("Stopped dot effect of {AssetActionEvent} [event: '{EventId}']", aae,
                                aae.Id);
                        }
                    }
                }
            }
        }
    }
}