﻿using PQGameEngine.Enums;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Functionality.Effects;

public static class EffectBehaviorFactory
{
    public static IEffectBehaviour Create(GameInstance game, GameEngineDependencies geDeps, EffectModel effect)
    {
        return effect.Template.Type switch
        {
            EffectTypes.MODIFY_ACTION => new ModifyActionEffect(game, geDeps, effect),
            EffectTypes.MODIFY_ACTOR => new ModifyActorEffect(game, geDeps, effect),
            EffectTypes.DAMAGE_SHIELD => new DamageShieldEffect(game, geDeps, effect),
            EffectTypes.REVEAL_ASSET => new RevealAssetEffect(game, geDeps, effect),
            EffectTypes.INFO => new InfoEffect(game, geDeps, effect),
            EffectTypes.GRANT_EQUIPMENT => new GrantEquipmentEffect(game, geDeps, effect),
            EffectTypes.GRANT_ADMIN_RIGHTS => new GrantAdminRightsEffect(game, geDeps, effect),
            EffectTypes.REVOKE_ADMIN_RIGHTS => new RevokeAdminRightsEffect(game, geDeps, effect),
            EffectTypes.APPLY_DOT => new ApplyDotEffect(game, geDeps, effect),
            EffectTypes.CURE_DOT => new CureDotEffect(game, geDeps, effect),
            EffectTypes.INSIGHT_PREVENTION => new InsightPreventionEffect(game, geDeps, effect),
            EffectTypes.STEAL_CREDITS => new StealCreditsEffect(game, geDeps, effect),
            _ => throw new ArgumentException($"Invalid effect type {effect.Template.Type}")
        };
    }
}