using PQGameEngine.Enums;
using PQGameEngine.Functionality.Shields;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality.Effects;

public class InsightPreventionEffect(GameInstance game, GameEngineDependencies geDeps, EffectModel effect)
    : EffectBehaviorBase(game, geDeps, effect)
{
    protected override void OnActivate(ActionEvent initializingActionEvent)
    {
        if (initializingActionEvent is AssetActionEvent aae)
        {
            var target = Game.Assets[aae.AssetId];
            target.InsightShields.Add(new InsightShield(Effect, initializingActionEvent));
        }
        else
        {
            var target = Game.Actors[initializingActionEvent.Actor];
            target.InsightShields.Add(new InsightShield(Effect, initializingActionEvent));
        }
    }

    protected override void ApplyEffect(IEffectApplicable target, EffectTimingType timingFilter,
        ActionEvent activeEvent)
    {
    }
}