using PQGameEngine.Enums;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality.Effects;

public class InfoEffect(GameInstance game, GameEngineDependencies geDeps, EffectModel effect)
    : EffectBehaviorBase(game, geDeps, effect)
{
    protected override void ApplyEffect(IEffectApplicable target, EffectTimingType timingFilter,
        ActionEvent activeEvent)
    {
    }
}