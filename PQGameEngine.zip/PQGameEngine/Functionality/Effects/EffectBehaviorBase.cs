using PQGameEngine.Enums;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality.Effects;

public abstract class EffectBehaviorBase(GameInstance game, GameEngineDependencies geDeps, EffectModel effect)
    : IEffectBehaviour
{
    protected readonly GameInstance Game = game;
    protected readonly GameEngineDependencies GeDeps = geDeps;
    protected readonly EffectModel Effect = effect;

    public void Apply<TEffectTarget>(TEffectTarget target, EffectTimingType timingFilter, ActionEvent activeEvent)
        where TEffectTarget : IEffectApplicable, IEffectTarget
    {
        if (!SkipAutoChecksInApply)
        {
            if (!CheckApply(target, timingFilter)) return;
        }

        ApplyEffect(target, timingFilter, activeEvent);
    }

    protected virtual bool CheckEffectCompatibility { get; } = false;

    protected virtual bool DisableAffectOnNoDefinition { get; } = false;

    protected virtual bool SkipAutoChecksInApply { get; } = false;

    protected virtual bool IsEffectApplicable(IEffectApplicable target, EffectTimingType timingFilter)
    {
        return true;
    }

    protected virtual void OnActivate(ActionEvent initializingActionEvent)
    {
    }

    protected abstract void ApplyEffect(IEffectApplicable target, EffectTimingType timingFilter,
        ActionEvent activeEvent);

    public void InitializeEffect(ActionEvent initializingActionEvent)
    {
        Effect.SetInitializingActionEventId(initializingActionEvent.Id);

        if (Effect.IsPermanentEffect())
        {
            Effect.Activate();
            OnActivate(initializingActionEvent);
        }
    }

    public bool CheckApply<TEffectTarget>(TEffectTarget target, EffectTimingType timingFilter)
        where TEffectTarget : IEffectApplicable, IEffectTarget
    {
        return CheckApplyInternal(target, timingFilter);
    }

    protected bool CheckApplyInternal(IEffectApplicable target, EffectTimingType timingFilter)
    {
        if (!IsEffectApplicable(target, timingFilter)) return false;

        if (!CheckApplyBaseEffect(target, timingFilter)) return false;

        if (Effect.CustomCheckApply != null && !Effect.CustomCheckApply(Game, Effect, target, timingFilter))
            return false;

        if (Effect.IsPermanentEffect())
        {
            if (!Effect.IsActive)
                return false;
        }

        if (target is MainActionModel mam && CheckEffectCompatibility && !IsEffectCompatibleWith(mam))
            return false;

        if (target is ActionEvent ae && CheckEffectCompatibility && !IsEffectCompatibleWith(ae.MainAction))
            return false;

        return true;
    }

    private bool IsEffectCompatibleWith(BaseActionModel actionToCheck)
    {
        if (Effect.Template.CompatibleActions.Count > 0)
            return Effect.Template.CompatibleActions.Contains(actionToCheck.Template.Id);

        IAffectsActions? affectableSource = null;

        if (Effect.ActionTemplateSourceId.HasValue)
        {
            affectableSource = Game.ActionTemplates[Effect.ActionTemplateSourceId.Value];
        }
        else if (Effect.EquipmentTemplateSourceId.HasValue)
        {
            affectableSource = Game.EquipmentTemplates[Effect.EquipmentTemplateSourceId.Value];
        }

        if (affectableSource == null)
        {
            if (DisableAffectOnNoDefinition) return false;
            return true;
        }

        return affectableSource.Affects(actionToCheck.Template, DisableAffectOnNoDefinition);
    }

    private bool CheckApplyBaseEffect(IEffectApplicable target, EffectTimingType timingFilter)
    {
        if (target.WasEffectAlreadyApplied(Effect))
            return false;

        if (Effect.Template.Timing != timingFilter)
            return false;

        if (Effect.Template.CompatibleActions?.Count > 0)
        {
            Guid? actionId = null;
            if (target is ActionEvent ae)
            {
                actionId = ae.MainAction.Template.Id;
            }
            else if (target is BaseActionModel bam)
            {
                actionId = bam.Template.Id;
            }
            else if (target is AssetModel || target is ActorModel)
            {
            }
            else
            {
                throw new ArgumentException("Invalid/Unsupported IEffectApplicable: " + target?.GetType());
            }

            if (actionId.HasValue)
            {
                if (!Effect.Template.CompatibleActions.Contains(actionId.Value))
                {
                    return false;
                }
            }
        }

        if (!Effect.IsUnscopedEffect())
        {
            switch (Effect.Template.Scope)
            {
                case EffectScopes.Own:
                    if (Effect.OwnerId != target!.GetOwnerId()) return false;
                    break;
                case EffectScopes.NotOwn:
                    if (Effect.OwnerId == target!.GetOwnerId()) return false;
                    break;
                case EffectScopes.Attackers:
                    if (!Game.Actors[target!.GetOwnerId()].IsAttacker) return false;
                    break;
                case EffectScopes.Defenders:
                    if (!Game.Actors[target!.GetOwnerId()].IsDefender) return false;
                    break;
                default:
                    throw new ArgumentException($"Unknown effect scope '{Effect.Template.Scope}'");
            }
        }

        return true;
    }
}