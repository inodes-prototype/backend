using PQGameEngine.Enums;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality.Effects;

public class RevokeAdminRightsEffect(GameInstance game, GameEngineDependencies geDeps, EffectModel effect)
    : EffectBehaviorBase(game, geDeps, effect)
{
    protected override bool IsEffectApplicable(IEffectApplicable target, EffectTimingType timingFilter)
    {
        if (target is not AssetModel at || !at.AdminAccessEnabled) return false;

        return base.IsEffectApplicable(target, timingFilter);
    }

    protected override void ApplyEffect(IEffectApplicable target, EffectTimingType timingFilter,
        ActionEvent activeEvent)
    {
        var asset = (AssetModel)target;
        asset.RevokeAdminAccess(activeEvent.Id);
        var actor = Game.Actors[Effect.OwnerId];
        Game.ActorStats().AdminRevoked(actor, asset);
    }
}