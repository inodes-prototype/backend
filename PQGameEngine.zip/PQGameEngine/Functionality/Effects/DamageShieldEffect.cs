using PQGameEngine.Enums;
using PQGameEngine.Functionality.Shields;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality.Effects;

public class DamageShieldEffect(GameInstance game, GameEngineDependencies geDeps, EffectModel effect)
    : EffectBehaviorBase(game, geDeps, effect)
{
    protected override bool CheckEffectCompatibility { get; } = true;
    protected override bool DisableAffectOnNoDefinition { get; } = true;

    protected override bool IsEffectApplicable(IEffectApplicable target, EffectTimingType timingFilter)
    {
        if (target is not AssetActionEvent aae) return false;

        if (aae.Succeeded == false) return false;

        if (aae.CurrentImpact.All(x => x <= 0)) return false;

        return base.IsEffectApplicable(target, timingFilter);
    }

    protected override void OnActivate(ActionEvent initializingActionEvent)
    {
        var aae = (AssetActionEvent)initializingActionEvent;
        var target = Game.Assets[aae.AssetId];
        target.DamageShields.Add(new DamageShield(Effect, initializingActionEvent));
    }

    protected override void ApplyEffect(IEffectApplicable target, EffectTimingType timingFilter,
        ActionEvent activeEvent)
    {
    }
}