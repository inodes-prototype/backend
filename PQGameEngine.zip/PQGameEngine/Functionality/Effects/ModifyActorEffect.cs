using PQGameEngine.Enums;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality.Effects;

public class ModifyActorEffect(GameInstance game, GameEngineDependencies geDeps, EffectModel effect)
    : EffectBehaviorBase(game, geDeps, effect)
{
    protected override bool SkipAutoChecksInApply { get; } = true;

    protected override void ApplyEffect(IEffectApplicable target, EffectTimingType timingFilter,
        ActionEvent activeEvent)
    {
        foreach (var actor in Game.Actors.Values)
        {
            if (!CheckApplyInternal(actor, timingFilter)) continue;

            if (Effect.Template.Credits.HasValue)
            {
                activeEvent.AddActorModifier(actor, ModifiableAttributes.Credits,
                    Effect.Template.Credits.Value, Effect);
            }

            if (Effect.Template.Insight.HasValue)
            {
                activeEvent.AddActorModifier(actor, ModifiableAttributes.Insight,
                    Effect.Template.Insight.Value, Effect);
            }

            if (Effect.Template.Skill.HasValue)
            {
                activeEvent.AddActorModifier(actor, ModifiableAttributes.Skill,
                    Effect.Template.Skill.Value, Effect);
            }
        }
    }
}