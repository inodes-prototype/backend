﻿using PQGameEngine.Instances;

namespace PQGameEngine.Functionality;

public class AssetVisibilityTracker
{
    private readonly Dictionary<int, List<int>> _visibleAssetsStore;
    private readonly Dictionary<int, bool> _assetOfflineStates;

    public static AssetVisibilityTracker Create(GameInstance gameState) => new AssetVisibilityTracker(gameState);

    private AssetVisibilityTracker(GameInstance game)
    {
        _visibleAssetsStore = new Dictionary<int, List<int>>();
        foreach (var role in game.Actors.Values)
        {
            _visibleAssetsStore[role.Id] = new List<int>(role.VisibleAssets);
        }

        _assetOfflineStates = new Dictionary<int, bool>();
        foreach (var asset in game.Assets.Values)
        {
            _assetOfflineStates[asset.Id] = asset.IsOffline;
        }
    }

    public void NotifyChanges(GameInstance game, Notifier notifier)
    {
        foreach (var role in game.Actors.Values)
        {
            IEnumerable<int> currentVisibleAssets = role.VisibleAssets;
            IEnumerable<int> previouslyVisibleAssets = _visibleAssetsStore[role.Id];
            var addedAssets = currentVisibleAssets.Except(previouslyVisibleAssets).ToList();
            var removedAssets = previouslyVisibleAssets.Except(currentVisibleAssets).ToList();

            if (addedAssets.Count > 0 || removedAssets.Count > 0)
            {
                notifier.AssetVisibilityChanged(role, game, addedAssets, removedAssets);
            }

            foreach (var removedAsset in removedAssets)
            {
                game.Assets[removedAsset].MarkAssetAsChanged();
            }

            var otherAssetsToUpdate = new HashSet<int>();

            foreach (var assetId in addedAssets)
            {
                var asset = game.Assets[assetId];
                if (asset.Template.ParentAssetId.HasValue && role.VisibleAssets.Contains(assetId))
                {
                    otherAssetsToUpdate.Add(assetId);
                }

                if (asset.Template.ChildAssetIds != null!)
                {
                    foreach (var childAssetId in asset.Template.ChildAssetIds)
                    {
                        if (role.VisibleAssets.Contains(childAssetId))
                        {
                            otherAssetsToUpdate.Add(childAssetId);
                        }
                    }
                }
            }

            foreach (var asset in game.Assets.Values)
            {
                if (_assetOfflineStates.TryGetValue(asset.Id, out var wasOffline) && wasOffline != asset.IsOffline)
                {
                    otherAssetsToUpdate.Add(asset.Id);
                }
            }

            foreach (var assetId in otherAssetsToUpdate.Except(addedAssets).Except(removedAssets))
            {
                game.Assets[assetId].MarkAssetAsChanged();
            }
        }
    }
}