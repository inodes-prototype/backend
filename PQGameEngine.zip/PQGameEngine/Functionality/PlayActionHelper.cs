using PQGameEngine.Enums;
using PQGameEngine.Exceptions;
using PQGameEngine.Factories;
using PQGameEngine.Functionality.Effects;
using PQGameEngine.Functionality.Shields;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;
using PQGameEngine.Models.Internal;

namespace PQGameEngine.Functionality;

public static class PlayActionHelper
{
    public static List<PlayedActionEventResult> CreateAndPlayActionEvents(GameInstance game,
        GameEngineDependencies geDeps, MainActionModel action, ActorModel actor, int responseTargetId,
        List<AssetModel> targets)
    {
        var actionEvents = PrepareActionEventsToPlay(game, geDeps, action, actor, targets);

        var unresolvedActionEvents = actionEvents.Where(x => !x.Succeeded.HasValue).ToList();


        PreProcessActionEvents(game, geDeps, unresolvedActionEvents, actor);
        DetermineSuccessOfActionEvents(game, geDeps, unresolvedActionEvents, actor, action);
        PostProcessActionEvents(game, geDeps, unresolvedActionEvents, actor, responseTargetId);

        if (action.TargetType != TargetTypes.Untargeted)
        {
            foreach (var asset in targets)
            {
                asset.MarkAssetAsChanged();
            }
        }

        return actionEvents.Select(x => new PlayedActionEventResult(x.Id, x.Succeeded!.Value)).ToList();
    }

    private static void PostProcessActionEvents(GameInstance game, GameEngineDependencies geDeps,
        List<ActionEvent> unresolvedActionEvents, ActorModel actor, int responseTargetId)
    {
        foreach (var actionEvent in unresolvedActionEvents)
        {
            actionEvent.Detected[actor.Id] = actionEvent.Turn;

            var assetActionEvent = actionEvent as AssetActionEvent;

            AssetModel? asset = null;
            if (assetActionEvent != null)
            {
                asset = game.Assets[assetActionEvent.AssetId];
                asset.PlayedActionEvents.Add(actionEvent.Id);
            }

            EffectHelper.ApplyPermanentEffectsOfPlayedActions(game, geDeps, actionEvent, EffectTimingType.PostSuccess);

            if (assetActionEvent != null)
            {
                DamageShieldHelper.Create(game, geDeps, game.Assets[assetActionEvent.AssetId])
                    .TryApplyTo(assetActionEvent);
            }

            if (actionEvent.WasEffectiveAction())
            {
                ActivateEffectsOfPlayedActionEvent(game, geDeps, actionEvent, asset);

                ActivateEquipmentEffectsOfPlayedActionEvent(game, geDeps, actor, actionEvent, asset);

                if (assetActionEvent != null)
                {
                    ApplyDamageAndHealOfPlayedActionEvent(game, geDeps, actor, responseTargetId, assetActionEvent,
                        asset!);
                }
            }
        }

        HandleActorModifications(game, geDeps, unresolvedActionEvents);
    }

    private static void HandleModificationsPerActor(this List<ActionEvent> unresolvedActionEvents,
        ModifiableAttributes attribute,
        Action<int, IReadOnlyCollection<(ActionEvent actionEvent, ActorModifier actorModifier)>> handler)
    {
        var groupedPerActor = unresolvedActionEvents
            .SelectMany(x => x.ActorModifiers.Select(a => (a.ActorId, a, x)))
            .Where(x => x.a.Type == attribute)
            .GroupBy(x => x.ActorId)
            .ToList();

        foreach (var group in groupedPerActor)
        {
            var modificationsToHandle = group.Select(x => (x.x, x.a)).ToList();
            if (modificationsToHandle.Count > 0)
            {
                handler(group.Key, modificationsToHandle);
            }
        }
    }

    private static void HandleActorModifications(GameInstance game, GameEngineDependencies geDeps,
        List<ActionEvent> unresolvedActionEvents)
    {
        unresolvedActionEvents.HandleModificationsPerActor(ModifiableAttributes.Credits, (actorId, data) =>
        {
            var actor = game.Actors[actorId];
            foreach (var t in data)
            {
                actor.ChangeCredits(t.actorModifier.Value, t.actorModifier.EventId);
            }

            geDeps.Notifier.AttributeChanged(actor, ChangedPlayerAttributeType.Credits, actor.CurrentCredits);
        });

        unresolvedActionEvents.HandleModificationsPerActor(ModifiableAttributes.Skill, (actorId, data) =>
        {
            var actor = game.Actors[actorId];
            foreach (var t in data)
            {
                var effect = game.Effects[t.actorModifier.EffectId];
                if (!actor.WasEffectAlreadyApplied(effect))
                {
                    actor.ChangeSkill((int)t.actorModifier.Value, t.actorModifier.EventId);
                    actor.SetEffectApplied(effect);
                }
            }

            geDeps.Notifier.AttributeChanged(actor, ChangedPlayerAttributeType.Skill, actor.CurrentSoph);
        });

        unresolvedActionEvents.HandleModificationsPerActor(ModifiableAttributes.Insight, (actorId, data) =>
        {
            foreach (var t in data)
            {
                if (t.actionEvent is AssetActionEvent aae)
                {
                    var targetAsset = game.Assets[aae.AssetId];
                    InsightShieldHelper.Create(game, geDeps, targetAsset).TryApplyTo(t.actorModifier);
                }
                else
                {
                    var targetActor = game.Defenders.Values.Single();
                    InsightShieldHelper.Create(game, geDeps, targetActor).TryApplyTo(t.actorModifier);
                }
            }

            var actor = game.Actors[actorId];
            foreach (var t in data.GroupBy(x => x.actionEvent.MainAction.Id))
            {
                var minInsightGainPerPlayedAction = t.MinBy(x => x.actorModifier.Value);
                var effect = game.Effects[minInsightGainPerPlayedAction.actorModifier.EffectId];
                if (!actor.WasEffectAlreadyApplied(effect))
                {
                    var insightGain = (int)minInsightGainPerPlayedAction.actorModifier.Value;
                    actor.ChangeIns(insightGain, minInsightGainPerPlayedAction.actorModifier.EventId);
                    actor.SetEffectApplied(effect);
                    game.ActorStats().InsightGained(actor, insightGain);
                }
            }

            geDeps.Notifier.AttributeChanged(actor, ChangedPlayerAttributeType.Insight, actor.CurrentIns);
        });
    }

    private static void ApplyDamageAndHealOfPlayedActionEvent(GameInstance game, GameEngineDependencies geDeps,
        ActorModel actor, int responseTargetId, AssetActionEvent assetActionEvent, AssetModel asset)
    {
        if (assetActionEvent.IsAttackAction)
        {
            DamageModel damage = assetActionEvent.CurrentImpact.ApplyMask(assetActionEvent.AttackMaskUsed);
            var t = AssetHelper.DealDamageToAsset(game, geDeps, asset, damage, assetActionEvent, actor,
                assetActionEvent.Turn);
            assetActionEvent.SetDamageDealt(t);
            assetActionEvent.FullyCountered = damage.Sum() <= 0;
            if (assetActionEvent.MainAction.AttackStage == asset.CurrentAttackStage)
            {
                asset.SetAttackStage(asset.CurrentAttackStage.Next());
                assetActionEvent.SetAttackStageChangedInfo(asset.AttackStageHistory[^1],
                    asset.CurrentAttackStage);
            }
        }
        else if (assetActionEvent.IsDefenseAction)
        {
            AssetActionEvent? responseTargetActionEvent = null;
            DamageModel? targetActionActiveDamage = null;

            if (responseTargetId != 0)
            {
                responseTargetActionEvent = (AssetActionEvent?)asset.PlayedActionEvents.Select(x => game.Events[x])
                    .FirstOrDefault(x =>
                        x is AssetActionEvent aae && aae.MainAction.Id == responseTargetId);
                if (responseTargetActionEvent != null)
                {
                    targetActionActiveDamage = EventHelper.GetActiveDamage(game, responseTargetActionEvent, null);
                }
            }

            var damage = DamageModel.Zero;

            foreach (var c in "CIA")
            {
                var tDmg = assetActionEvent.CurrentImpact[c];

                if (tDmg > 0)
                {
                    damage[c] = tDmg;
                }
                else if (tDmg < 0 && responseTargetActionEvent != null)
                {
                    var possibleHeal = tDmg;
                    var existingDamage = targetActionActiveDamage?[c] ?? 0;

                    if (existingDamage > 0)
                    {
                        var maxAcceptableHeal = existingDamage * -1;

                        if (possibleHeal < maxAcceptableHeal)
                        {
                            damage[c] = maxAcceptableHeal;
                        }
                        else
                        {
                            damage[c] = possibleHeal;
                        }
                    }
                }
            }


            damage = damage.ApplyMask(assetActionEvent.AttackMaskUsed);

            if (responseTargetActionEvent != null)
            {
                assetActionEvent.Counters = responseTargetActionEvent.Id;
                responseTargetActionEvent.CounteredByEvents.Add(assetActionEvent.Id);
            }

            var t = AssetHelper.DealDamageToAsset(game, geDeps, asset, damage, assetActionEvent, actor,
                assetActionEvent.Turn);
            assetActionEvent.SetDamageDealt(t);

            if (responseTargetActionEvent != null &&
                EventHelper.GetActiveDamage(game, responseTargetActionEvent, null) == DamageModel.Zero)
            {
                responseTargetActionEvent.FullyCountered = true;

                foreach (var effectId in responseTargetActionEvent.Effects)
                {
                    var effect = game.Effects[effectId];
                    if (effect.Template.Type == EffectTypes.APPLY_DOT && effect.IsActive)
                    {
                        effect.Deactivate();
                    }
                }

                if (responseTargetActionEvent.MainAction.AttackStage == AttackStages.InitialAccess &&
                    asset.CurrentAttackStage == AttackStages.Execution)
                {
                    if (!asset.PlayedActionEvents.Select(x => game.Events[x]).Any(x =>
                            x is AssetActionEvent aae && aae.IsAttackAction &&
                            aae.MainAction.AttackStage == AttackStages.InitialAccess &&
                            aae.Succeeded == true && aae.FullyCountered == false))
                    {
                        asset.SetAttackStage(AttackStages.InitialAccess);
                        assetActionEvent.SetAttackStageChangedInfo(asset.AttackStageHistory[^1],
                            asset.CurrentAttackStage);
                    }
                }
            }
        }
    }

    private static void ActivateEquipmentEffectsOfPlayedActionEvent(GameInstance game, GameEngineDependencies geDeps,
        ActorModel actor, ActionEvent actionEvent, AssetModel? asset)
    {
        foreach (int eqId in actionEvent.EquipmentPlayedWith)
        {
            var eq = game.Equipment[eqId];
            if (eq.IsPermanentEquipment())
            {
                EquipmentHelper.ActivatePermanentEquipmentOnAsset(game, geDeps, eq, actor, asset,
                    out var effectActivated);
                if (effectActivated)
                {
                    game.EventsToHandleEachTurn.Add(actionEvent.Id);
                }
            }
            else
            {
                if (asset != null)
                {
                    foreach (var effectId in eq.Effects)
                    {
                        var effect = game.Effects[effectId];
                        EffectBehaviorFactory.Create(game, geDeps, effect).Apply(asset, EffectTimingType.PostSuccess,
                            actionEvent);
                    }
                }
            }
        }
    }

    private static void ActivateEffectsOfPlayedActionEvent(GameInstance game, GameEngineDependencies geDeps,
        ActionEvent actionEvent, AssetModel? asset)
    {
        foreach (var effectId in actionEvent.Effects)
        {
            var effect = game.Effects[effectId];
            if (effect.IsPermanentEffect())
            {
                ApplyPermanentEffectOfPlayedActionEvent(game, geDeps, effect, actionEvent, asset);
            }
            else
            {
                EffectBehaviorFactory.Create(game, geDeps, effect).Apply(asset, EffectTimingType.PostSuccess,
                    actionEvent);
            }
        }
    }

    private static void ApplyPermanentEffectOfPlayedActionEvent(GameInstance game, GameEngineDependencies geDeps,
        EffectModel effect, ActionEvent actionEvent, AssetModel? asset)
    {
        switch (Constants.REPLAYED_ACTION_EFFECT_BEHAVIOUR)
        {
            case ReplayedActionEffectBehaviour.STACK:
                EffectBehaviorFactory.Create(game, geDeps, effect).InitializeEffect(actionEvent);
                game.EventsToHandleEachTurn.Add(actionEvent.Id);
                geDeps.Logger.LogDebug("Permanent effect {effect} now active on {asset}", effect,
                    game.Assets[asset.Id]);
                break;
            case ReplayedActionEffectBehaviour.REFRESH:
                var effectFoundAndActive = false;
                if (actionEvent is AssetActionEvent assetActionEvent)
                {
                    foreach (var aeid in game.Assets[assetActionEvent.AssetId].PlayedActionEvents)
                    {
                        var ae = game.Events[aeid];

                        if (ae is ActionEvent tae)
                        {
                            foreach (var tEffectId in tae.Effects)
                            {
                                var tEffect = game.Effects[tEffectId];
                                if (tEffect.ActionTemplateSourceId != null &&
                                    effect.ActionTemplateSourceId != null
                                    && tEffect.ActionTemplateSourceId == effect.ActionTemplateSourceId
                                    && tEffect.Template.Id == effect.Template.Id)
                                {
                                    if (tEffect.IsActive)
                                    {
                                        tEffect.ResetDuration();
                                        tEffect.ResetShieldStrength();

                                        game.EventsToHandleEachTurn.Add(ae.Id);

                                        if (asset != null)
                                        {
                                            geDeps.Logger.LogDebug(
                                                "Refreshed permanent effect {Effect} on {Asset}",
                                                tEffect, game.Assets[asset.Id]);
                                        }
                                        else
                                        {
                                            geDeps.Logger.LogDebug(
                                                "Refreshed permanent effect {Effect}",
                                                tEffect);
                                        }

                                        effectFoundAndActive = true;
                                        break;
                                    }
                                }
                            }
                        }

                        if (effectFoundAndActive)
                        {
                            break;
                        }
                    }
                }

                if (!effectFoundAndActive)
                {
                    EffectBehaviorFactory.Create(game, geDeps, effect).InitializeEffect(actionEvent);
                    game.EventsToHandleEachTurn.Add(actionEvent.Id);
                    if (asset != null)
                    {
                        geDeps.Logger.LogDebug("Permanent effect {Effect} now active on {Asset}",
                            effect,
                            game.Assets[asset.Id]);
                    }
                    else
                    {
                        geDeps.Logger.LogDebug("Permanent effect {Effect} now active", effect);
                    }
                }

                break;
            default:
                throw new ArgumentException(
                    $"ReplayedActionEffectBehaviour '{Constants.REPLAYED_ACTION_EFFECT_BEHAVIOUR}' unknown");
        }
    }

    private static void DetermineSuccessOfActionEvents(GameInstance game, GameEngineDependencies geDeps,
        List<ActionEvent> unresolvedActionEvents, ActorModel actor, MainActionModel action)
    {
        if (game.Options.ActionSuccessMode == GameOptionActionSuccessMode.ALWAYS_SUCCESS ||
            game.Phase == GamePhase.DefenderPreSetup)
        {
            foreach (var actionEvent in unresolvedActionEvents)
            {
                actionEvent.Succeeded = true;
            }
        }
        else if (game.Options.ActionSuccessMode == GameOptionActionSuccessMode.DEFAULT)
        {
            if (game.Options.MultiTargetSuccess == GameOptionMultiTargetSuccessMode.OneRollPerTarget
                || (game.Options.MultiTargetSuccess ==
                    GameOptionMultiTargetSuccessMode.Attacker_OneRollOnAverageSuccessChanceOfAllTargets &&
                    actor.IsDefender)
                || (game.Options.MultiTargetSuccess ==
                    GameOptionMultiTargetSuccessMode.Defender_OneRollOnAverageSuccessChanceOfAllTargets &&
                    actor.IsAttacker))
            {
                foreach (var actionEvent in unresolvedActionEvents)
                {
                    actionEvent.Succeeded =
                        game.Random.DidMyRollSucceed(actionEvent.RealSuccessChance!.Value, out var roll);
                    actionEvent.RollResult = roll;

                    geDeps.Logger.LogDebug("Play Action {Action} chance: {Roll} <= {Chance}? succeeded={Success}",
                        action,
                        roll,
                        actionEvent.RealSuccessChance, actionEvent.Succeeded);
                }
            }
            else if (game.Options.MultiTargetSuccess ==
                     GameOptionMultiTargetSuccessMode.All_OneRollOnAverageSuccessChanceOfAllTargets
                     || (game.Options.MultiTargetSuccess ==
                         GameOptionMultiTargetSuccessMode.Attacker_OneRollOnAverageSuccessChanceOfAllTargets &&
                         actor.IsAttacker)
                     || (game.Options.MultiTargetSuccess ==
                         GameOptionMultiTargetSuccessMode.Defender_OneRollOnAverageSuccessChanceOfAllTargets &&
                         actor.IsDefender))
            {
                var avgSuccessChance =
                    unresolvedActionEvents.Sum(x => x.RealSuccessChance) / unresolvedActionEvents.Count;

                var success = game.Random.DidMyRollSucceed(avgSuccessChance!.Value, out var roll);

                foreach (var actionEvent in unresolvedActionEvents)
                {
                    actionEvent.Succeeded = success;
                    actionEvent.RollResult = roll;
                }

                geDeps.Logger.LogDebug("Play Action {Action} chance: {Roll} <= {Chance}? succeeded={Success}",
                    action, roll, avgSuccessChance, success);
            }
            else
            {
                throw new PenQuestException(Errors.ValueErrorFatal,
                    $"Unknown game option for multi target success: {game.Options.MultiTargetSuccess}");
            }
        }
        else
        {
            throw new PenQuestException(Errors.ValueErrorFatal,
                $"Unknown game option for action success mode: {game.Options.ActionSuccessMode}");
        }

        foreach (var actionEvent in unresolvedActionEvents)
        {
            if (actionEvent is AssetActionEvent aae)
            {
                var asset = game.Assets[aae.AssetId];
                if (actionEvent.MainAction.Template.RequireAdmin && !asset.AdminAccessEnabled)
                {
                    actionEvent.Succeeded = false;
                }
            }
        }
    }

    private static void PreProcessActionEvents(GameInstance game, GameEngineDependencies geDeps,
        List<ActionEvent> unresolvedActionEvents, ActorModel actor)
    {
        foreach (var actionEvent in unresolvedActionEvents)
        {
            AssetModel? targetAsset = null;

            if (actionEvent is AssetActionEvent assetActionEvent)
            {
                targetAsset = game.Assets[assetActionEvent.AssetId];
            }

            ApplySupportActions(game, geDeps, actor, actionEvent);

            ApplySingleUserEquipment(game, geDeps, actor, actionEvent, targetAsset);

            EventHelper.ApplyPermanentEquipment(game, geDeps, actionEvent, actor);

            EffectHelper.ApplyPermanentEffectsOfPlayedActions(game, geDeps, actionEvent, EffectTimingType.PreSuccess);

            ApplyAssetSpecificEffects(game, geDeps, actionEvent, EffectTimingType.PreSuccess);

            var actualSuccessChance = actionEvent.GetSuccessChance(
                ChanceHelper.GetSuccessModifierFromSkill(actor, actionEvent),
                ChanceHelper.GetSuccessModifierFromInsight(actor));

            actionEvent.SetRealSuccessChance(actualSuccessChance);
        }
    }

    private static void ApplySingleUserEquipment(GameInstance game, GameEngineDependencies geDeps, ActorModel actor,
        ActionEvent actionEvent, AssetModel? targetAsset)
    {
        foreach (var eqId in actionEvent.EquipmentPlayedWith)
        {
            EquipmentModel eq = game.Equipment[eqId];
            if (eq.IsSingleUseEquipment())
            {
                ApplySingleUseEquipment(game, geDeps, eq, actor, actionEvent, targetAsset);
            }

            if (eq.IsLocalEquipment())
            {
                eq.SetPlayedWith(actionEvent.MainAction.Id);
            }
        }
    }

    private static void ApplySupportActions(GameInstance game, GameEngineDependencies geDeps, ActorModel actor,
        ActionEvent actionEvent)
    {
        foreach (var supportActionId in actionEvent.SupportedBy)
        {
            var supportAction = (SupportActionModel)game.Actions[supportActionId];
            ApplySupportAction(game, geDeps, supportAction, actionEvent);
        }
    }

    private static IReadOnlyCollection<ActionEvent> PrepareActionEventsToPlay(GameInstance game,
        GameEngineDependencies geDeps, MainActionModel action,
        ActorModel actor, List<AssetModel> targets)
    {
        if (action.TargetType == TargetTypes.Untargeted)
        {
                        var ae = new ActionEvent(game.Turn, action, action.Effects);
            game.AddEvent(ae);
            geDeps.Logger.LogDebug("created action event {ActionEvent} for untargeted action", ae);
            action.ActionEvents[Constants.NO_ASSET_ID] = ae.Id;
            return [ae];
        }

        var actionEvents = new List<ActionEvent>();
                foreach (var asset in targets)
        {
            var ae = new AssetActionEvent(asset.Id, game.Turn, action,
                ModelFactories.CreateEffects(game, action.Effects.Select(x => game.Effects[x].Template.Id).ToList(),
                    actor,
                    action.Template.Id, null), asset.CurrentExposedState);
            actionEvents.Add(ae);
            game.AddEvent(ae);
            geDeps.Logger.LogDebug("created action event {ActionEvent} for asset {Asset}", ae, asset);
            action.ActionEvents[asset.Id] = ae.Id;

                        if (ae.MainAction.IsAttackAction)
            {
                                if (!ActionValidationHelper.IsAttackVectorAtLeastPartiallyAvailable(ae.AttackMaskUsed, asset))
                {
                    ae.Succeeded = false;
                }
            }
        }

        return actionEvents;
    }

                private static void ApplySupportAction(GameInstance game, GameEngineDependencies geDeps,
        SupportActionModel supportAction, ActionEvent targetActionEvent)
    {
                foreach (var effectId in supportAction.Effects)
        {
            var effect = game.Effects[effectId];
            EffectBehaviorFactory.Create(game, geDeps, effect).Apply(targetActionEvent, EffectTimingType.PreSuccess,
                targetActionEvent);
        }

                foreach (var effectId in supportAction.TransferEffects)
        {
                        if (targetActionEvent is AssetActionEvent)
            {
                var t = game.Effects[effectId];
                targetActionEvent.AddEffect(ModelFactories.CreateEffect(game, t.Template.Id, t.OwnerId,
                    supportAction.Template.Id, null));
            }
            else
            {
                targetActionEvent.AddEffect(effectId);
            }
        }

                if (targetActionEvent is AssetActionEvent assetActionEvent)
        {
            assetActionEvent.AddImpact(supportAction.CurrentImpact);
        }

                supportAction.Used = true;
    }

                private static void ApplySingleUseEquipment(GameInstance game, GameEngineDependencies geDeps,
        EquipmentModel equipment, ActorModel actor, ActionEvent targetActionEvent, AssetModel? asset)
    {
        if (!equipment.IsSingleUseEquipment()) return;

        if (!EquipmentHelper.IsEquipmentApplicable(equipment, actor, targetActionEvent, asset)) return;

        if (equipment.UsedOn != null)
        {
            throw new PenQuestException(Errors.EquipmentAlreadyUsed,
                $"Equipment {equipment} was already applied to {equipment.UsedOn}");
        }

        EventHelper.ApplyEquipment(game, geDeps, equipment, targetActionEvent, actor);
        equipment.UsedOn = targetActionEvent.Id;
        TryApplyFixToRemoveExploits(game, equipment, actor, asset);
    }

                private static void TryApplyFixToRemoveExploits(GameInstance game, EquipmentModel equipment, ActorModel actor,
        AssetModel? asset)
    {
        if (equipment.EquipmentType != EquipmentSubTypes.FIX || actor == null! || asset == null!) return;

        foreach (var eqId in asset.InfluencedByEquipment)
        {
            var eq = game.Equipment[eqId];
            if (eq.IsPermanentEquipment() && eq.IsAttackEquipment && eq.IsLocalEquipment() &&
                eq.PossibleAssetCategories.Contains(asset.Template.Category))
            {
                var mainAction = (MainActionModel)game.Actions[eq.PlayedWithAction!.Value];
                if (mainAction.ActionEvents.TryGetValue(asset.Id, out var eventId))
                {
                    var actionEvent = (ActionEvent)game.Events[eventId];
                    if (actionEvent.Detected.ContainsKey(actor.Id))
                    {
                        EquipmentHelper.DeactivatePermanentEquipment(game, eq);
                        game.ActorStats().FixApplied(actor);
                    }
                }
            }
        }
    }

    private static void ApplyAssetSpecificEffects(GameInstance game, GameEngineDependencies geDeps,
        ActionEvent actionEvent, EffectTimingType timing)
    {
        if (actionEvent is AssetActionEvent aae)
        {
            var asset = game.Assets[aae.AssetId];
            foreach (var effectId in asset.GetActiveAssetSpecificEffects())
            {
                var effect = game.Effects[effectId];
                if (effect.IsPermanentEffect() && effect.IsActive)
                {
                    EffectBehaviorFactory.Create(game, geDeps, effect).Apply(actionEvent, timing, actionEvent);
                }
            }
        }
    }
}