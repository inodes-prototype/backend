﻿namespace PQGameEngine.Functionality;

public interface IEquipmentApplicable
{
    List<int> InfluencedByEquipment { get; }
}