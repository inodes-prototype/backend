﻿using PQGameEngine.Exceptions;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Functionality;

public static class GoalHelper
{
    public static bool AreAttackerGoalsAchieved(GameInstance game, ActorModel attacker)
    {
        return game.Scenario.Goals.All(goal => IsGoalAchieved(game, goal));
    }

    public static bool IsGoalAchieved(GameInstance game, BaseGoalModel goal)
    {
        if (goal is AssetGoalModel assetGoal)
        {
            return IsAssetGoalAchieved(game, assetGoal);
        }
        else if (goal is ActorGoalModel actorGoal)
        {
            return IsActorGoalAchieved(game, actorGoal);
        }
        else if (goal is DefenderNotExceededActorGoal defenderGoal)
        {
            return IsDefenderNotExceededActorGoalAchieved(game, defenderGoal);
        }
        else
        {
            throw new PenQuestException(Errors.TypeErrorFatal, $"Type {goal.GetType()} is not a valid goal type");
        }
    }

    private static bool IsAssetGoalAchieved(GameInstance game, AssetGoalModel goal)
    {
        var asset = game.Assets[goal.AssetId];

        var damageAchieved = asset.CurrentDamage >= goal.Damage;

        var exposedAchieved = !((goal.Exposed.C && !asset.CurrentExposedState.C)
                                || (goal.Exposed.I && !asset.CurrentExposedState.I)
                                || (goal.Exposed.A && !asset.CurrentExposedState.A));

        var attackStageAchieved = asset.CurrentAttackStage >= goal.AttackStage;

        return damageAchieved && exposedAchieved && attackStageAchieved;
    }

    private static bool IsActorGoalAchieved(GameInstance game, ActorGoalModel goal)
    {
        if (goal.SelfActorId == 0)
        {
            return false;
        }

        var selfActor = game.Actors[goal.SelfActorId];

        var insAchieved = selfActor.CurrentIns >= goal.Insight;
        var creditsAchieved = selfActor.CurrentCredits >= goal.Credits;

        if (!goal.Insight.HasValue && goal.Credits.HasValue) return creditsAchieved;
        if (goal.Insight.HasValue && !goal.Credits.HasValue) return insAchieved;
        if (goal.Insight.HasValue && goal.Credits.HasValue) return insAchieved && creditsAchieved;

        return false;
    }

    private static bool IsDefenderNotExceededActorGoalAchieved(GameInstance game, DefenderNotExceededActorGoal goal)
    {
        var defender = game.Defenders[goal.DefenderId];

        var insAchieved = defender.CurrentIns >= goal.Insight;
        var creditsAchieved = defender.CurrentCredits >= goal.Credits;

        if (!goal.Insight.HasValue && goal.Credits.HasValue) return creditsAchieved;
        if (goal.Insight.HasValue && !goal.Credits.HasValue) return insAchieved;
        if (goal.Insight.HasValue && goal.Credits.HasValue) return insAchieved && creditsAchieved;

        return false;
    }
}