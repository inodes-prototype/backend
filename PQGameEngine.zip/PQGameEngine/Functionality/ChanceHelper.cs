﻿using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality;

public static class ChanceHelper
{
    public static decimal GetSuccessModifierFromInsight(ActorModel actor)
    {
        return Constants.GAME_ENGINE_INS_SUCCESS_IMPROVEMENT * actor.CurrentIns;
    }

    public static decimal GetSuccessModifierFromSkill(ActorModel actor, MainActionModel action) =>
        GetSuccessModifierFromSkill(actor, action.CurrentSophReq);

    public static decimal GetSuccessModifierFromSkill(ActorModel actor, ActionEvent actionEvent) =>
        GetSuccessModifierFromSkill(actor, actionEvent.SophReq);

    private static decimal GetSuccessModifierFromSkill(ActorModel actor, int requiredSkill)
    {
        return Constants.GAME_ENGINE_SOPH_SUCCESS_IMPROVEMENT * (actor.CurrentSoph - requiredSkill);
    }
}