using PQGameEngine.Enums;
using PQGameEngine.Exceptions;
using PQGameEngine.Factories;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;
using PQGameEngine.Models.Internal;
using PQGameEngine.Templates;

namespace PQGameEngine.Functionality;

public static class GameSetupHelper
{
    public static void SetupGame(GameInstance game, GameEngineDependencies geDeps, ScenarioConfig scenarioConfig)
    {
        switch (scenarioConfig.GoalMode)
        {
            case ScenarioConfig.ScenarioGoalMode.Default:
                game.Scenario.SetDefaultGoalSet();
                break;
            case ScenarioConfig.ScenarioGoalMode.Random:
                game.Scenario.SetRandomGoalSet(game.Random);
                break;
            case ScenarioConfig.ScenarioGoalMode.ManuallySelected:
                game.Scenario.SetActiveGoalSet(scenarioConfig.SelectedGoalSet!.Value);
                break;
            default:
                throw new PenQuestFatalException(
                    $"GameOptionGameObjectivesMode {scenarioConfig.GoalMode} not supported");
        }

        CustomScenSetup(game);

        foreach (var asset in game.Assets.Values)
        {
            InitAsset(game, asset);
        }

        foreach (var actor in game.Actors.Values)
        {
            InitActor(game, actor, geDeps);
        }

        InitActionDecks(game);
        foreach (var actor in game.Actors.Values)
        {
            if (actor.IsDefender && game.Scenario.IsDefenderPreSetupModeEnabled(game)) continue;
            DealInitialActions(game, actor);
        }

        foreach (var actor in game.Actors.Values)
        {
            game.Shops[actor.Id] = EquipmentHelper.CreateShopSelection(game, actor);
        }
    }

    private static void InitActionDecks(GameInstance game)
    {
        GetMaxSophChanges(game, game.ActionTemplatesAttacker, game.EquipmentTemplatesAttacker, out var maxSophIncAtk,
            out var maxSophDecAtk);
        GetMaxSophChanges(game, game.ActionTemplatesDefender, game.EquipmentTemplatesDefender, out var maxSophIncDef,
            out var maxSophDecDef);
        var osCatCombinations = GetAppearingAttributes(game);

        var mainAttackActionTemplates = new Dictionary<Guid, ActionTemplate>();
        var mainDefenseActionTemplates = new Dictionary<Guid, ActionTemplate>();
        var supportAttackActionTemplates = new Dictionary<Guid, ActionTemplate>();
        var supportDefenseActionTemplates = new Dictionary<Guid, ActionTemplate>();

        foreach (var template in game.ActionTemplatesAttacker)
        {
            if (template.IsMainAction)
            {
                mainAttackActionTemplates[template.Id] = template;
            }
            else if (template.IsSupportAction)
            {
                supportAttackActionTemplates[template.Id] = template;
            }
        }

        foreach (var template in game.ActionTemplatesDefender)
        {
            if (template.IsMainAction)
            {
                if (game.Options.ManualDefTypeMode == GameOptionManualDefType.PREVENTION ||
                    game.Options.ManualDefTypeMode == GameOptionManualDefType.DETECTION ||
                    game.Options.ManualDefTypeMode == GameOptionManualDefType.RESPONSE)
                {
                    DefenseActionType defType = Mapper.Map(game.Options.ManualDefTypeMode);
                    template.OverrideDefType(defType);
                    mainDefenseActionTemplates.Add(template.Id, template);
                }
                else if (game.Options.ManualDefTypeMode == GameOptionManualDefType.PREVENTION_ONLY ||
                         game.Options.ManualDefTypeMode == GameOptionManualDefType.DETECTION_ONLY ||
                         game.Options.ManualDefTypeMode == GameOptionManualDefType.RESPONSE_ONLY)
                {
                    if ((game.Options.ManualDefTypeMode == GameOptionManualDefType.PREVENTION_ONLY &&
                         template.DefenseType == DefenseActionType.Prevention)
                        || (game.Options.ManualDefTypeMode == GameOptionManualDefType.DETECTION_ONLY &&
                            template.DefenseType == DefenseActionType.Detection)
                        || (game.Options.ManualDefTypeMode == GameOptionManualDefType.RESPONSE_ONLY &&
                            template.DefenseType == DefenseActionType.Response))
                    {
                        mainDefenseActionTemplates.Add(template.Id, template);
                    }
                }
                else
                {
                    mainDefenseActionTemplates.Add(template.Id, template);
                }
            }
            else if (template.IsSupportAction)
            {
                supportDefenseActionTemplates.Add(template.Id, template);
            }
        }

        foreach (var actor in game.Actors.Values)
        {
            List<Guid> actionDeckMain = [];
            List<Guid> actionDeckSupport = [];
            if (actor.IsAttacker)
            {
                foreach (var t in mainAttackActionTemplates)
                {
                    if (ActionHelper.ActorFulfillsActionRequirements(t.Value, actor, osCatCombinations, maxSophIncAtk,
                            maxSophDecAtk))
                    {
                        actionDeckMain.Add(t.Key);
                    }
                }

                if (game.Options.SupportActionsMode != GameOptionSupportActionsMode.DISABLED)
                {
                    foreach (var t in supportAttackActionTemplates)
                    {
                        if (ActionHelper.ActorFulfillsActionRequirements(t.Value, actor, osCatCombinations,
                                maxSophIncAtk,
                                maxSophDecAtk))
                        {
                            actionDeckSupport.Add(t.Key);
                        }
                    }
                }
            }
            else if (actor.IsDefender)
            {
                foreach (var t in mainDefenseActionTemplates)
                {
                    if (ActionHelper.ActorFulfillsActionRequirements(t.Value, actor, osCatCombinations, maxSophIncDef,
                            maxSophDecDef))
                    {
                        actionDeckMain.Add(t.Key);
                    }
                }

                if (game.Options.SupportActionsMode != GameOptionSupportActionsMode.DISABLED)
                {
                    foreach (var t in supportDefenseActionTemplates)
                    {
                        if (ActionHelper.ActorFulfillsActionRequirements(t.Value, actor, osCatCombinations,
                                maxSophIncDef,
                                maxSophDecDef))
                        {
                            actionDeckSupport.Add(t.Key);
                        }
                    }
                }
            }
            else
            {
                throw new PenQuestException(Errors.InvalidRoleTypeError, $"Invalid role type for role {actor.Id}");
            }

            if (actionDeckMain.Count == 0)
            {
                throw new PenQuestException(Errors.NoPlayableActionError,
                    "The deck contains no action the player can ever play");
            }

            game.ActionDecksMain.Add(actor.Id, actionDeckMain);
            game.ActionDecksSupport.Add(actor.Id, actionDeckSupport);
        }
    }

    private static HashSet<(Oses, AssetCategories)> GetAppearingAttributes(GameInstance game)
    {
        var appearingAttributes = new HashSet<(Oses, AssetCategories)>();

        foreach (var asset in game.Assets.Values)
        {
            appearingAttributes.Add((asset.Template.Os, asset.Template.Category));
        }

        return appearingAttributes;
    }

    public static IReadOnlyCollection<BaseActionModel> DealInitialActions(GameInstance game, ActorModel actor)
    {
        if (game.Options.InitActionsMode == GameOptionInitActionsMode.PICK) return [];

        var relevantMainTids = game.ActionDecksMain[actor.Id];
        var relevantSupportTids = game.ActionDecksSupport[actor.Id];

        var playableTemplates = ActionHelper.GetPossibleActionTemplates(game, actor, null, true);
        var playableTids = playableTemplates.Select(t => t.Id).ToList();

        if (playableTemplates.Count == 0)
        {
            throw new PenQuestException(Errors.NoPlayableActionError,
                "Currently the deck contains no playable action");
        }

        var currentTemplates = relevantMainTids;
        var limit = ActorHelper.GetActionLimit(game, actor) - 1;

        if (game.Options.InitActionsMode == GameOptionInitActionsMode.PLAYABLE)
        {
            currentTemplates = playableTids;
            limit += 1;
        }

        var choosenActionTemplateIds = new List<Guid>();

        for (var i = 0; i < limit; i++)
        {
            var tid = currentTemplates[game.Random.Next(currentTemplates.Count)];
            choosenActionTemplateIds.Add(tid);
        }

        if (game.Options.InitActionsMode == GameOptionInitActionsMode.RANDOM)
        {
            var hasPlayableAction = actor.Actions.Any(actionId =>
                ActionHelper.IsTemplateCurrentlyPlayable(game, actor, game.Actions[actionId].Template));

            var tids = hasPlayableAction ? relevantMainTids : playableTids;

            var tid = tids[game.Random.Next(tids.Count)];
            choosenActionTemplateIds.Add(tid);
        }

        if (game.Options.SupportActionsMode == GameOptionSupportActionsMode.ALL_AT_START)
        {
            foreach (var tid in relevantSupportTids)
            {
                choosenActionTemplateIds.Add(tid);
            }
        }

        var receivedActions = new List<BaseActionModel>();

        foreach (var tempalteId in choosenActionTemplateIds)
        {
            var actionTemplate = game.ActionTemplates[tempalteId];
            var action = ModelFactories.CreateAction(game, actionTemplate, actor);
            receivedActions.Add(action);
            actor.Actions.Add(action.Id);
            game.AddEvent(new DrawActionEvent(game.Turn, actor.Id, action.Id, null));
        }

        return receivedActions;
    }

    private static void GetMaxSophChanges(GameInstance game, IEnumerable<ActionTemplate> actionDeck,
        IEnumerable<EquipmentTemplate> equipments, out decimal maxSophInc, out decimal maxSophDec)
    {
        maxSophDec = 0;
        maxSophInc = 0;

        foreach (var action in actionDeck)
        {
            foreach (var effectId in action.Effects)
            {
                var effect = game.Scenario.EffectTemplates[effectId];
                if (effect.Type == EffectTypes.MODIFY_ACTION && effect.IsPermanentEffect())
                {
                    if (effect.SkillReq.HasValue && effect.SkillReq < maxSophDec)
                    {
                        maxSophDec = effect.SkillReq.Value;
                    }
                    else if (effect.Skill.HasValue && effect.Skill > maxSophInc)
                    {
                        maxSophInc = effect.Skill.Value;
                    }
                }
            }
        }

        foreach (var equipment in equipments)
        {
            foreach (var effectId in equipment.Effects)
            {
                var effect = game.Scenario.EffectTemplates[effectId];

                if (effect.Type == EffectTypes.MODIFY_ACTION && effect.IsPermanentEffect())
                {
                    if (effect.SkillReq.HasValue && effect.SkillReq < maxSophDec)
                    {
                        maxSophDec = effect.SkillReq.Value;
                    }
                    else if (effect.Skill.HasValue && effect.Skill > maxSophInc)
                    {
                        maxSophInc = effect.Skill.Value;
                    }
                }
            }
        }
    }

    private static void CustomScenSetup(GameInstance game)
    {
        foreach (var asset in game.Assets.Values)
        {
            var adminAssetEffect1Id = game.Scenario.AddCustomEffect((int effectId) =>
            {
                return new EffectTemplate(effectId, EffectTypes.MODIFY_ACTION, "Privilege Escalation",
                    "Increases attack success chance by 20%.", EffectScopes.Attackers, null, null, 0.2M, null, null,
                    null, null, null, null, null, null);
            });
            var adminAssetEffect2Id = game.Scenario.AddCustomEffect((int effectId) =>
            {
                return new EffectTemplate(effectId, EffectTypes.MODIFY_ACTION, "Privilege Escalation",
                    "Decreases defense success chance by 10%.", EffectScopes.Defenders, null, null, -0.1M, null, null,
                    null, null, null, null, null, null);
            });

            var gameEffectId1 = ModelFactories.CreateEffect(game, adminAssetEffect1Id, Constants.DUNGEON_MASTER_ID,
                null, null,
                (GameInstance tgame, EffectModel effect, IEffectApplicable target, EffectTimingType timingFilter) =>
                {
                    if (target is BaseActionModel bam)
                    {
                        if (bam.Effects.Any(x => tgame.Effects[x].Template.Type == EffectTypes.GRANT_ADMIN_RIGHTS))
                            return false;
                        if (bam.Template.RequireAdmin) return false;
                    }
                    else if (target is ActionEvent ae)
                    {
                        var supportedBy = ae.SupportedBy.Select(x => tgame.Actions[x]).ToList();
                        if (ae.Effects.Any(x => tgame.Effects[x].Template.Type == EffectTypes.GRANT_ADMIN_RIGHTS))
                            return false;
                        if (supportedBy.Any(x =>
                                x.Effects.Any(x => tgame.Effects[x].Template.Type == EffectTypes.GRANT_ADMIN_RIGHTS)))
                            return false;
                        if (ae.MainAction.Template.RequireAdmin) return false;
                        if (supportedBy.Any(x => x.Template.RequireAdmin)) return false;
                    }
                    else
                    {
                        return false;
                    }

                    return true;
                });
            var gameEffectId2 = ModelFactories.CreateEffect(game, adminAssetEffect2Id, Constants.DUNGEON_MASTER_ID,
                null, null,
                (GameInstance tgame, EffectModel effect, IEffectApplicable target, EffectTimingType timingFilter) =>
                {
                    if (target is BaseActionModel bam)
                    {
                        if (bam.Effects.Any(x => tgame.Effects[x].Template.Type == EffectTypes.REVOKE_ADMIN_RIGHTS))
                            return false;
                    }
                    else if (target is ActionEvent ae)
                    {
                        if (ae.Effects.Any(x => tgame.Effects[x].Template.Type == EffectTypes.REVOKE_ADMIN_RIGHTS))
                            return false;
                    }
                    else
                    {
                        return false;
                    }

                    return true;
                });

            game.Effects[gameEffectId1].Activate();
            game.Effects[gameEffectId2].Activate();

            asset.AddAdminIsActiveEffect(gameEffectId1);
            asset.AddAdminIsActiveEffect(gameEffectId2);
        }
    }

    private static void InitAsset(GameInstance game, AssetModel asset)
    {
        var initialAssetStage = AttackStages.Reconnaissance;

        if (game.Options.InitialAssetStage != GameOptionInitialAssetStage.DEFAULT)
        {
            initialAssetStage = Mapper.Map(game.Options.InitialAssetStage);
        }

        asset.SetInitialAttackStage(initialAssetStage);
    }

    private static void InitActor(GameInstance game, ActorModel actor, GameEngineDependencies geDeps)
    {
        game.ActorStatCounters.Add(actor.Id, new PlayerStatCounter());
        game.TurnTrackers.Add(actor.Id, new TurnTracker(actor, geDeps));
        var initialInitiative = GetInitialInitiative(game, actor);

        var initialInsight = actor.Type switch
        {
            ActorTypes.Attacker => game.Scenario.ActiveGoalSet.InitialInsightAttacker ?? 0,
            ActorTypes.Defender => game.Scenario.ActiveGoalSet.InitialInsightDefender ?? 0,
            _ => 0
        };

        var initialCredits = Constants.GAME_ENGINE_START_CREDITS_PER_WEALTH * actor.CurrentWealth;

        actor.SetInitialValues(initialInitiative, initialInsight, initialCredits);

        foreach (var aid in game.Scenario.InitialVisibleAssets)
        {
            actor.VisibleAssets.Add(aid);
            actor.KnownAssets.Add(aid);
            game.Assets[aid].RevealedTo.Add(actor.Id);
        }

        if (actor.IsDefender)
        {
            foreach (var aid in GetAssetIds(game, actor))
            {
                actor.VisibleAssets.Add(aid);
                actor.KnownAssets.Add(aid);
                game.Assets[aid].RevealedTo.Add(actor.Id);
            }
        }
    }

    private static int GetInitialInitiative(GameInstance game, ActorModel actor)
    {
        var initialInitiative = actor.CurrentDet + actor.CurrentSoph + (game.Assets.Count / 3);

        if (game.Scenario.ActiveGoalSet.AvailableInitiative.HasValue)
        {
            initialInitiative = game.Scenario.ActiveGoalSet.AvailableInitiative.Value;
        }

        return initialInitiative;
    }

    private static IEnumerable<int> GetAssetIds(GameInstance game, ActorModel actor)
    {
        if (!actor.IsDefender) throw new PenQuestFatalException("Invalid actor supplied");

        return game.Scenario.ActorToAssets[actor.Id];
    }
}