using PQGameEngine.Enums;
using PQGameEngine.Factories;
using PQGameEngine.Instances;
using PQGameEngine.Models.Datastore;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Functionality;

public static class GamePhaseHelper
{
    public static void BeginGame(GameInstance game, GameEngineDependencies geDeps)
    {
        if (game.Scenario.IsDefenderPreSetupModeEnabled(game))
        {
            MoveToGamePhase(game, geDeps, GamePhase.DefenderPreSetup);
        }
        else if (game.Options.InitActionsMode == GameOptionInitActionsMode.PICK)
        {
            MoveToGamePhase(game, geDeps, GamePhase.InitDraw);
        }
        else
        {
            BeginNextTurn(game, geDeps);
        }
    }

    public static void TryMoveGamePhase(GameInstance game, GameEngineDependencies geDeps)
    {
        switch (game.Phase)
        {
            case GamePhase.DefenderPreSetup:
                if (game.HaveAllDefendersCompletedTheirActions())
                {
                    game.InitTurnTrackerDefender();
                    SkipActors(game, geDeps, game.Defenders.Values);
                    if (game.Options.InitActionsMode == GameOptionInitActionsMode.PICK)
                    {
                        MoveToGamePhase(game, geDeps, GamePhase.InitDraw);
                    }
                    else
                    {
                        BeginNextTurn(game, geDeps);
                        foreach (var actor in game.Defenders.Values)
                        {
                            var allocatedActions = GameSetupHelper.DealInitialActions(game, actor);
                            geDeps.Notifier.ActionsReceived(actor, allocatedActions, game, -1);
                        }
                    }
                }

                break;
            case GamePhase.Attack:
                if (game.HaveAllAttackersCompletedTheirActions() &&
                    (game.Turn == 1 || game.HaveAllAttackersDrawnNewActions()))
                {
                    foreach (var attacker in game.Attackers.Values)
                    {
                        if (attacker.FirstActionDetected)
                        {
                            attacker.ChangeIni(-1, game.Turn);
                            geDeps.Notifier.AttributeChanged(attacker, ChangedPlayerAttributeType.Initiative,
                                attacker.CurrentIni);
                        }

                        game.GameboardLog.AddEntry(attacker, GameboardLogMessageType.InfoInsightTotal,
                            c => c.SetInitiative(attacker.CurrentIni));

                        SendShoppingAssortment(game, geDeps, attacker);
                    }

                    game.InitTurnTrackerAttacker();
                    EffectHelper.MovePermanentEffects(game, geDeps, EventTypes.DefenseActionEvent);
                    DetectionHelper.DetectAttackerActions(game, geDeps);
                    AssetHelper.NotifyAssetsChanged(game, geDeps, ActorTypes.Defender);
                    ReportInsightShieldStatusToDefenders(game, geDeps);
                    SkipActors(game, geDeps, game.Defenders.Values);
                    MoveToGamePhase(game, geDeps, GamePhase.Defense);
                }

                break;
            case GamePhase.Defense:
                if (game.HaveAllDefendersCompletedTheirActions() &&
                    (game.Turn == 1 || game.HaveAllDefendersDrawnNewActions()))
                {
                    if (IsGameOver(game))
                    {
                        EndGame(game, geDeps);
                    }
                    else
                    {
                        foreach (var defender in game.Defenders.Values)
                        {
                            SendShoppingAssortment(game, geDeps, defender);
                        }

                        game.InitTurnTrackerDefender();
                        DetectionHelper.DetectDefenderActions(game, geDeps);
                        AssetHelper.NotifyAssetsChanged(game, geDeps, ActorTypes.Attacker);
                        ReportInsightShieldStatusToDefenders(game, geDeps);
                        BeginNextTurn(game, geDeps);
                    }
                }

                break;
            case GamePhase.InitDraw:
                if (game.HaveAllPlayersDrawnNewActions())
                {
                    game.InitTurnTrackerAttacker();
                    game.InitTurnTrackerDefender();
                    SkipActors(game, geDeps, game.Attackers.Values);

                    BeginNextTurn(game, geDeps);
                }

                break;
        }

        game.GameboardLog.PublishNewRecords(game, geDeps.Notifier);
    }

    private static void ReportInsightShieldStatusToDefenders(GameInstance game, GameEngineDependencies geDeps)
    {
        foreach (var defender in game.Defenders.Values)
        {
            geDeps.Notifier.AttributeChanged(defender, ChangedPlayerAttributeType.InsightShield,
                defender.GetRemainingInsightShieldStrength());
        }
    }

    private static void MoveToGamePhase(GameInstance game, GameEngineDependencies geDeps, GamePhase newPhase)
    {
        game.SetPhase(newPhase);
        geDeps.Notifier.GamePhaseChanged(game.Actors.Values.ToList(), game.Phase);
        geDeps.Logger.LogDebug("Game phase changed to {NewPhase}", newPhase);

        HandlePostGamePhaseChangeActions(game, geDeps);
    }

    public static void EndGame(GameInstance game, GameEngineDependencies geDeps)
    {
        if (game.Phase == GamePhase.Ended) return;

        MoveToGamePhase(game, geDeps, GamePhase.Ended);

        var result = ActorHelper.DetermineEndGameStatePerPlayer(game);

        var gameFinishedInfo = new GameFinishedInfoModel()
        {
            GameId = game.Id,
            Turns = game.Turn,
        };

        foreach (var (actorId, (endState, message)) in result)
        {
            var actor = game.Actors[actorId];

            var xpSummary = PostGameXpFactory.Create(game, actor, endState);

            if (xpSummary.IsXpGranted() && !actor.IsBot())
            {
                geDeps.Datastore.GrantXp(actor.UserId, xpSummary, game.ActorStatCounters[actor.Id], actor.Type,
                    endState, game.XpEventId);
            }

            geDeps.Notifier.GameEnded(actor, game, endState, message, xpSummary);

            game.GameboardLog.AddEntry(actor,
                endState switch
                {
                    GamePlayerEndState.Won => GameboardLogMessageType.GameWon,
                    GamePlayerEndState.Lost => GameboardLogMessageType.GameLost,
                    GamePlayerEndState.AutoDefeatAssetOffline => GameboardLogMessageType.GameDraw,
                    GamePlayerEndState.Surrendered => GameboardLogMessageType.GameSurrendered,
                    _ => throw new ArgumentException($"Invalid state '{endState}'")
                }, _ => { });

            geDeps.Logger.LogDebug("Player {Actor} has {GameFinishedState}", actor, endState);

            gameFinishedInfo.ActorInfos.Add(new GameFinishedInfoModel.ActorInfoModel()
            {
                UserId = actor.UserId,
                ActorId = actor.Id,
                ActorType = actor.Type,
                EndState = endState,
                ConnectionId = actor.ConnectionId,
                StatsInfoJson = System.Text.Json.JsonSerializer.Serialize(game.ActorStatCounters[actor.Id]),
                Xp = xpSummary.Sum,
            });
        }

        geDeps.Datastore.GameFinished(gameFinishedInfo);

        game.GameboardLog.AddEntry(game.Actors.Values, GameboardLogMessageType.GameEnded, _ => { });
        game.GameboardLog.PublishNewRecords(game, geDeps.Notifier);

        geDeps.Logger.LogInformation("Game {GameId} ended", game.Id);
    }

    private static void HandlePostGamePhaseChangeActions(GameInstance game, GameEngineDependencies geDeps)
    {
        switch (game.Phase)
        {
            case GamePhase.DefenderPreSetup:
                foreach (var actor in game.Defenders.Values)
                {
                    game.TurnTrackers[actor.Id].InitForNewTurn();
                    game.TurnTrackers[actor.Id]
                        .SetActionPoints(game.Scenario.GetDefenderPreSetupActionNumber(game, actor) *
                                         Constants.GAME_ENGINE_ACTION_POINTS_PER_TURN_DEFENDER);
                    CardHelper.OfferActions(game, geDeps, actor, false);
                }

                break;
            case GamePhase.InitDraw:
                foreach (var actor in game.Actors.Values)
                {
                    CardHelper.OfferActions(game, geDeps, actor, true);
                }

                break;
            case GamePhase.Defense:
                if (game.Turn > 1)
                {
                    foreach (var defender in game.Defenders.Values)
                    {
                        if (!defender.HasLeft)
                        {
                            CardHelper.OfferActions(game, geDeps, defender, false);
                        }
                    }
                }

                break;
            case GamePhase.Attack:
                if (game.Turn > 1)
                {
                    foreach (var attacker in game.Attackers.Values)
                    {
                        if (!attacker.HasLeft && attacker.CurrentIni > 0)
                        {
                            CardHelper.OfferActions(game, geDeps, attacker, false);
                        }
                    }
                }

                break;
        }
    }

    private static void SkipActors(GameInstance game, GameEngineDependencies geDeps, IEnumerable<ActorModel> actors)
    {
        foreach (var actor in actors)
        {
            if (actor.HasLeft || (actor.IsAttacker && actor.CurrentIni == 0))
            {
                game.TurnTrackers[actor.Id].InitForNewTurn();
                game.TurnTrackers[actor.Id].SetHasDrawn();
                geDeps.Logger.LogDebug("Skipped turn of {Actor}", actor);
            }
        }
    }

    private static void SendShoppingAssortment(GameInstance game, GameEngineDependencies geDeps, ActorModel actor)
    {
        var selectedEquipment = EquipmentHelper.CreateShopSelection(game, actor);
        game.Shops[actor.Id] = selectedEquipment;
        geDeps.Notifier.UpdateEquipmentShop(game, actor,
            selectedEquipment.Select(x => game.EquipmentTemplates[x]).ToList());
    }

    private static void BeginNextTurn(GameInstance game, GameEngineDependencies geDeps)
    {
        game.SetTurn(game.Turn + 1);
        geDeps.Logger.LogDebug("New turn: {Turn}", game.Turn);

        if (game.Turn > 1)
        {
            geDeps.Notifier.TurnChanged(game.Actors.Values, game.Turn);
            game.GameboardLog.AddEntry(game.Actors.Values, GameboardLogMessageType.NewTurn, c => c.SetTurn(game.Turn));

            EffectHelper.MovePermanentEffects(game, geDeps, EventTypes.AttackActionEvent);

            foreach (var defender in game.Defenders.Values)
            {
                ActorHelper.ReportAutoDefeatToGameboardLog(game, defender);
                ActorHelper.GrantDefenderIncome(game, geDeps.Notifier, defender);
            }
        }

        MoveToGamePhase(game, geDeps, GamePhase.Attack);
    }

    private static bool IsGameOver(GameInstance game)
    {
        var onlineAttackers = game.Attackers.Values.Where(x => !x.HasLeft).ToList();

        if (onlineAttackers.Count == 0) return true;

        var onlineDefenders = game.Defenders.Values.Where(x => !x.HasLeft).ToList();

        if (onlineDefenders.Count == 0) return true;

        if (onlineAttackers.Any(x => ActorHelper.HasGoalsFulfilled(game, x))) return true;

        if (onlineDefenders.Any(x => ActorHelper.HasLostBecauseOf3APenatly(game, x))) return true;

        if (onlineAttackers.All(ActorHelper.IsOutOfTurns)) return true;

        return false;
    }

    public static bool HasActorDrawnActions(GameInstance game, ActorModel actor)
    {
        if (actor.IsDefender && game.Phase == GamePhase.DefenderPreSetup)
        {
            return true;
        }

        if (game.Turn == 1)
        {
            return true;
        }

        if (!ActorHelper.IsActorMissingActions(game, actor))
        {
            return true;
        }

        if (game.TurnTrackers[actor.Id].ActionsDrawn)
        {
            return true;
        }

        return false;
    }
}