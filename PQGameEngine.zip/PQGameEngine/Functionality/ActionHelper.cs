using PQGameEngine.Enums;
using PQGameEngine.Exceptions;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Templates;

namespace PQGameEngine.Functionality;

public static class ActionHelper
{
    public static (List<Guid> offeredActionIds, int requiredAmount) CreateActionSelection(GameInstance game,
        ActorModel actor, bool offerEntireDeck)
    {
        var requiredAmount = ActorHelper.GetNumberOfActionsToDraw(game, actor);

        if (requiredAmount == 0) return ([], requiredAmount);

        var allRoleTemplateIds = game.ActionDecksMain[actor.Id].ToList();
        if (game.Options.SupportActionsMode == GameOptionSupportActionsMode.ENABLED)
        {
            allRoleTemplateIds = allRoleTemplateIds.Concat(game.ActionDecksSupport[actor.Id]).ToList();
        }

        if (game.Phase == GamePhase.DefenderPreSetup)
        {
            if (offerEntireDeck) return (allRoleTemplateIds, requiredAmount);
            var toOffer = allRoleTemplateIds.Where(x =>
                    game.ActionTemplates[x].DefenseType.In(DefenseActionType.Detection, DefenseActionType.Prevention))
                .ToList();

            return (toOffer, requiredAmount);
        }

        if (game.Options.ActionShopMode == GameOptionActionShopMode.ALL_ACTIONS || offerEntireDeck)
        {
            return (allRoleTemplateIds, requiredAmount);
        }

        var offeredActionsLimit =
            (int)(requiredAmount + Math.Round(0.5 * actor.CurrentSoph + 0.5 * actor.CurrentDet, 0));

        var randomAmount = requiredAmount - 1;

        if (actor.IsAttacker)
        {
            List<AttackStages> visibleAttackStages = actor.VisibleAssets
                .Select(aid => game.Assets[aid].CurrentAttackStage)
                .Distinct()
                .ToList();

            if (visibleAttackStages.Count > offeredActionsLimit)
            {
                throw new PenQuestException(Errors.InvalidArgument,
                    $"Length of assets with visible attack stages {visibleAttackStages.Count} is greater than the max length of the offer {offeredActionsLimit}");
            }

            bool hasPlayableAction = actor.Actions.Any(actionId =>
                IsTemplateCurrentlyPlayable(game, actor, game.Actions[actionId].Template));

            var offeredActions = new List<Guid>();

            for (int i = 0; i < visibleAttackStages.Count; i++)
            {
                bool playable = !hasPlayableAction && offeredActions.Count >= randomAmount;
                List<ActionTemplate> templates =
                    GetPossibleActionTemplates(game, actor, visibleAttackStages[i], playable);
                offeredActions.Add(templates[game.Random.Next(templates.Count)].Id);
            }

            List<ActionTemplate> possibleTemplates = GetPossibleActionTemplates(game, actor, null, true);

            for (int i = offeredActions.Count; i < offeredActionsLimit; i++)
            {
                if (!hasPlayableAction && offeredActions.Count >= randomAmount)
                {
                    ActionTemplate randomSelection = possibleTemplates[game.Random.Next(possibleTemplates.Count)];
                    offeredActions.Add(randomSelection.Id);
                }
                else
                {
                    var tid = allRoleTemplateIds[game.Random.Next(allRoleTemplateIds.Count)];
                    ActionTemplate randomSelection = game.ActionTemplates[tid];
                    offeredActions.Add(randomSelection.Id);
                }
            }

            return (offeredActions, requiredAmount);
        }

        if (actor.IsDefender)
        {
            bool hasPlayableAction = actor.Actions.Any(actionId =>
                IsTemplateCurrentlyPlayable(game, actor, game.Actions[actionId].Template));

            var offeredActions = new List<Guid>();

            if (!hasPlayableAction)
            {
                offeredActions = Enumerable.Range(0, randomAmount)
                    .Select(_ =>
                        game.ActionTemplates[allRoleTemplateIds[game.Random.Next(allRoleTemplateIds.Count)]].Id)
                    .ToList();

                List<ActionTemplate> possibleTemplates = GetPossibleActionTemplates(game, actor, null, true);

                offeredActions.AddRange(Enumerable
                    .Range(offeredActions.Count, offeredActionsLimit - randomAmount)
                    .Select(_ => possibleTemplates[game.Random.Next(possibleTemplates.Count)].Id));
            }
            else
            {
                offeredActions = Enumerable.Range(0, offeredActionsLimit)
                    .Select(_ =>
                        game.ActionTemplates[allRoleTemplateIds[game.Random.Next(allRoleTemplateIds.Count)]].Id)
                    .ToList();
            }

            return (offeredActions, requiredAmount);
        }

        throw new PenQuestException(Errors.UnknownActorError,
            $"Actor {actor} is of unknown type {actor.GetType()}");
    }

    public static List<ActionTemplate> GetPossibleActionTemplates(GameInstance game, ActorModel actor,
        AttackStages? attackStage, bool playable)
    {
        var requirements = new List<Func<ActionTemplate, bool>>();

        if (attackStage.HasValue)
        {
            requirements.Add(template => template.AttackStage == attackStage);
        }

        if (playable)
        {
            requirements.Add(template => IsTemplateCurrentlyPlayable(game, actor, template));
        }

        var deck = game.ActionDecksMain[actor.Id];
        var filteredTemplates = deck
            .Where(tid => requirements.All(r => r(game.ActionTemplates[tid])))
            .Select(tid => game.ActionTemplates[tid])
            .ToList();

        return filteredTemplates;
    }

    public static bool IsTemplateCurrentlyPlayable(GameInstance game, ActorModel actor, ActionTemplate actionTemplate)
    {
        if (actionTemplate.SophReq > actor.CurrentSoph) return false;
        if (actor.IsDefender && actionTemplate.IsAttackAction) return false;
        if (actor.IsAttacker && actionTemplate.IsDefenseAction) return false;

        List<AssetModel> relevantAssets = null;

        if (actionTemplate.IsMainAction && actionTemplate.TargetType == TargetTypes.Single)
        {
            var assetCombinations = GetVisibileAssetProperties(game, actor);

            if (!ActionHasPossibleTarget(actionTemplate, assetCombinations, out _))
            {
                return false;
            }
        }

        if (actionTemplate.IsSupportAction && !actionTemplate.ValidMainActions
                .Intersect(actor.Actions.Select(x => game.Actions[x].TemplateId)).Any())
        {
            return false;
        }

        if (actionTemplate.RequiredEquipment?.Count > 0)
        {
            foreach (var equipmentId in actionTemplate.RequiredEquipment)
            {
                bool possesSpecificRequire = false;
                foreach (var possesEqId in actor.Equipment)
                {
                    if (game.Equipment.TryGetValue(possesEqId, out var possesEq))
                    {
                        if (possesEq.TemplateId == equipmentId)
                        {
                            possesSpecificRequire = true;
                            break;
                        }
                    }
                }

                if (!possesSpecificRequire)
                {
                    return false;
                }
            }
        }

                                        if (actionTemplate.IsMainAction)
        {
            foreach (var effectId in actionTemplate.Effects)
            {
                var effect = game.Scenario.EffectTemplates[effectId];

                if (effect.IsIncDecEffect() && effect.Credits < 0)
                {
                    return false;
                }
            }
        }

        return true;
    }

                        public static Dictionary<(AssetCategories assetCategory, Oses os, AttackStages attackStage, bool hasAdmin),
            HashSet<int>>
        GetVisibileAssetProperties(GameInstance game, ActorModel actor)
    {
        var assetProperties =
            new Dictionary<(AssetCategories assetCategory, Oses os, AttackStages attackStage, bool hasAdmin),
                HashSet<int>>();

        foreach (var visibleAssetId in actor.VisibleAssets)
        {
            var asset = game.Assets[visibleAssetId];
            if (!asset.IsOffline)
            {
                foreach (var atkStage in Enum.GetValues<AttackStages>())
                {
                    if (atkStage <= asset.CurrentAttackStage)
                    {
                        var k = (asset.Template.Category, asset.Template.Os, atkStage, asset.AdminAccessEnabled);
                        if (!assetProperties.TryGetValue(k, out var assetIds))
                        {
                            assetIds = new HashSet<int>();
                            assetProperties.Add(k, assetIds);
                        }

                        assetIds.Add(asset.Id);
                    }
                }
            }
        }

        return assetProperties;
    }

    public static bool ActionHasPossibleTarget(ActionTemplate action,
        Dictionary<(AssetCategories assetCategory, Oses os, AttackStages attackStage, bool hasAdmin), HashSet<int>>
            assetProperties,
        out HashSet<int> possibleTargets)
    {
        possibleTargets = new HashSet<int>();

        foreach (var assetCategory in action.AssetCategories.Count == 0
                     ? Enum.GetValues<AssetCategories>()
                     : action.AssetCategories.ToArray())
        {
            foreach (var os in action.Oses.Count == 0 ? Enum.GetValues<Oses>() : action.Oses.ToArray())
            {
                foreach (var atkStage in Enum.GetValues<AttackStages>())
                {
                    if (atkStage >= action.AttackStage)
                    {
                        if (assetProperties.TryGetValue((assetCategory, os, atkStage, action.RequireAdmin),
                                out var targetIds))
                        {
                            foreach (var t in targetIds)
                            {
                                possibleTargets.Add(t);
                            }
                        }
                    }
                }
            }
        }

        return possibleTargets.Count > 0;
    }

    public static bool ActorFulfillsActionRequirements(ActionTemplate actionTemplate, ActorModel actor,
        HashSet<(Oses, AssetCategories)> osCatCombinations, decimal sophSlackInc, decimal sophSlackDec)
    {
        if ((actionTemplate.SophReq + sophSlackDec) <= (actor.CurrentSoph + sophSlackInc))
        {
                                                                                                            
                                                
            foreach (var os in actionTemplate.Oses)
            {
                foreach (var category in actionTemplate.AssetCategories)
                {
                    if (osCatCombinations.Contains((os, category)))
                    {
                        return true;
                    }
                }
            }
        }

        return false;
    }
}