using PQGameEngine.Enums;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;
using PQGameEngine.Models.Internal;

namespace PQGameEngine.Functionality;

public class ActorStatsHelper(GameInstance game)
{
    private PlayerStatCounter GetActorStats(ActorModel actor)
    {
        if (!game.ActorStatCounters.TryGetValue(actor.Id, out var stats))
            throw new ArgumentException($"Stats for Actor {actor} not initialized");

        return stats;
    }

    public void AddActionPlayed(ActorModel actor, MainActionModel action, ActionSuccessState successState)
    {
        var stats = GetActorStats(actor);

        UpdateActionsCounters(action, successState, stats);
        UpdateMva(action, stats);
    }

    private void UpdateMva(MainActionModel action, PlayerStatCounter stats)
    {
        foreach (var actionEventId in action.ActionEvents.Values)
        {
            var actionEvent = game.Events[actionEventId];
            if (actionEvent is AssetActionEvent aae)
            {
                var dmgDealt = aae.DamageDealt.SumDamage();
                var dmgHealed = aae.DamageDealt.SumHeal();

                stats.DamageCaused += dmgDealt;
                stats.DamageHealed += dmgHealed;

                var maxImpact = Math.Max(dmgDealt, dmgHealed);
                if (stats.Mva == null || stats.Mva.MaxImpact < maxImpact)
                {
                    stats.Mva = new PlayerStatCounter.MostValuableAction()
                    {
                        ActionId = action.Id,
                        MaxImpact = maxImpact
                    };
                }
            }
        }
    }

    private static void UpdateActionsCounters(MainActionModel action, ActionSuccessState successState,
        PlayerStatCounter stats)
    {
        switch (action.Template.ActionType)
        {
            case ActionTypes.Attack:
                switch (action.Template.AttackStage)
                {
                    case AttackStages.Reconnaissance:
                        UpdateCounter(stats.ReconActions, successState);
                        break;
                    case AttackStages.InitialAccess:
                        UpdateCounter(stats.InitialAccessActions, successState);
                        break;
                    case AttackStages.Execution:
                        UpdateCounter(stats.ExecutionActions, successState);
                        break;
                    default:
                        throw new ArgumentException($"Invalid attack stage type {action.Template.AttackStage}");
                }

                break;
            case ActionTypes.Defense:
                switch (action.Template.DefenseType)
                {
                    case DefenseActionType.Prevention:
                        UpdateCounter(stats.PreventionActions, successState);
                        break;
                    case DefenseActionType.Detection:
                        UpdateCounter(stats.DetectionActions, successState);
                        break;
                    case DefenseActionType.Response:
                        UpdateCounter(stats.ResponseActions, successState);
                        break;
                    default:
                        throw new ArgumentException($"Invalid defense type {action.Template.DefenseType}");
                }

                break;
            default:
                throw new ArgumentException($"Invalid action type {action.Template.ActionType}");
        }
    }

    private static void UpdateCounter(PlayerStatCounter.ActionPlayedCounter counter, ActionSuccessState successState)
    {
        switch (successState)
        {
            case ActionSuccessState.Failed:
                counter.Failed++;
                break;
            case ActionSuccessState.PartialSuccess:
                counter.PartialSuccess++;
                break;
            case ActionSuccessState.Success:
                counter.Success++;
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(successState), successState, "Invalid success state");
        }
    }

    public void CompromisedSystem(ActorModel actor, AssetModel asset)
    {
        GetActorStats(actor).SystemsCompromised.Add(asset.Id);
    }

    public void UnCompromisedSystem(ActorModel actor, AssetModel asset)
    {
        GetActorStats(actor).CompromisedSystemsMitigated.Add(asset.Id);
    }

    public void UsedEquipment(ActorModel actor, EquipmentModel eq)
    {
        var stats = GetActorStats(actor);

        switch (eq.Template.EquipmentType)
        {
            case EquipmentSubTypes.EXPLOIT:
                stats.ExploitsUsed++;
                break;
        }
    }

    public void FixApplied(ActorModel actor)
    {
        GetActorStats(actor).ExploitsFixed++;
    }

    public void EquipmentReceived(ActorModel actor, EquipmentModel eq)
    {
        var stats = GetActorStats(actor);

        switch (eq.Template.EquipmentType)
        {
            case EquipmentSubTypes.EXPLOIT:
                stats.ExploitsFound++;
                break;
            case EquipmentSubTypes.CREDENTIALS:
                stats.CredentialsGathered++;
                break;
        }
    }

    public void AdminGranted(ActorModel actor, AssetModel asset)
    {
        GetActorStats(actor).AdminGained++;
    }

    public void AdminRevoked(ActorModel actor, AssetModel asset)
    {
        GetActorStats(actor).AdminRevoked++;
    }

    public void InsightGained(ActorModel actor, int insightGain)
    {
        GetActorStats(actor).InsightGained += insightGain;
    }

    public void ActionDetected(ActorModel actor)
    {
        GetActorStats(actor).ActionsDetected++;
    }

    public void DamagePrevented(ActorModel actor, int absorbed)
    {
        GetActorStats(actor).DamagePrevented += absorbed;
    }

    public void InsightPrevented(ActorModel actor, int absorbed)
    {
        GetActorStats(actor).InsightPrevented += absorbed;
    }

    public void EquipmentBought(ActorModel actor, EquipmentModel equipment)
    {
        var stats = GetActorStats(actor);
        stats.EquipmentBought++;
        stats.CreditsSpent += equipment.Price;
    }
}