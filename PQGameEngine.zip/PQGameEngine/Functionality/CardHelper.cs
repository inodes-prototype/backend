using PQGameEngine.Enums;
using PQGameEngine.Exceptions;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;

namespace PQGameEngine.Functionality;

public static class CardHelper
{
    public static void OfferActions(GameInstance game, GameEngineDependencies geDeps, ActorModel actor,
        bool offerEntireDeck)
    {
        if (actor.IsAttacker)
        {
            if (game.Phase.NotIn(GamePhase.Attack, GamePhase.InitDraw))
            {
                throw new PenQuestException(Errors.GamePhaseMismatchError,
                    $"Game phase Attack is required for you to get an offer. Current game phase is {game.Phase}");
            }
        }
        else if (actor.IsDefender)
        {
            if (game.Phase.NotIn(GamePhase.Defense, GamePhase.InitDraw, GamePhase.DefenderPreSetup))
            {
                throw new PenQuestException(Errors.GamePhaseMismatchError,
                    $"Game phase Defense is required for you to get an offer. Current game phase is {game.Phase}");
            }
        }
        else
        {
            throw new PenQuestException(Errors.UnknownActorError,
                $"Actor {actor} is of unknown type {actor.GetType()}");
        }

        var (offeredActions, requiredAmount) = ActionHelper.CreateActionSelection(game, actor, offerEntireDeck);

        game.TurnTrackers[actor.Id].SetOfferedActions(offeredActions);

        if (requiredAmount > 0)
        {
            var offeredActionTemplates = offeredActions
                .Select(tid => game.ActionTemplates[tid])
                .OrderBy(x => x.IsDefenseAction ? (int)x.DefenseType : (int)x.AttackStage)
                .ToList();

            geDeps.Notifier.OfferSelection(actor, offeredActionTemplates, requiredAmount, game);
        }
    }
}