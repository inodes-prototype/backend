using PQGameEngine.Enums;
using PQGameEngine.Exceptions;
using PQGameEngine.Functionality.Effects;
using PQGameEngine.Functionality.GameboardLog;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality;

public static class DetectionHelper
{
    public static void DetectAttackerActions(GameInstance game, GameEngineDependencies geDeps)
    {
        foreach (var defender in game.Defenders.Values)
        {
            DetectActionEvents(game, geDeps, defender);
        }
    }

    public static void DetectDefenderActions(GameInstance game, GameEngineDependencies geDeps)
    {
        foreach (var attacker in game.Attackers.Values)
        {
            DetectActionEvents(game, geDeps, attacker);
        }
    }

    private static void DetectActionEvents(GameInstance game, GameEngineDependencies geDeps, ActorModel actor)
    {
        int startIdx = 0;
        if (game.JournalIdx.TryGetValue(actor.Id, out var tidx))
        {
            startIdx = tidx;
        }

        int clearedIdx = startIdx;
        List<ActionEvent> detectedEvents = new List<ActionEvent>();

        for (int i = startIdx; i <= game.Turn; i++)
        {
            if (game.Journal.TryGetValue(i, out var allEventsPerTurn))
            {
                List<ActionEvent> relevantEvents = GetRelevantEvents(game, allEventsPerTurn, actor);

                foreach (var actionEvent in relevantEvents)
                {
                    if (TryDetectActionEvent(game, geDeps, actionEvent, actor))
                    {
                        EventHelper.MarkEventDetected(game, geDeps, actionEvent, actor);
                        detectedEvents.Add(actionEvent);
                    }
                }

                if (clearedIdx == i && relevantEvents.Count > 0 &&
                    relevantEvents.All(e => e.Detected.ContainsKey(actor.Id)))
                {
                    clearedIdx++;
                }
            }
        }

        game.JournalIdx[actor.Id] = clearedIdx;

        if (detectedEvents.Count > 0)
        {
            geDeps.Notifier.ActionsDetected(actor, game, detectedEvents.Select(e => e.MainAction).Distinct().ToList());

            var relevantAssetIds = new HashSet<int>();
            foreach (var actionEvent in detectedEvents)
            {
                game.GameboardLog.AddEntry(game, actor, actionEvent);

                if (actionEvent is AssetActionEvent assetActionEvent)
                {
                    relevantAssetIds.Add(assetActionEvent.AssetId);
                    foreach (var (assetId, _) in assetActionEvent.AppliedDependencyDamage)
                    {
                        relevantAssetIds.Add(assetId);
                    }
                }
            }

            var assets = relevantAssetIds.Select(id => game.Assets[id]).ToList();
            foreach (var asset in assets)
            {
                asset.MarkAssetAsChanged();
            }
        }
    }

    private static bool TryDetectActionEvent(GameInstance game, GameEngineDependencies geDeps, ActionEvent actionEvent,
        ActorModel detectingActor)
    {
        if (actionEvent.Succeeded == null) return false;
        if (!actionEvent.Detectable) return false;
        if (actionEvent.Detected.ContainsKey(detectingActor.Id)) return true;
        if (game.Turn > actionEvent.Turn + actionEvent.DetectableDuring) return false;

        if (actionEvent is AssetActionEvent assetActionEvent)
        {
            var asset = game.Assets[assetActionEvent.AssetId];
            if (asset.Owner == null)
                throw new PenQuestException(Errors.IsNoneErrorFatal,
                    $"Owner of asset {assetActionEvent.AssetId} is null");
            if (!asset.CurrentExposedState.Any() && detectingActor.Id != asset.Owner)
                return false;
            if (!detectingActor.VisibleAssets.Contains(asset.Id))
                return false;
        }

        EventHelper.ApplyPermanentEquipment(game, geDeps, actionEvent, detectingActor);

        if (actionEvent is AssetActionEvent assetActionEvent2)
        {
            var asset = game.Assets[assetActionEvent2.AssetId];
            foreach (var eventId in asset.PlayedActionEvents)
            {
                var playedActionEvent = game.Events[eventId] as ActionEvent;
                if (playedActionEvent?.Succeeded == true)
                {
                    foreach (var effectId in playedActionEvent.Effects)
                    {
                        var effect = game.Effects[effectId];
                        if (effect.IsPermanentEffect())
                        {
                            EffectBehaviorFactory.Create(game, geDeps, effect).Apply(playedActionEvent,
                                EffectTimingType.PreSuccess, actionEvent);
                        }
                    }
                }
            }
        }

        decimal actualDetectionChance = actionEvent.Succeeded == false
            ? actionEvent.GetDetectionChanceFailed()
            : actionEvent.GetDetectionChance();

        geDeps.Logger.LogDebug(
            "{Actor} attempts to detect {ActionEvent} on {Target} with actual DC: {ActualDetectionChance}...",
            detectingActor, actionEvent, actionEvent is AssetActionEvent ae ? ae.AssetId.ToString() : "None",
            actualDetectionChance);

        bool detected;
        if (game.Options.ActionDetectionMode == GameOptionActionDetectionMode.ALWAYS_DETECT)
        {
            detected = true;
        }
        else if (game.Options.ActionDetectionMode == GameOptionActionDetectionMode.DEFAULT)
        {
            detected = game.Random.DidMyRollSucceed(actualDetectionChance, out var roll);
            geDeps.Logger.LogDebug("Detect Action chance: {Roll} <= {Chance}? detected={Success}", roll,
                actualDetectionChance,
                detected);
        }
        else
        {
            throw new PenQuestException(
                Errors.ValueErrorFatal,
                $"Unknown game option for action detection mode: {game.Options.ActionDetectionMode}"
            );
        }

        geDeps.Logger.LogDebug("Detection success = {Success}", detected);

        return detected;
    }

    private static List<ActionEvent> GetRelevantEvents(GameInstance game, List<Guid> events, ActorModel actor)
    {
        var relevantEvents = new List<ActionEvent>();

        foreach (var eventId in events)
        {
            var @event = game.Events[eventId];
            if (@event is ActionEvent actionEvent && actionEvent.Succeeded.HasValue && actionEvent.Detectable &&
                !actionEvent.Detected.ContainsKey(actor.Id) &&
                game.Turn <= actionEvent.Turn + actionEvent.DetectableDuring)
            {
                var isRelevant = false;

                if (actor.IsDefender)
                {
                    if (actionEvent.TargetType == TargetTypes.Untargeted ||
                        (actionEvent is AssetActionEvent assetActionEvent &&
                         actor.OwnAssets.Contains(assetActionEvent.AssetId)))
                    {
                        isRelevant = true;
                    }
                }
                else if (actor.IsAttacker)
                {
                    if (actionEvent.IsDefenseAction)
                    {
                        if (actionEvent.Counters != null)
                        {
                            var counteredEvent = game.Events[actionEvent.Counters!.Value] as ActionEvent;
                            if (counteredEvent?.Actor == actor.Id)
                            {
                                isRelevant = true;
                            }
                        }

                        if (actionEvent is AssetActionEvent assetActionEvent &&
                            actor.VisibleAssets.Contains(assetActionEvent.AssetId))
                        {
                            switch (game.Options.DefenderActionsDetectable)
                            {
                                case GameOptionDefenderActionsDetectableMode.ResponseOnly:
                                    if (actionEvent.MainAction.Template.DefenseType == DefenseActionType.Response)
                                    {
                                        isRelevant = true;
                                    }

                                    break;
                                case GameOptionDefenderActionsDetectableMode.PreventionAndResponse:
                                    if (actionEvent.MainAction.Template.DefenseType.In(DefenseActionType.Prevention,
                                            DefenseActionType.Response))
                                    {
                                        isRelevant = true;
                                    }

                                    break;
                                case GameOptionDefenderActionsDetectableMode.DetectionAndResponse:
                                    if (actionEvent.MainAction.Template.DefenseType.In(DefenseActionType.Detection,
                                            DefenseActionType.Response))
                                    {
                                        isRelevant = true;
                                    }

                                    break;
                                case GameOptionDefenderActionsDetectableMode.AllDefenseAction:
                                    isRelevant = true;
                                    break;
                                default:
                                    throw new PenQuestException(
                                        Errors.ValueErrorFatal,
                                        $"Unknown game option for defender detection mode: {game.Options.DefenderActionsDetectable}"
                                    );
                            }
                        }
                    }
                }

                if (isRelevant)
                {
                    relevantEvents.Add(actionEvent);
                }
            }
        }

        return relevantEvents;
    }

    public static void TryFlagAttackerDetectedFirstTime(GameInstance game, GameEngineDependencies geDeps,
        ActorModel detectedActor, ActorModel detectingActor)
    {
        if (!detectedActor.FirstActionDetected)
        {
            detectedActor.RegisterActionDetection(game.Turn);
            foreach (var receiver in game.Actors.Values)
            {
                geDeps.Notifier.ActorDetected(receiver, detectedActor.Id);
            }
        }
    }
}