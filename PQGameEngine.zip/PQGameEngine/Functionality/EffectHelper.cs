using PQGameEngine.Enums;
using PQGameEngine.Functionality.Effects;
using PQGameEngine.Functionality.Shields;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;

namespace PQGameEngine.Functionality;

public static class EffectHelper
{
    public static void MovePermanentEffects(GameInstance game, GameEngineDependencies geDeps, EventTypes eventType)
    {
        var notifyAssets = new HashSet<int>();

        var assetTracker = AssetVisibilityTracker.Create(game);

        foreach (var eventId in game.EventsToHandleEachTurn)
        {
            var gameEvent = game.Events[eventId];

            if (gameEvent is ActionEvent actionEvent && actionEvent.Succeeded == true &&
                ((eventType == EventTypes.AttackActionEvent && actionEvent.IsAttackAction)
                 || (eventType == EventTypes.DefenseActionEvent && actionEvent.IsDefenseAction)))
            {
                var isAnyEffectActive = false;

                foreach (var effectId in actionEvent.Effects)
                {
                    var effect = game.Effects[effectId];

                    if (effect.IsPermanentEffect())
                    {
                        ProcessPermanentEffectAtEndOfTurn(game, effect, actionEvent, notifyAssets, geDeps);

                        isAnyEffectActive = isAnyEffectActive || effect.IsActive;
                    }
                }

                foreach (var equipmentId in actionEvent.EquipmentPlayedWith)
                {
                    var equipment = game.Equipment[equipmentId];
                    if (equipment.IsPermanentEquipment())
                    {
                        foreach (var effectId in equipment.Effects)
                        {
                            var effect = game.Effects[effectId];
                            ProcessPermanentEffectAtEndOfTurn(game, effect, actionEvent, notifyAssets, geDeps);

                            isAnyEffectActive = isAnyEffectActive || effect.IsActive;
                        }
                    }
                }

                if (!isAnyEffectActive)
                {
                    game.EventsToHandleEachTurn.Remove(gameEvent.Id);
                }
            }
        }

        foreach (var equipment in game.Equipment.Values)
        {
            if (equipment.IsPassiveEquipment() &&
                ((eventType == EventTypes.AttackActionEvent && equipment.IsAttackEquipment)
                 || (eventType == EventTypes.DefenseActionEvent && equipment.IsDefenseEquipment)))
            {
                foreach (var effectId in equipment.Effects)
                {
                    var effect = game.Effects[effectId];
                    ProcessPermanentEffectAtEndOfTurn(game, effect, null, notifyAssets, geDeps);
                }
            }
        }

        foreach (var assetId in notifyAssets)
        {
            game.Assets[assetId].MarkAssetAsChanged();
        }

        assetTracker.NotifyChanges(game, geDeps.Notifier);
    }

    private static void ProcessPermanentEffectAtEndOfTurn(GameInstance game, EffectModel effect,
        ActionEvent? actionEvent, HashSet<int> notifyAssets, GameEngineDependencies geDeps)
    {
        if (!effect.IsPermanentEffect()) return;
        if (!effect.IsActive) return;

        if (effect.Template.Type == EffectTypes.APPLY_DOT && effect.IsActive && actionEvent is AssetActionEvent aae)
        {
            var atkMask = aae.AttackMaskUsed;

            var dotTickDmg = DamageModel.Create(1, atkMask);

            var tAssetActionEvent = new AssetActionEvent(aae.AssetId, game.Turn, aae.MainAction, null, null)
            {
                Succeeded = true
            };
            tAssetActionEvent.ForceOverrideId(aae.Id);
            tAssetActionEvent.SetImpact(dotTickDmg);
            DamageShieldHelper.Create(game, geDeps, game.Assets[aae.AssetId]).TryApplyTo(tAssetActionEvent);
            dotTickDmg = tAssetActionEvent.CurrentImpact;

            if (dotTickDmg.Any(x => x > 0))
            {
                var dealtDmg = AssetHelper.DealDamageToAsset(game, geDeps, game.Assets[aae.AssetId], dotTickDmg, aae,
                    game.Actors[aae.Actor], game.Turn);

                if (dealtDmg.Any(x => x > 0))
                {
                    aae.SetDamageDealt(aae.DamageDealt + dealtDmg);
                    game.GameboardLog.AddEntry(game.Actors.Values, GameboardLogMessageType.DamagePeriodic, c => c
                        .SetInfo(game.Assets[aae.AssetId])
                        .SetDamage(dealtDmg[dealtDmg.MaxIdx()], dealtDmg.MaxIdx())
                        .SetInfo(aae.MainAction)
                    );
                }

                notifyAssets.Add(aae.AssetId);
            }
        }

        if (effect.Template.Type != EffectTypes.DAMAGE_SHIELD ||
            (effect.Template.Type == EffectTypes.DAMAGE_SHIELD && !game.Options.InfiniteShields))
        {
            effect.DecreaseOneTurn(out var isExpired);
            if (isExpired && actionEvent is AssetActionEvent aae2)
            {
                var asset = game.Assets[aae2.AssetId];
                notifyAssets.Add(asset.Id);
                game.GameboardLog.AddEntry(game.Actors[aae2.Actor], GameboardLogMessageType.EffectExpired, c => c
                    .SetInfo(aae2.MainAction)
                    .SetInfo(game.Assets[aae2.AssetId])
                    .SetInfo(effect)
                );
            }
        }
    }

    public static void ApplyPermanentEffectsOfPlayedActions(GameInstance game, GameEngineDependencies geDeps,
        ActionEvent actionEvent,
        EffectTimingType timing)
    {
        if (actionEvent is AssetActionEvent aae)
        {
            AssetModel asset = game.Assets[aae.AssetId];
            foreach (var eventId in asset.PlayedActionEvents)
            {
                var playedActionEvent = (ActionEvent)game.Events[eventId];
                if (playedActionEvent.Succeeded == true)
                {
                    foreach (var effectId in playedActionEvent.Effects)
                    {
                        var effect = game.Effects[effectId];
                        if (effect.IsPermanentEffect() && effect.IsActive)
                        {
                            EffectBehaviorFactory.Create(game, geDeps, effect)
                                .Apply(actionEvent, timing, playedActionEvent);
                        }
                    }
                }
            }
        }
    }
}