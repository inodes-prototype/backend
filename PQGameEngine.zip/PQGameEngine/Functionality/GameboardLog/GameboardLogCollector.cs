using PQGameEngine.Enums;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;
using PQGameEngine.Templates;

namespace PQGameEngine.Functionality.GameboardLog;

public class GameboardLogCollector
{
    private Dictionary<long, LogEntry> _log = [];
    private HashSet<long> _unpublishedEntryIds = [];

    private long _lastEntryId = 0;

    private long GetNextId() => Interlocked.Increment(ref _lastEntryId);

    public void AddEntry(IEnumerable<ActorModel> forActors, GameboardLogMessageType type,
        Action<LogEntryPayloadConfigurator> configurePayload)
    {
        foreach (var forActor in forActors)
        {
            AddEntry(forActor, type, configurePayload);
        }
    }

    public void AddEntry(ActorModel forActor, GameboardLogMessageType type,
        Action<LogEntryPayloadConfigurator> configurePayload)
    {
        var payload = new Dictionary<string, object>();
        var payloadConfigurator = new LogEntryPayloadConfigurator(payload);
        configurePayload(payloadConfigurator);
        var entry = new LogEntry(GetNextId(), forActor.Id, type, payload);
        _log.Add(entry.Id, entry);
        _unpublishedEntryIds.Add(entry.Id);
    }

    public IReadOnlyCollection<LogEntry> GetRecords(ActorModel forActor)
    {
        return _log.Values.Where(x => x.SlotId == forActor.Id && !_unpublishedEntryIds.Contains(x.Id)).ToList();
    }

    public void PublishNewRecords(GameInstance game, Notifier notifier)
    {
        if (_unpublishedEntryIds.Count == 0) return;

        var entriesPerActor = new Dictionary<int, List<LogEntry>>();

        foreach (var entryId in _unpublishedEntryIds)
        {
            var entry = _log[entryId];

            if (!entriesPerActor.TryGetValue(entry.SlotId, out var list))
            {
                list = [];
                entriesPerActor.Add(entry.SlotId, list);
            }

            list.Add(entry);
        }

        foreach (var (slotId, list) in entriesPerActor)
        {
            if (list.Count == 0) continue;

            var receiver = game.Actors[slotId];

            notifier.GameboardLogUpdated(receiver, game, list);
        }

        _unpublishedEntryIds.Clear();
    }
}

public static class GameboardLogCollectorExtensions
{
    public static void AddEntry(this GameboardLogCollector collector, GameInstance game, ActorModel forActor,
        GameEvent gameEvent)
    {
        if (gameEvent is ActionEvent ae)
        {
            var aae = gameEvent as AssetActionEvent;

            collector.AddEntry(forActor,
                ae.Succeeded switch
                {
                    true when forActor.Id == ae.Actor => GameboardLogMessageType.ActionSuccess,
                    true when forActor.Id != ae.Actor => GameboardLogMessageType.ActionSuccessDetected,
                    false when forActor.Id == ae.Actor => GameboardLogMessageType.ActionFailure,
                    false when forActor.Id != ae.Actor => GameboardLogMessageType.ActionFailureDetected,
                    _ => throw new ArgumentException("Event success state must not be unset at this point in time"),
                },
                c =>
                {
                    c.SetInfo(ae.MainAction);
                    c.SetInfo(game.Actors[ae.Actor]);

                    if (aae != null)
                    {
                        c.SetInfo(game.Assets[aae.AssetId]);
                    }
                });

            if (aae != null)
            {
                if (aae.AttackStageChangedInfo != null)
                {
                    collector.AddEntry(forActor, GameboardLogMessageType.AttackStageChanged, c => c
                        .SetInfo(game.Assets[aae.AssetId])
                        .SetAttackStage(aae.AttackStageChangedInfo.Value.newStage)
                        .SetInfo(aae.MainAction)
                    );
                }

                foreach (var assetId in aae.ExposedAssetInfo)
                {
                    collector.AddEntry(forActor, GameboardLogMessageType.AssetExposed, c => c
                        .SetInfo(game.Assets[aae.AssetId])
                        .SetExposedInfo(game.Assets[assetId]));
                }

                if (aae.DeflectedBy.Count > 0)
                {
                    foreach (var deflectedInfo in aae.DeflectedBy)
                    {
                        var deflectingAction = (game.Events[deflectedInfo.eventId] as ActionEvent)!.MainAction;
                        var shieldEffect = deflectingAction.Effects.Select(x => game.Effects[x])
                            .FirstOrDefault(x => x.Template.Type == EffectTypes.DAMAGE_SHIELD);

                        if (shieldEffect != null)
                        {
                            game.GameboardLog.AddEntry(forActor, GameboardLogMessageType.Prevention, c =>
                            {
                                if (shieldEffect.ActionTemplateSourceId.HasValue)
                                {
                                    c.SetInfo(game.ActionTemplates[shieldEffect.ActionTemplateSourceId.Value]);
                                }

                                c.SetInfo(shieldEffect);
                                c.SetInfo(game.Assets[aae.AssetId]);
                                c.SetInfo2(aae.MainAction);
                                c.SetDamage(deflectedInfo.deflectedDmg.Sum(), deflectedInfo.deflectedDmg.MaxIdx());
                            });
                        }
                    }

                    if (aae.DamageDealt.All(x => x == 0))
                    {
                        game.GameboardLog.AddEntry(forActor, GameboardLogMessageType.NoDamage, c => c
                            .SetInfo(game.Assets[aae.AssetId])
                            .SetInfo(aae.MainAction)
                        );
                    }
                }

                if (aae.DamageDealt != DamageModel.Zero)
                {
                    collector.AddDamageEntry(forActor, ae.MainAction, game.Assets[aae.AssetId], aae.DamageDealt,
                        GameboardLogMessageType.DamageFlat, GameboardLogMessageType.HealFlat);
                }

                foreach (var (targetAssetId, depDamage) in aae.AppliedDependencyDamage)
                {
                    collector.AddDamageEntry(forActor, ae.MainAction, game.Assets[targetAssetId], depDamage,
                        GameboardLogMessageType.CausedDependencyDamage, GameboardLogMessageType.CausedDependencyDamage);
                }
            }

            if (ae.WasEffectiveAction())
            {
                foreach (var effectId in ae.Effects)
                {
                    var effect = game.Effects[effectId];

                    if (effect.Template.Type == EffectTypes.REVEAL_ASSET) continue;

                    collector.AddEntry(forActor, GameboardLogMessageType.EffectApplied, c => c
                        .SetInfo(ae.MainAction)
                        .SetInfo(effect)
                    );

                    foreach (var eqId in effect.GeneratedEquipment)
                    {
                        var eq = game.Equipment[eqId];
                        game.GameboardLog.AddEntry(forActor, GameboardLogMessageType.InventoryAddedGranted, c => c
                            .SetInfo(ae.MainAction)
                            .SetInfo(eq)
                        );
                    }
                }
            }
        }
    }

    private static void AddDamageEntry(this GameboardLogCollector collector, ActorModel forActor,
        BaseActionModel action, AssetModel targetAsset, DamageModel damage,
        GameboardLogMessageType forValueGreaterThanZero, GameboardLogMessageType forValueLowerThanZero)
    {
        if (damage.C != 0)
        {
            collector.AddEntry(forActor, damage.C < 0 ? forValueLowerThanZero : forValueGreaterThanZero,
                c => c.SetInfo(action).SetInfo(targetAsset)
                    .SetDamage(damage.C, 'C'));
        }

        if (damage.I != 0)
        {
            collector.AddEntry(forActor, damage.I < 0 ? forValueLowerThanZero : forValueGreaterThanZero,
                c => c.SetInfo(action).SetInfo(targetAsset)
                    .SetDamage(damage.I, 'I'));
        }

        if (damage.A != 0)
        {
            collector.AddEntry(forActor, damage.A < 0 ? forValueLowerThanZero : forValueGreaterThanZero,
                c => c.SetInfo(action).SetInfo(targetAsset)
                    .SetDamage(damage.A, 'A'));
        }
    }
}

public static class GameboardLogVariables
{
    public const string TURN = "turn";
    public const string CREDITS = "credits";
    public const string INITIATIVE = "initiative";
    public const string DAMAGE = "damage";
    public const string DAMAGE_TYPE = "damage_type";
    public const string ATTACK_STAGE = "attack_stage";
    public const string ASSET_ID = "asset_id";
    public const string ASSET_NAME = "asset_name";
    public const string ASSET_TYPE = "asset_type";
    public const string EXPOSED_ASSET_ID = "exposed_asset_id";
    public const string EXPOSED_ASSET_NAME = "exposed_asset_name";
    public const string EXPOSED_ASSET_TYPE = "exposed_asset_type";
    public const string EFFECT_NAME = "effect_name";
    public const string EFFECT_ID = "effect_id";
    public const string EFFECT_TYPE = "effect_type";
    public const string ACTOR_NAME = "actor_name";
    public const string ACTOR_ID = "actor_id";
    public const string ACTOR_TYPE = "actor_type";
    public const string ACTION_NAME = "action_name";
    public const string ACTION_ID = "action_id";
    public const string ACTION_IS_ATTACK = "action_isAttack";
    public const string ACTION_INFO = "action_info";
    public const string ACTION2_NAME = "action2_name";
    public const string ACTION2_ID = "action2_id";
    public const string ACTION2_IS_ATTACK = "action2_isAttack";
    public const string ACTION2_INFO = "action2_info";
    public const string EQUIPMENT_NAME = "equipment_name";
    public const string EQUIPMENT_ID = "equipment_id";
    public const string EQUIPMENT_TYPE = "equipment_type";
}

public class LogEntryPayloadConfigurator
{
    private readonly Dictionary<string, object> _payload;

    public LogEntryPayloadConfigurator(Dictionary<string, object> payload)
    {
        _payload = payload;
    }

    public LogEntryPayloadConfigurator SetTurn(int turn)
    {
        _payload.Add(GameboardLogVariables.TURN, turn);

        return this;
    }

    public LogEntryPayloadConfigurator SetInfo(AssetModel asset)
    {
        _payload.Add(GameboardLogVariables.ASSET_ID, asset.Id);
        _payload.Add(GameboardLogVariables.ASSET_NAME, asset.Template.Name);
        _payload.Add(GameboardLogVariables.ASSET_TYPE, asset.Template.Category);

        return this;
    }

    public LogEntryPayloadConfigurator SetInfo(BaseActionModel action)
    {
        _payload.Add(GameboardLogVariables.ACTION_ID, action.Id);
        _payload.Add(GameboardLogVariables.ACTION_NAME, action.Template.Name);
        _payload.Add(GameboardLogVariables.ACTION_INFO,
            action.IsAttackAction ? action.Template.AttackStage : action.Template.DefenseType);
        _payload.Add(GameboardLogVariables.ACTION_IS_ATTACK, action.Template.IsAttackAction);

        return this;
    }

    public LogEntryPayloadConfigurator SetInfo(ActionTemplate action)
    {
        _payload.Add(GameboardLogVariables.ACTION_ID, action.Id);
        _payload.Add(GameboardLogVariables.ACTION_NAME, action.Name);
        _payload.Add(GameboardLogVariables.ACTION_INFO,
            action.IsAttackAction ? action.AttackStage : action.DefenseType);
        _payload.Add(GameboardLogVariables.ACTION_IS_ATTACK, action.IsAttackAction);

        return this;
    }

    public LogEntryPayloadConfigurator SetInfo2(BaseActionModel action)
    {
        _payload.Add(GameboardLogVariables.ACTION2_ID, action.Id);
        _payload.Add(GameboardLogVariables.ACTION2_NAME, action.Name);
        _payload.Add(GameboardLogVariables.ACTION2_INFO,
            action.IsAttackAction ? action.AttackStage.ToClientString() : action.Template.DefenseType.ToClientString());
        _payload.Add(GameboardLogVariables.ACTION2_IS_ATTACK, action.IsAttackAction);

        return this;
    }

    public LogEntryPayloadConfigurator SetInfo(EquipmentModel equipment)
    {
        _payload.Add(GameboardLogVariables.EQUIPMENT_ID, equipment.Id);
        _payload.Add(GameboardLogVariables.EQUIPMENT_NAME, equipment.Template.Name);
        _payload.Add(GameboardLogVariables.EQUIPMENT_TYPE, equipment.Template.EquipmentType);

        return this;
    }

    public LogEntryPayloadConfigurator SetInfo(EffectModel effect)
    {
        _payload.Add(GameboardLogVariables.EFFECT_ID, effect.Id);
        _payload.Add(GameboardLogVariables.EFFECT_NAME, effect.Template.Name);
        _payload.Add(GameboardLogVariables.EFFECT_TYPE, effect.Template.Type);

        return this;
    }

    public LogEntryPayloadConfigurator SetInfo(ActorModel actor)
    {
        _payload.Add(GameboardLogVariables.ACTOR_ID, actor.Id);
        _payload.Add(GameboardLogVariables.ACTOR_NAME, actor.Name);
        _payload.Add(GameboardLogVariables.ACTOR_TYPE, actor.Type);

        return this;
    }

    public LogEntryPayloadConfigurator SetCredits(decimal credits)
    {
        _payload.Add(GameboardLogVariables.CREDITS, credits);

        return this;
    }

    public LogEntryPayloadConfigurator SetInitiative(int initiative)
    {
        _payload.Add(GameboardLogVariables.INITIATIVE, initiative);

        return this;
    }

    public LogEntryPayloadConfigurator SetDamage(int damage, char damageType)
    {
        _payload.Add(GameboardLogVariables.DAMAGE, damage);
        _payload.Add(GameboardLogVariables.DAMAGE_TYPE, damageType);

        return this;
    }

    public LogEntryPayloadConfigurator SetAttackStage(AttackStages attackStage)
    {
        _payload.Add(GameboardLogVariables.ATTACK_STAGE, attackStage.ToClientString());

        return this;
    }

    public LogEntryPayloadConfigurator SetExposedInfo(AssetModel asset)
    {
        _payload.Add(GameboardLogVariables.EXPOSED_ASSET_ID, asset.Id);
        _payload.Add(GameboardLogVariables.EXPOSED_ASSET_NAME, asset.Template.Name);
        _payload.Add(GameboardLogVariables.EXPOSED_ASSET_TYPE, asset.Template.Category);

        return this;
    }
}

public static class LogEntryTextMapperExtensions
{
    public static string ToClientString(this DefenseActionType defenseActionType)
    {
        return defenseActionType switch
        {
            DefenseActionType.Detection => "Detection",
            DefenseActionType.Prevention => "Prevention",
            DefenseActionType.Response => "Response",
            _ => defenseActionType.ToString(),
        };
    }

    public static string ToClientString(this AttackStages attackStage)
    {
        return attackStage switch
        {
            AttackStages.Reconnaissance => "Reconnaissance",
            AttackStages.InitialAccess => "Initial Access",
            AttackStages.Execution => "Execution",
            _ => attackStage.ToString(),
        };
    }
}

public class LogEntry(long id, int slotId, GameboardLogMessageType type, Dictionary<string, object> payload)
{
    public long Id { get; } = id;
    public DateTimeOffset Created { get; } = DateTimeOffset.UtcNow;
    public int SlotId { get; } = slotId;
    public GameboardLogMessageType Type { get; } = type;
    public Dictionary<string, object> Payload { get; } = payload;
}