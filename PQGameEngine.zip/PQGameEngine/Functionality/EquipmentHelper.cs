using PQGameEngine.Enums;
using PQGameEngine.Exceptions;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Templates;

namespace PQGameEngine.Functionality;

public static class EquipmentHelper
{
    public static List<Guid> CreateShopSelection(GameInstance game, ActorModel forActor)
    {
        List<EquipmentTemplate> allEquipment;
        if (forActor.IsAttacker)
        {
            allEquipment = game.EquipmentTemplatesAttacker;
        }
        else if (forActor.IsDefender)
        {
            allEquipment = game.EquipmentTemplatesDefender;
        }
        else
        {
            throw new PenQuestException(Errors.ValueErrorFatal, $"Unknown actor type: {forActor.GetType().Name}");
        }

        var alreadyOwnedPermanentEquipment = forActor.Equipment.Select(x => game.Equipment[x])
            .Where(x => x.IsGlobalEquipment()).Select(x => x.Template.Id);
        allEquipment = allEquipment.Where(x => !alreadyOwnedPermanentEquipment.Contains(x.Id)).ToList();

        if (allEquipment.Count == 0 || game.Options.EquipmentShopMode == GameOptionEquipmentShopMode.DISABLED)
        {
            return [];
        }

        List<Guid> selectedEquipment;
        switch (game.Options.EquipmentShopMode)
        {
            case GameOptionEquipmentShopMode.ALL_EQUIPMENT:
                selectedEquipment = allEquipment.Select(x => x.Id).ToList();
                break;
            case GameOptionEquipmentShopMode.RANDOM:
                int k = Math.Min(allEquipment.Count, Constants.GAME_ENGINE_EQUIPMENT_PER_SELECTION);
                var allKeys = allEquipment.Select(x => x.Id).ToArray();
                game.Random.Shuffle(allKeys);
                selectedEquipment = allKeys.Take(k).ToList();
                break;
            default:
                throw new PenQuestException(Errors.ValueErrorFatal,
                    $"Unknown game option for equipment shop mode: {game.Options.EquipmentShopMode}");
        }

        return selectedEquipment;
    }

    public static void ActivatePermanentEquipment(GameInstance game, EquipmentModel eq, out bool effectActivated)
    {
        effectActivated = false;

        if (!eq.IsPermanentEquipment()) return;

        eq.Activate();


        foreach (var effecId in eq.Effects)
        {
            var effect = game.Effects[effecId];
            effect.Activate();
            effectActivated = true;
        }
    }

    public static void DeactivatePermanentEquipment(GameInstance game, EquipmentModel eq)
    {
        if (!eq.IsPermanentEquipment()) return;

        eq.Deactivate();


        foreach (var effectId in eq.Effects)
        {
            var effect = game.Effects[effectId];
            effect.Deactivate();
        }
    }

    public static void ActivatePermanentEquipmentOnAsset(GameInstance game, GameEngineDependencies geDeps,
        EquipmentModel equipment, ActorModel actor, AssetModel? asset, out bool effectActivated)
    {
        effectActivated = false;

        if (!equipment.IsPermanentEquipment() || asset == null) return;

        if (!IsEquipmentApplicable(equipment, actor, asset, asset)) return;

        asset.InfluencedByEquipment.Add(equipment.Id);
        equipment.EquiptOn = asset;
        ActivatePermanentEquipment(game, equipment, out effectActivated);
        geDeps.Logger.LogDebug("Installed permanent equipment {Equipment} on {Target}", equipment, asset);
    }

    public static bool IsEquipmentApplicable(EquipmentModel equipment, ActorModel? actor, IEquipmentApplicable? target,
        AssetModel? asset)
    {
        if (target == null)
        {
            return false;
        }

        if (target.InfluencedByEquipment.Contains(equipment.Id))
        {
            return false;
        }

        if (asset != null)
        {
            if (!equipment.PossibleAssetCategories.Contains(asset.Template.Category))
            {
                return false;
            }

            if (!equipment.PossibleOses.Contains(asset.Template.Os))
            {
                return false;
            }

            if (!equipment.PossibleAttackStages.Contains(asset.CurrentAttackStage))
            {
                return false;
            }
        }

        if (actor != null)
        {
            if (equipment.Scope == EquipmentScopes.Own)
            {
                if (equipment.OwnerId != actor.Id)
                {
                    return false;
                }
            }
            else if (equipment.Scope == EquipmentScopes.NotOwn)
            {
                if (equipment.OwnerId == actor.Id)
                {
                    return false;
                }
            }
            else if (equipment.Scope == EquipmentScopes.Attackers)
            {
                if (!(actor.IsAttacker))
                {
                    return false;
                }
            }
            else if (equipment.Scope == EquipmentScopes.Defenders)
            {
                if (!(actor.IsDefender))
                {
                    return false;
                }
            }
            else if (equipment.Scope == EquipmentScopes.All)
            {
            }
            else
            {
                throw new PenQuestFatalException(
                    $"Invalid equipment scope {equipment.Scope} on equipment template with id {equipment.Template.Id}");
            }
        }

        return true;
    }
}