using PQGameEngine.Enums;
using PQGameEngine.Templates;

namespace PQGameEngine.Functionality;

public static class ScenarioHelper
{
    public static void Sanitize(ScenarioTemplate scenTemplate, ILogger logger)
    {
        SanitizeGrantEquipmentEffects(scenTemplate, logger);
    }

    private static void SanitizeGrantEquipmentEffects(ScenarioTemplate scenTemplate, ILogger logger)
    {
        foreach (var effect in scenTemplate.EffectTemplates.Values)
        {
            if (effect.Type == EffectTypes.GRANT_EQUIPMENT)
            {
                var notExistingEquipment = new HashSet<Guid>();
                foreach (var equipmentInfo in effect.GrantEquipment)
                {
                    if (!scenTemplate.EquipmentTemplates.ContainsKey(equipmentInfo.EquipmentId))
                    {
                        notExistingEquipment.Add(equipmentInfo.EquipmentId);
                    }
                }

                if (notExistingEquipment.Count > 0)
                {
                    effect.GrantEquipment.RemoveAll(x => notExistingEquipment.Contains(x.EquipmentId));
                    var actionsContainingEffect = scenTemplate.ActionTemplates.Values
                        .Where(x => x.Effects.Contains(effect.Id)).ToList();
                    foreach (var action in actionsContainingEffect)
                    {
                        logger.LogWarning(
                            "Grant Equipment effect on action '{ActionName}'({ActionId}) should grant not existing equipment with ids {EquipmentIds}",
                            action.Name, action.Id, notExistingEquipment);
                    }
                }
            }
        }
    }
}