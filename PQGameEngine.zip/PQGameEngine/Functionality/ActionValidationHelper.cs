using PQGameEngine.Enums;
using PQGameEngine.Exceptions;
using PQGameEngine.GameEventMessages.Inbound;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.GameEvents;
using PQGameEngine.Models.Internal;

namespace PQGameEngine.Functionality;

public static class ActionValidationHelper
{
    public static ValidatedAction GetValidateAction(PlayActionEvent cmd, GameInstance game, ActorModel actor)
    {
        if (!game.Actions.TryGetValue(cmd.MainActionId, out var baseAction) || !baseAction.IsMainAction ||
            baseAction is not MainActionModel mainActionModel)
            throw new PenQuestException(Errors.ActionNotFoundError, "Invalid action id");

        var validatedAction = new ValidatedAction(mainActionModel);

        if (cmd.TargetId != null)
        {
            if (!game.Assets.TryGetValue(cmd.TargetId.Value, out var asset))
                throw new PenQuestException(Errors.AssetNotFoundOrVisibleError, "Invalid asset");
            if (!actor.VisibleAssets.Contains(cmd.TargetId.Value))
                throw new PenQuestException(Errors.AssetNotFoundOrVisibleError, "Invalid asset");

            validatedAction.Targets.Add(asset);
        }

        if (cmd.SupportActionIds != null)
        {
            foreach (var t in cmd.SupportActionIds)
            {
                if (!game.Actions.TryGetValue(t, out var supAct) || !supAct.IsSupportAction ||
                    supAct is not SupportActionModel supportActionModel)
                    throw new PenQuestException(Errors.ActionNotFoundError, "Invalid support action id");
                validatedAction.SupportActions.Add(supportActionModel);
            }
        }

        if (cmd.EquipmentIds != null)
        {
            foreach (var t in cmd.EquipmentIds)
            {
                if (!game.Equipment.TryGetValue(t, out var eq))
                    throw new PenQuestException(Errors.EquipmentNotFoundError, "Invalid equipment id");
                validatedAction.Equipment.Add(eq);
            }
        }

        validatedAction.AttackMask = mainActionModel.HasPredefinedAttackMask()
            ? mainActionModel.PredefinedAttackMask
            : (cmd.AttackMask ?? "");

        validatedAction.ResponseTargetId = cmd.ResponseTargetId ?? 0;

        if (mainActionModel.TargetType == TargetTypes.Untargeted)
        {
            validatedAction.Targets.Clear();
        }
        else if (mainActionModel.TargetType == TargetTypes.Single)
        {
        }
        else if (mainActionModel.TargetType == TargetTypes.Multi)
        {
            validatedAction.Targets.Clear();
            validatedAction.Targets.AddRange(GetTargetAssets(game, actor, mainActionModel,
                validatedAction.AttackMask));
        }
        else
        {
            throw new ArgumentException($"Invalid action target type {mainActionModel.TargetType}");
        }

        IsCombinationPlayable(game, actor, validatedAction);

        if (!GamePhaseHelper.HasActorDrawnActions(game, actor))
        {
            validatedAction.Errors.Add(
                new PenQuestErrorInfo(Errors.MissingActionError, "Actor needs to redraw actions"));
        }

        if (game.TurnTrackers[actor.Id].RemainingActionPoints - validatedAction.GetTotalActionPointCost() <
            ActorHelper.GetMinApValue(actor))
        {
            validatedAction.Errors.Add(
                new PenQuestErrorInfo(Errors.InsufficientActionPointsError, "Insufficient action points"));
        }

        return validatedAction;
    }

    private static List<AssetModel> GetTargetAssets(GameInstance game, ActorModel actor, MainActionModel action,
        string? attackMask)
    {
        var targets = new List<AssetModel>();


        var isRevealAction = action.Effects.Any(x => game.Effects[x].Template.Type == EffectTypes.REVEAL_ASSET);

        foreach (var asset in game.Assets.Values)
        {
            if (isRevealAction || actor.VisibleAssets.Contains(asset.Id))
            {
                if (attackMask != null)
                {
                    if (action.AssetCategories.Contains(asset.Template.Category) &&
                        action.Oses.Contains(asset.Template.Os) && action.AttackStage <= asset.CurrentAttackStage)
                    {
                        if (actor.IsDefender)
                        {
                            targets.Add(asset);
                        }
                        else if (actor.IsAttacker)
                        {
                            if ((asset.CurrentExposedState.C && attackMask.IndexOf('C') >= 0 &&
                                 asset.CurrentExposedState.C)
                                || (asset.CurrentExposedState.I && attackMask.IndexOf('I') >= 0 &&
                                    asset.CurrentExposedState.I)
                                || (asset.CurrentExposedState.A && attackMask.IndexOf('A') >= 0 &&
                                    asset.CurrentExposedState.A))
                            {
                                if (!asset.IsOffline)
                                {
                                    targets.Add(asset);
                                }
                            }
                        }
                    }
                }
            }
        }

        return targets;
    }

    private static void IsCombinationPlayable(GameInstance game, ActorModel actor, ValidatedAction validatedAction)
    {
        if (!Constants.ValidAttackMasks.Contains(validatedAction.AttackMask))
        {
            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.InvalidAttackMaskError,
                $"Invalid attack mask '{validatedAction.AttackMask}'"));
        }

        if (!validatedAction.MainAction.HasPredefinedAttackMask() && validatedAction.AttackMask.Length > 1)
        {
            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.InvalidAttackMaskError,
                $"Invalid attack mask '{validatedAction.AttackMask}' - don't try to cheat me"));
        }

        if (validatedAction.MainAction.TargetType == TargetTypes.Single)
        {
            if (validatedAction.Targets.Count < 1)
            {
                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.MissingAssetError,
                    $"Missing target asset for action '{validatedAction.MainAction.Name}' [{validatedAction.MainAction.Id}]"));
            }
            else if (validatedAction.Targets.Count > 1)
            {
                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.TooManyAssetsSelectedError,
                    $"Too many assets selected. Action '{validatedAction.MainAction.Name}' [{validatedAction.MainAction.Id}] is a single target action"));
            }
        }

        CombinationChecks(validatedAction);
        GameStateChecks(game, actor, validatedAction);
        RequirementChecks(game, actor, validatedAction);
        RoleChecks(actor, validatedAction);
        AssetChecks(game, actor, validatedAction);
        CheckEffectValidity(game, actor, validatedAction);
    }

    public static void CombinationChecks(ValidatedAction validatedAction)
    {
        if (!validatedAction.MainAction.IsMainAction)
        {
            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.NotAMainActionError,
                $"Action {validatedAction.MainAction.Name}({validatedAction.MainAction.TemplateId}) is not a main action"));
        }

        foreach (var supportAction in validatedAction.SupportActions)
        {
            if (!supportAction.IsSupportAction)
            {
                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.NotASupportActionError,
                    $"Action {supportAction.Name}({supportAction.TemplateId}) is not a support action"));
            }

            if (supportAction.ValidMainActions.Count > 0 &&
                !supportAction.ValidMainActions.Contains(validatedAction.MainAction.TemplateId))
            {
                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.SupportActionMainActionMismatchError,
                    $"Support action {supportAction.Name}({supportAction.TemplateId}) is incompatible with main action {validatedAction.MainAction.Name}({validatedAction.MainAction.TemplateId})"));
            }
        }

        foreach (var eq in validatedAction.Equipment)
        {
            if (eq.IsSingleUseEquipment() && validatedAction.MainAction.TargetType == TargetTypes.Multi)
            {
                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.NoSingleUseEquipmentOnMultitargetAction,
                    $"Single Use equipment ({eq.Name} ({eq.TemplateId})) cannot be appended to a multi target action."));
            }

            if (eq.IsGlobalEquipment() && eq.IsPermanentEquipment())
            {
                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.WrongEquipmentType,
                    $"Global equipment ({eq.Name} ({eq.TemplateId})) cannot be appended to an action."));
            }

            if (eq.IsGlobalEquipment() && eq.IsSingleUseEquipment() && eq.UsedOn != null)
            {
                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.EquipmentAlreadyUsed,
                    $"Equipment {eq.Name} was already used."));
            }

            if (eq.IsLocalEquipment() && eq.PlayedWithAction.HasValue)
            {
                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.EquipmentAlreadyUsed,
                    $"Local equipment {eq.Name} was already played."));
            }

            if (eq.PossibleActions.Count > 0 && !eq.PossibleActions.Contains(validatedAction.MainAction.TemplateId))
            {
                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.EquipmentMainActionMismatchError,
                    $"Equipment {eq.Name} cannot be played along with main action {validatedAction.MainAction.Name}"));
            }
        }

        if (validatedAction.MainAction.IsAttackAction)
        {
            foreach (var supportAction in validatedAction.SupportActions)
            {
                if (!supportAction.IsAttackAction)
                {
                    validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.SupportActionMainActionMismatchError,
                        "Attack/defense mode of main action (attack) is incompatible with attack/defense mode of support action (defense)"));
                }
            }

            foreach (var eq in validatedAction.Equipment)
            {
                if (!eq.IsAttackEquipment)
                {
                    validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.EquipmentMainActionMismatchError,
                        "Attack/defense mode of main action (attack) is incompatible with attack/defense mode of equipment (defense)"));
                }
            }
        }
        else if (validatedAction.MainAction.IsDefenseAction)
        {
            foreach (var supportAction in validatedAction.SupportActions)
            {
                if (!supportAction.IsDefenseAction)
                {
                    validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.SupportActionMainActionMismatchError,
                        "Attack/defense mode of main action (defense) is incompatible with attack/defense mode of support action (attack)"));
                }
            }

            foreach (var eq in validatedAction.Equipment)
            {
                if (!eq.IsDefenseEquipment)
                {
                    validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.EquipmentMainActionMismatchError,
                        "Attack/defense mode of main action (defense) is incompatible with attack/defense mode of equipment (attack)"));
                }
            }
        }
    }

    public static void GameStateChecks(GameInstance game, ActorModel actor, ValidatedAction validatedAction)
    {
        GamePhase[] expectedGamePhases;
        if (actor.IsAttacker)
        {
            expectedGamePhases = [GamePhase.Attack];
        }
        else if (actor.IsDefender)
        {
            expectedGamePhases = [GamePhase.Defense, GamePhase.DefenderPreSetup];
        }
        else
        {
            throw new PenQuestException(Errors.UnknownActorError,
                $"Actor {actor} is of unknown type {actor.GetType()}");
        }

        if (game.Phase.NotIn(expectedGamePhases))
        {
            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.GamePhaseMismatchError,
                $"Game phase {string.Join(" or ", expectedGamePhases)} is required for you to perform an action. Current game phase is {game.Phase}"));
        }

        if (validatedAction.MainAction.ActionEvents.Count > 0)
        {
            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.ActionAlreadyPlayedError,
                $"Action {validatedAction.MainAction.Id} {validatedAction.MainAction.Name} was already played"));
        }

        if (game.TurnTrackers[actor.Id].HasFinishedItsTurn())
        {
            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.ActorPhaseAlreadyCompletedError,
                $"Actor {actor} has already met the limit of actions per turn"));
        }

        foreach (var supportAction in validatedAction.SupportActions)
        {
            if (!actor.Actions.Contains(supportAction.Id))
            {
                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.ActionNotInPossessionError,
                    $"Action {supportAction} is not in your possession"));
            }

            if (supportAction.Used)
            {
                validatedAction.Errors.Add(
                    new PenQuestErrorInfo(Errors.ActionAlreadyPlayedError,
                        $"Action {supportAction} was already played"));
            }
        }

        foreach (var eq in validatedAction.Equipment)
        {
            if (!actor.Equipment.Contains(eq.Id))
            {
                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.EquipmentNotInPossessionError,
                    $"Equipment {eq} is not in possession of you."));
            }
        }

        if (!actor.Actions.Contains(validatedAction.MainAction.Id))
        {
            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.ActionNotInPossessionError,
                $"Action {validatedAction.MainAction} is not in your possession"));
        }
    }

    public static void RequirementChecks(GameInstance game, ActorModel actor, ValidatedAction validatedAction)
    {
        if (game.Options.EquipmentShopMode != GameOptionEquipmentShopMode.DISABLED)
        {
            var reqEqIds = new List<Guid>(validatedAction.MainAction.Template.RequiredEquipment);
            foreach (var sa in validatedAction.SupportActions)
            {
                reqEqIds.AddRange(sa.Template.RequiredEquipment);
            }

            if (reqEqIds.Count > 0)
            {
                var found = false;

                foreach (var reqEqId in reqEqIds)
                {
                    if (game.EquipmentTemplates.TryGetValue(reqEqId, out var ret))
                    {
                        if (ret.IsPassiveEquipment())
                        {
                            found = found || actor.Equipment.Select(x => game.Equipment[x])
                                .Any(x => x.Template.Id == ret.Id);
                        }
                        else
                        {
                            found = found || validatedAction.Equipment.Any(x => x.Template.Id == ret.Id);
                        }

                        if (found)
                        {
                            break;
                        }
                    }
                }

                if (!found)
                {
                    validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.ActionRequiredEquipmentMissing,
                        $"Requires at least one of the following equipment items to be active (in inventory) " +
                        $"or to be played with the action: {(string.Join(", ", reqEqIds.Where(x => game.EquipmentTemplates.ContainsKey(x)).Select(x => game.EquipmentTemplates[x].Name)))}"));
                }
            }
        }
    }

    public static void RoleChecks(ActorModel actor, ValidatedAction validatedAction)
    {
        if (validatedAction.MainAction.IsAttackAction && !actor.IsAttacker)
        {
            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.ActionActorMismatchError,
                $"Action {validatedAction.MainAction} is an attack action but actor {actor} is not an attacker"));
        }

        if (validatedAction.MainAction.IsDefenseAction && !actor.IsDefender)
        {
            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.ActionActorMismatchError,
                $"Action {validatedAction.MainAction} is a defense action but actor {actor} is not a defender"));
        }

        if (validatedAction.MainAction.CurrentSophReq > actor.CurrentSoph)
        {
            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.MissingSophError,
                $"Actor {actor.Id} {actor.Name} requires {validatedAction.MainAction.CurrentSophReq} sophistication but only has {actor.CurrentSoph}"));
        }

        foreach (var supportAction in validatedAction.SupportActions)
        {
            if (supportAction.CurrentSophReq > actor.CurrentSoph)
            {
                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.MissingSophError,
                    $"Actor {actor.Id} {actor.Name} requires {supportAction.CurrentSophReq} sophistication but only has {actor.CurrentSoph}"));
            }
        }
    }

    private static void AssetChecks(GameInstance game, ActorModel actor, ValidatedAction validatedAction)
    {
        foreach (var asset in validatedAction.Targets)
        {
            CheckActionAssetValidity(validatedAction, validatedAction.MainAction, asset);

            if (validatedAction.MainAction.IsAttackAction)
            {
                if (asset.IsOffline)
                {
                    validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.AssetOfflineError,
                        $"Asset {asset.Id} {asset.Template.Name} is currently not reachable / offline"));
                }

                if (!IsAttackVectorAtLeastPartiallyAvailable(validatedAction.AttackMask, asset))
                {
                    validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.AssetNotExposedError,
                        $"Asset {asset.Id} {asset.Template.Name} is not exposed at attack mask {validatedAction.AttackMask}"));
                }
            }
            else if (validatedAction.MainAction.IsDefenseAction)
            {
                if (validatedAction.MainAction.CurrentImpact.Any(x => x < 0))
                {
                    if (validatedAction.ResponseTargetId != 0)
                    {
                        if (!asset.PlayedActionEvents.Any(eventId =>
                                game.Events[eventId] is ActionEvent ae &&
                                ae.MainAction.Id == validatedAction.ResponseTargetId))
                        {
                            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.InvalidResponseTarget,
                                $"Target {validatedAction.ResponseTargetId} does not correspond to a valid played action on asset {asset}"));
                        }

                        var actionEvent = asset.PlayedActionEvents
                            .Select(eventId => game.Events[eventId] as ActionEvent)
                            .FirstOrDefault(actionEvent =>
                                actionEvent?.MainAction.Id == validatedAction.ResponseTargetId);
                        if (actionEvent != null)
                        {
                            if (actionEvent.Succeeded == false)
                            {
                                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.InvalidResponseTarget,
                                    $"Target {validatedAction.ResponseTargetId} corresponds to an unsuccessful action on asset {asset}"));
                            }

                            if (!actionEvent.Detected.ContainsKey(actor.Id))
                            {
                                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.InvalidResponseTarget,
                                    $"Target {validatedAction.ResponseTargetId} does not correspond to a valid played action on asset {asset} (b1)"));
                            }

                            if (!validatedAction.MainAction.Template.AffectedAttackActions.Contains(actionEvent
                                    .MainAction.TemplateId) &&
                                !validatedAction.MainAction.Template.AffectedDefenseActions.Contains(actionEvent
                                    .MainAction.TemplateId))
                            {
                                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.InvalidResponseTarget,
                                    $"Target {validatedAction.ResponseTargetId} does not correspond to a valid played action on asset {asset} (b2)"));
                            }

                            if (actionEvent.AttackMaskUsed == null!)
                            {
                                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.InvalidResponseTarget,
                                    $"Target {validatedAction.ResponseTargetId} does not correspond to a valid played action on asset {asset} (b3)"));
                            }

                            if (actionEvent is AssetActionEvent aae && !aae.IsCurrentlyCounterable(game))
                            {
                                validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.InvalidResponseTarget,
                                    $"Target {validatedAction.ResponseTargetId} does not correspond to a valid played action on asset {asset} (b4)"));
                            }
                        }
                        else
                        {
                            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.IndexErrorFatal,
                                $"Asset {asset.Template.Name}({asset.Id}) does not have a played action {validatedAction.ResponseTargetId}"));
                        }
                    }
                }
            }

            foreach (var supportAction in validatedAction.SupportActions)
            {
                CheckActionAssetValidity(validatedAction, supportAction, asset);
            }
        }
    }

    public static bool IsAttackVectorAtLeastPartiallyAvailable(string usedAttackMask, AssetModel asset)
    {
        return "CIA".Any(c => usedAttackMask.Contains(c) && asset.CurrentExposedState.IsExposed(c));
    }

    private static void CheckActionAssetValidity(ValidatedAction validatedAction, BaseActionModel action,
        AssetModel asset)
    {
        if (!action.Oses.Contains(asset.Template.Os))
        {
            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.OsMismatchError,
                $"Action not playable on OS {asset.Template.Os}"));
        }

        if (!action.AssetCategories.Contains(asset.Template.Category))
        {
            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.ActionAssetMismatchError,
                $"Action not playable on asset {asset.Template.Category}"));
        }

        if (asset.CurrentAttackStage < action.AttackStage)
        {
            validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.AttackStageMismatchError,
                $"Action not playable on attack stage {asset.CurrentAttackStage}"));
        }

        if (action.Template.RequireAdmin && !asset.AdminAccessEnabled)
        {
            validatedAction.Errors.Add(
                new PenQuestErrorInfo(Errors.AdminModeRequired, $"Action requires admin access"));
        }
    }

    public static void CheckEffectValidity(GameInstance game, ActorModel actor,
        ValidatedAction validatedAction)
    {
        var effects = new List<int>(validatedAction.MainAction.Effects);
        effects.AddRange(validatedAction.SupportActions.SelectMany(sa => sa.TransferEffects));
        effects.AddRange(validatedAction.Equipment.SelectMany(eq => eq.TransferEffects));

        foreach (var effectId in effects)
        {
            var effect = game.Effects[effectId];
            if (effect.Template.Type == EffectTypes.MODIFY_ACTOR && effect.Template.Credits.HasValue)
            {
                if (validatedAction.MainAction.TargetType == TargetTypes.Single ||
                    validatedAction.MainAction.TargetType == TargetTypes.Untargeted)
                {
                    if (actor.CurrentCredits + effect.Template.Credits.Value < 0)
                    {
                        validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.NotEnoughCreditsError,
                            "Not enough credits to play action"));
                    }
                }
                else if (validatedAction.MainAction.TargetType == TargetTypes.Multi)
                {
                    if (actor.CurrentCredits + effect.Template.Credits.Value * validatedAction.Targets.Count < 0)
                    {
                        validatedAction.Errors.Add(new PenQuestErrorInfo(Errors.NotEnoughCreditsError,
                            "Not enough credits to play action"));
                    }
                }
            }
        }
    }
}