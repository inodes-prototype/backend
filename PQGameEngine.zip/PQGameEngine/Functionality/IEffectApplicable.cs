﻿using PQGameEngine.Models.Game;

namespace PQGameEngine.Functionality;

public interface IEffectApplicable
{
    HashSet<AppliedEffectSource> AppliedEffects { get; }

    int GetOwnerId();
}

public record struct AppliedEffectSource(char SourceType, Guid SourceId, int EffectId)
{
    public static AppliedEffectSource FromEquipment(Guid id, int effectId) => new('E', id, effectId);
    public static AppliedEffectSource FromAction(Guid id, int effectId) => new('A', id, effectId);
    public static AppliedEffectSource FromOther(Guid id, int effectId) => new('O', id, effectId);
}

public static class EffectApplicableExtensions
{
    public static void SetEffectApplied(this IEffectApplicable target, EffectModel effect)
    {
        if (effect.ActionTemplateSourceId.HasValue)
        {
            target.AppliedEffects.Add(AppliedEffectSource.FromAction(effect.ActionTemplateSourceId.Value,
                effect.Template.Id));
        }

        if (effect.EquipmentTemplateSourceId.HasValue)
        {
            target.AppliedEffects.Add(AppliedEffectSource.FromEquipment(effect.EquipmentTemplateSourceId.Value,
                effect.Template.Id));
        }
    }

    public static bool WasEffectAlreadyApplied(this IEffectApplicable target, EffectModel effect)
    {
        if (target != null! && effect.ActionTemplateSourceId.HasValue &&
            target.AppliedEffects.Contains(AppliedEffectSource.FromAction(effect.ActionTemplateSourceId.Value,
                effect.Template.Id)))
            return true;

        if (target != null && effect.EquipmentTemplateSourceId.HasValue &&
            target.AppliedEffects.Contains(
                AppliedEffectSource.FromEquipment(effect.EquipmentTemplateSourceId.Value, effect.Template.Id)))
            return true;

        return false;
    }
}