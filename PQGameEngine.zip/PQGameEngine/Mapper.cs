﻿using PQGameEngine.Enums;

namespace PQGameEngine;

public static class Mapper
{
    public static AttackStages Map(GameOptionInitialAssetStage initialAssetStage)
    {
        switch (initialAssetStage)
        {
            case GameOptionInitialAssetStage.RECONNAISSANCE: return AttackStages.Reconnaissance;
            case GameOptionInitialAssetStage.INITIAL_ACCESS: return AttackStages.InitialAccess;
            case GameOptionInitialAssetStage.EXECUTION: return AttackStages.Execution;
            default: throw new ArgumentException($"Invalid initialAssetStage {initialAssetStage}");
        }
    }

    public static DefenseActionType Map(GameOptionManualDefType manualDefTypeMode)
    {
        switch (manualDefTypeMode)
        {
            case GameOptionManualDefType.DETECTION: return DefenseActionType.Detection;
            case GameOptionManualDefType.RESPONSE: return DefenseActionType.Response;
            case GameOptionManualDefType.PREVENTION: return DefenseActionType.Prevention;
            default: throw new ArgumentException($"Invalid manualDefTypeMode {manualDefTypeMode}");
        }
    }
}