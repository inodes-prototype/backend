﻿using PQGameEngine.Models.Game;
using PQGameEngine.Templates;

namespace PQGameEngine;

public static class EquipmentExtensions
{
    public static bool IsPermanentEquipment(this EquipmentTemplate equipment) =>
        EquipmentModel.IsTemplatePermanentEquipment(equipment);

    public static bool IsPermanentEquipment(this EquipmentModel equipment) => equipment.Template.IsPermanentEquipment();

    public static bool IsSingleUseEquipment(this EquipmentTemplate equipment) =>
        EquipmentModel.IsTemplateSingleUseEquipment(equipment);

    public static bool IsSingleUseEquipment(this EquipmentModel equipment) => equipment.Template.IsSingleUseEquipment();

    public static bool IsGlobalEquipment(this EquipmentTemplate equipment) =>
        EquipmentModel.IsTemplateGlobalEquipment(equipment);

    public static bool IsGlobalEquipment(this EquipmentModel equipment) => equipment.Template.IsGlobalEquipment();

    public static bool IsLocalEquipment(this EquipmentTemplate equipment) =>
        EquipmentModel.IsTemplateLocalEquipment(equipment);

    public static bool IsLocalEquipment(this EquipmentModel equipment) => equipment.Template.IsLocalEquipment();

    public static bool IsPassiveEquipment(this EquipmentTemplate equipment) =>
        EquipmentModel.IsTemplatePassiveEquipment(equipment);

    public static bool IsPassiveEquipment(this EquipmentModel equipment) => equipment.Template.IsPassiveEquipment();
}