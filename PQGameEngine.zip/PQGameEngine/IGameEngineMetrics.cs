namespace PQGameEngine;

public interface IGameEngineMetrics
{
    void IncreaseRunningGameCounter();
    void DecreaseRunningGameCounter();
}