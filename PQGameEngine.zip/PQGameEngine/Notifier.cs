﻿using PQGameEngine.Commands;
using PQGameEngine.Enums;
using PQGameEngine.Exceptions;
using PQGameEngine.Factories;
using PQGameEngine.Functionality.GameboardLog;
using PQGameEngine.GameEventMessages.MessageModels;
using PQGameEngine.GameEventMessages.Outbound;
using PQGameEngine.Instances;
using PQGameEngine.Models.Game;
using PQGameEngine.Models.Internal;
using PQGameEngine.Templates;

namespace PQGameEngine;

public class Notifier(INotifyService notifyService)
{
    private void SendNotification(string connectionId, Guid userId, string eventName, IOutboundGameEventMessage message,
        long? requestId)
    {
        if (string.IsNullOrWhiteSpace(connectionId)) return;

        notifyService.Notify(connectionId, userId, new WrappedOutboundMessage(eventName, message, requestId));
    }

    private void SendNotification(string connectionId, Guid userId, string command, IOutboundBotEventMessage message)
    {
        notifyService.NotifyBot(connectionId, userId, new WrappedBotOutboundMessage(command, message));
    }

    public void ReportErrors(AbstractCommand ac, PenQuestBaseException e)
    {
        ErrorMessage error;

        if (e is PenQuestException pqe)
        {
            error = new ErrorMessage()
            {
                MultipleErrors = true,
                ErrorIds = [(int)pqe.Code],
                ErrorMessages = [e.Message]
            };
        }
        else if (e is PenQuestAggregateException pqa)
        {
            error = new ErrorMessage()
            {
                MultipleErrors = true,
                ErrorIds = pqa.ErrorInfos.Select(x => (int)x.Code).ToList(),
                ErrorMessages = pqa.ErrorInfos.Select(x => x.Message).ToList()
            };
        }
        else
        {
            error = new ErrorMessage()
            {
                MultipleErrors = true,
                ErrorIds = [999999],
                ErrorMessages = [e.Message]
            };
        }

        notifyService.Notify(ac.ConnectionId, ac.UserId,
            new WrappedOutboundMessage(Constants.GAME_EVENT_NAME_ERROR, error, ac.RequestId));
    }

    public void SendInfo(ActorModel receiver, InfoType type, string message)
    {
        notifyService.Notify(receiver.ConnectionId, receiver.UserId,
            new WrappedOutboundMessage(Constants.GAME_EVENT_NAME_INFO,
                new InfoMessage() { Type = type, Message = message }, null));
    }

    public void ReportCrash(string connectionId, Guid userId, Errors code, string message)
    {
        SendNotification(connectionId, userId, Constants.GAME_EVENT_NAME_GAME_CRASHED,
            new ServerCrashMessage() { Reason = message, Code = (int)code }, null);
    }

    public void GameboardLogUpdated(ActorModel actor, GameInstance game, List<LogEntry> logEntries)
    {
        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_LOG_UPDATE,
            new GameboardLogUpdateMessage()
            {
                Events = GameboardLogEventViewFactory.Create(actor, game, logEntries),
            }, null);
    }

    public void ActionsDetected(ActorModel actor, GameInstance game, List<MainActionModel> actions)
    {
        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_ACTIONS_DETECTED,
            new ActionsDetectedMessage()
            {
                Actions = actions.Select(x => ActionViewFactory.Create(actor, game, game.Turn, x)).ToList()
            }, null);
    }

    public void ActionsReceived(ActorModel actor, IReadOnlyCollection<BaseActionModel> newActions, GameInstance game,
        long requestId)
    {
        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_ACTIONS_RECEIVED,
            new ActionsReceivedMessage()
            {
                Actions = newActions.Select(x => ActionViewFactory.Create(actor, game, null, x)).ToList()
            }, requestId);
    }

    public void ActionPlayable(ActorModel actor, GameInstance game, bool playable,
        ValidateActionChanceModel? successChance, ValidateActionChanceModel? detectedChance,
        List<PenQuestErrorInfo> errors, List<PenQuestErrorInfo> warnings, List<int> responseTargetIds,
        List<CounterableInfoRecord> fullCounterInfos)
    {
        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_ACTION_PLAYABLE,
            new ActionPlayableMessage()
            {
                DetectionChance = detectedChance?.Chance ?? 0M,
                IsPlayable = playable,
                ResponseTargetIds = responseTargetIds,
                SuccessChance = successChance?.Chance ?? 1M,
                ResponseTargetInfos = fullCounterInfos.Select(x => new ActionPlayableMessage.ResponseTargetInfoModel()
                {
                    ActionId = x.CounterableActionId,
                    IsExpired = x.Expired,
                }).ToList(),
                Errors = new ErrorMessage()
                {
                    MultipleErrors = true,
                    ErrorIds = errors.Select(x => (int)x.Code).ToList(),
                    ErrorMessages = errors.Select(x => x.Message).ToList()
                },
                Warnings = new ActionPlayableMessage.WarningInfos()
                {
                    NoResponseTargetAvailable = warnings.Any(x => x.Code == Errors.NoResponseTargetAvailable),
                    InvalidAttackMask = errors.Any(x => x.Code == Errors.InvalidAttackMaskError)
                },
                DetectionModifier = detectedChance?.ChanceModifier.Select(x =>
                    new ActionPlayableMessage.ActionChanceModifier()
                    {
                        Bonus = x.chanceModifier,
                        Reason = x.reason,
                        Code = x.code,
                    }).ToList(),
                SuccessModifier = successChance?.ChanceModifier.Select(x =>
                    new ActionPlayableMessage.ActionChanceModifier()
                    {
                        Bonus = x.chanceModifier,
                        Reason = x.reason,
                        Code = x.code,
                    }).ToList(),
            }, null);
    }

    public void GameState(ActorModel actor, GameInstance game, long requestId)
    {
        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_GAME_STATE, new GameStateMessage()
        {
            Game = GameViewFactory.Create(actor, game, game.Turn)
        }, requestId);
    }

    public void GamePlayerChanged(IEnumerable<ActorModel> actors, GameInstance game, ActorModel actor,
        string connectionIdToResume, Guid playerIdToResume)
    {
        foreach (var oneActor in actors)
        {
            SendNotification(oneActor.ConnectionId, oneActor.UserId, Constants.GAME_EVENT_NAME_GAME_PLAYER_CHANGE,
                new GamePlayerChangedMessage()
                {
                    OldConnectionId = connectionIdToResume,
                    OldPlayerId = playerIdToResume,
                    NewConnectionId = actor.ConnectionId,
                    NewPlayerId = actor.UserId,
                    Player = PlayerViewFactory.Create(oneActor, game, actor)
                }, null);
        }
    }

    public void ActionSuccess(ActorModel actor, GameInstance game, ActionSuccessState actionSuccessState,
        MainActionModel action,
        List<bool> result)
    {
        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_ACTION_SUCCESS,
            new ActionSuccessMessage()
            {
                Action = ActionViewFactory.Create(actor, game, game.Turn, action),
                SuccessInfo = result
            }, null);
    }

    public void AssetChanged(IEnumerable<ActorModel> actors, GameInstance game, AssetModel asset)
    {
        foreach (var actor in actors)
        {
            AssetChanged(actor, game, asset);
        }
    }

    public void AssetChanged(ActorModel actor, GameInstance game, AssetModel asset)
    {
        if (game.Phase == GamePhase.DefenderPreSetup && actor.IsAttacker) return;
        if (actor.VisibleAssets.Contains(asset.Id) || actor.KnownAssets.Contains(asset.Id))
        {
            SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_ASSET_CHANGED,
                new AssetChangedMessage()
                {
                    Asset = AssetViewFactory.Create(actor, game, game.Turn, asset, true)
                }, null);
        }
    }

    public void AssetVisibilityChanged(ActorModel actor, GameInstance game, List<int> revealed, List<int> hidden)
    {
        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_ASSET_CHANGES,
            new AssetVisibilityChangedMessage(
                hidden,
                revealed.Select(x => AssetViewFactory.Create(actor, game, game.Turn, game.Assets[x], true)).ToList()
            ), null);
    }

    public void UpdateEquipmentShop(GameInstance game, ActorModel actor, List<EquipmentTemplate> equipmentTemplates)
    {
        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_ASSORTMENT_RECEIVED,
            new UpdateEquipmentShopMessage()
            {
                Equipment = equipmentTemplates.Select(x => EquipmentViewFactory.Create(actor, game, null, x)).ToList()
            }, null);
    }

    public void RemoveCardsFromHand(ActorModel actor, GameInstance game, List<int> actionIds, List<int> equipmentIds)
    {
        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_REMOVE_CARDS,
            new RemoveCardsFromHandMessage()
            {
                ActionIds = actionIds,
                EquipmentIds = equipmentIds,
            }, null);
    }

    public void RemoveEquipmentFromShop(ActorModel actor, GameInstance game, List<Guid> equipmentIds)
    {
        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_REMOVE_EQUIPMENT_FROM_SHOP,
            new RemoveEquipmentFromShopMessage()
            {
                EquipmentIds = equipmentIds,
            }, null);
    }

    public void AttributeChanged(ActorModel actor, ChangedPlayerAttributeType attributeType, decimal newVal)
    {
        var attributeText = attributeType switch
        {
            ChangedPlayerAttributeType.Insight => Constants.ACTOR_ATTRIBUTE_TEXT_INSIGHT,
            ChangedPlayerAttributeType.Credits => Constants.ACTOR_ATTRIBUTE_TEXT_CREDITS,
            ChangedPlayerAttributeType.Initiative => Constants.ACTOR_ATTRIBUTE_TEXT_INITIATIVE,
            ChangedPlayerAttributeType.Skill => Constants.ACTOR_ATTRIBUTE_TEXT_SKILL,
            ChangedPlayerAttributeType.InsightShield => "insightShield",
            _ => throw new ArgumentException("Invalid attribute " + attributeType),
        };

        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_ATTRIBUTE_CHANGED,
            new AttributeChangedMessage()
            {
                AttributeType = attributeType,
                Attribute = attributeText,
                Value = newVal
            }, null);
    }

    public void ActorDetected(ActorModel actor, int detectedActorId)
    {
        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_ACTOR_DETECTED,
            new ActorDetectedMessage()
            {
                ActorId = detectedActorId
            }, null);
    }

    public void EquipmentReceived(ActorModel actor, GameInstance game, List<EquipmentModel> equipmentList)
    {
        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_EQUIPMENT_RECEIVED,
            new EquipmentReceivedMessage()
            {
                Equipment = equipmentList.Select(x => EquipmentViewFactory.Create(actor, game, null, x, false, false))
                    .ToList()
            }, null);
    }

    public void GameEnded(ActorModel actor, GameInstance game, GamePlayerEndState endState, string finishMessage,
        PostGameXpModel xpSummary)
    {
        var postGameSummary = PostGameSummaryFactory.Create(game, actor, endState);

        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_GAME_ENDED, new GameEndedMessage()
        {
            PostGameSummary = postGameSummary,
            XpSummary = xpSummary,
            EndMessage = finishMessage,
            EndState = endState,
        }, null);
    }

    public void GamePhaseChanged(IEnumerable<ActorModel> actors, GamePhase phase)
    {
        foreach (var actor in actors)
        {
            SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_GAMEPHASE_CHANGED,
                new GamePhaseChangedMessage()
                {
                    GamePhase = phase.ToViewText()
                }, null);
        }
    }

    public void TurnChanged(IEnumerable<ActorModel> actors, int currentTurn)
    {
        foreach (var actor in actors)
        {
            SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_GAMETURN_CHANGED,
                new GameTurnChangedMessage()
                {
                    CurrentTurn = currentTurn
                }, null);
        }
    }

    public void GameStarted(IEnumerable<ActorModel> actors, GameInstance game)
    {
        foreach (var actor in actors)
        {
            SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_GAME_STARTED,
                new GameStartedMessage()
                {
                    Game = GameViewFactory.Create(actor, game, game.Turn)
                }, null);
        }
    }

    public void OfferSelection(ActorModel actor, IEnumerable<ActionTemplate> actions, int amountSelection,
        GameInstance game)
    {
        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_OFFER_SELECTION,
            new OfferSelectionMessage()
            {
                Actions = actions.Select(x => ActionViewFactory.Create(actor, game, null, x)).ToList(),
                AmountToSelect = amountSelection
            }, null);
    }

    public void PlayerLeft(IEnumerable<ActorModel> actors, ActorModel actor)
    {
        foreach (var oneActor in actors)
        {
            SendNotification(oneActor.ConnectionId, oneActor.UserId, Constants.GAME_EVENT_NAME_PLAYER_LEFT,
                new PlayerLeftMessage()
                {
                    Player = PlayerViewFactory.Create(oneActor, null!, actor),
                    Slot = actor.Id
                }, null);
        }
    }

    public void UpdatePlayer(IEnumerable<ActorModel> actors, ActorModel actor)
    {
        foreach (var oneActor in actors)
        {
            SendNotification(oneActor.ConnectionId, oneActor.UserId, Constants.GAME_EVENT_NAME_UPDATE_PLAYER,
                new UpdatePlayerMessage()
                {
                    Player = PlayerViewFactory.Create(oneActor, null!, actor),
                }, null);
        }
    }

    public void GameLeft(string connectionId, Guid userId, long? requestId)
    {
        SendNotification(connectionId, userId, Constants.GAME_EVENT_NAME_GAME_LEFT, new GameLeftMessage(), requestId);
    }

    public void InformActionsPlayable(ActorModel actor, long requestId,
        List<AllActionsPlayableMessage.AllActionsPlayableMessageContent> resData)
    {
        var t = new Dictionary<string, AllActionsPlayableMessage.AllActionsPlayableMessageContent>();
        for (var i = 0; i < resData.Count; i++)
        {
            t.Add(i.ToString(), resData[i]);
        }

        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_ACTIONS_PLAYABLE,
            new AllActionsPlayableMessage()
            {
                PlayableInformation = t
            }, requestId);
    }

    public void ActionPointsChanged(ActorModel actor, int remainingActionPoints)
    {
        SendNotification(actor.ConnectionId, actor.UserId, Constants.GAME_EVENT_NAME_ACTION_POINTS_CHANGED,
            new ActionPointsChangedMessage()
            {
                ActionPoints = remainingActionPoints,
            }, null);
    }
}